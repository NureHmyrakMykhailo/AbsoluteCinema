const WebSocket = require('ws');
const { createClient } = require('@supabase/supabase-js');
const cookieParser = require('cookie-parser');

// Инициализация Supabase клиента
const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_ANON_KEY
);

// Хранилище активных соединений
const clients = new Map();

// Инициализация WebSocket сервера
function initWebSocket(server) {
    const wss = new WebSocket.Server({ 
        server, 
        path: '/ws/chat',
        verifyClient: (info, callback) => {
            callback(true);
        }
    });

    wss.on('connection', async (ws, req) => {
        console.log('Новое WebSocket соединение');

        // Аутентификация пользователя
        ws.on('message', async (message) => {
            try {
                const data = JSON.parse(message);
                console.log('Получено WebSocket сообщение:', data);

                if (data.type === 'auth') {
                    const token = data.token;
                    if (!token) {
                        console.log('Токен не найден в сообщении');
                        ws.close(1008, 'Unauthorized');
                        return;
                    }

                    try {
                        // Проверяем токен через Supabase
                        const { data: { user }, error } = await supabase.auth.getUser(token);
                        
                        if (error || !user) {
                            console.error('Ошибка аутентификации:', error);
                            ws.close(1008, 'Unauthorized');
                            return;
                        }

                        console.log('Пользователь успешно аутентифицирован:', user.id);
                        
                        // Сохраняем соединение в Map
                        const userId = user.id.toLowerCase();
                        clients.set(userId, {
                            ws,
                            userId
                        });
                        
                        console.log(`Пользователь ${userId} подключен к WebSocket`);
                        console.log('Текущие подключенные клиенты:', Array.from(clients.keys()));
                    } catch (error) {
                        console.error('Ошибка аутентификации:', error);
                        ws.close(1008, 'Unauthorized');
                    }
                } else if (data.type === 'message') {
                    // Проверяем, аутентифицирован ли отправитель
                    const sender = Array.from(clients.entries()).find(([id, client]) => client.ws === ws);
                    if (!sender) {
                        console.error('Отправитель не аутентифицирован');
                        return;
                    }

                    console.log('Отправитель найден:', sender[0]);
                    console.log('Текущие подключенные клиенты:', Array.from(clients.keys()));

                    // Получаем информацию о чате
                    const chat = await getChatInfo(data.chat_id);
                    
                    if (!chat) {
                        console.error('Чат не найден:', data.chat_id);
                        return;
                    }

                    // Проверяем, является ли отправитель участником чата
                    if (chat.user1_id.toLowerCase() !== sender[0] && chat.user2_id.toLowerCase() !== sender[0]) {
                        console.error('Отправитель не является участником чата');
                        return;
                    }

                    // Определяем получателя сообщения
                    const recipientId = chat.user1_id.toLowerCase() === sender[0] ? chat.user2_id.toLowerCase() : chat.user1_id.toLowerCase();
                    console.log('ID получателя:', recipientId);
                    
                    // Получаем соединение получателя
                    const recipient = clients.get(recipientId);
                    console.log('Найден получатель:', recipient ? 'да' : 'нет');
                    
                    if (recipient) {
                        try {
                            // Отправляем сообщение получателю
                            recipient.ws.send(JSON.stringify({
                                type: 'message',
                                chat_id: data.chat_id,
                                content: data.content,
                                sender_id: sender[0],
                                sent_at: data.sent_at || new Date().toISOString()
                            }));
                            console.log(`Сообщение отправлено пользователю ${recipientId}`);
                            
                            // Отправляем подтверждение отправителю
                            ws.send(JSON.stringify({
                                type: 'message_sent',
                                chat_id: data.chat_id,
                                message_id: data.message_id
                            }));
                        } catch (error) {
                            console.error('Ошибка при отправке сообщения получателю:', error);
                            // Если не удалось отправить сообщение, удаляем соединение
                            clients.delete(recipientId);
                            
                            // Отправляем ошибку отправителю
                            ws.send(JSON.stringify({
                                type: 'message_error',
                                chat_id: data.chat_id,
                                error: 'Не удалось отправить сообщение'
                            }));
                        }
                    } else {
                        console.log(`Получатель ${recipientId} не подключен к WebSocket`);
                        // Отправляем уведомление отправителю
                        ws.send(JSON.stringify({
                            type: 'message_status',
                            chat_id: data.chat_id,
                            status: 'recipient_offline'
                        }));
                    }
                }
            } catch (error) {
                console.error('Ошибка обработки сообщения:', error);
            }
        });

        // Обработка отключения
        ws.on('close', () => {
            // Удаляем соединение из Map
            for (const [userId, client] of clients.entries()) {
                if (client.ws === ws) {
                    clients.delete(userId);
                    console.log(`Пользователь ${userId} отключен от WebSocket`);
                    console.log('Оставшиеся подключенные клиенты:', Array.from(clients.keys()));
                    break;
                }
            }
        });

        // Обработка ошибок соединения
        ws.on('error', (error) => {
            console.error('WebSocket ошибка:', error);
            // Удаляем соединение из Map при ошибке
            for (const [userId, client] of clients.entries()) {
                if (client.ws === ws) {
                    clients.delete(userId);
                    console.log(`Пользователь ${userId} отключен из-за ошибки`);
                    console.log('Оставшиеся подключенные клиенты:', Array.from(clients.keys()));
                    break;
                }
            }
        });
    });

    return wss;
}

// Функция для получения информации о чате
async function getChatInfo(chatId) {
    try {
        const { data, error } = await supabase
            .from('chats')
            .select('*')
            .eq('id', chatId)
            .single();

        if (error) {
            console.error('Ошибка получения информации о чате:', error);
            return null;
        }

        return data;
    } catch (error) {
        console.error('Ошибка получения информации о чате:', error);
        return null;
    }
}

module.exports = { initWebSocket }; 