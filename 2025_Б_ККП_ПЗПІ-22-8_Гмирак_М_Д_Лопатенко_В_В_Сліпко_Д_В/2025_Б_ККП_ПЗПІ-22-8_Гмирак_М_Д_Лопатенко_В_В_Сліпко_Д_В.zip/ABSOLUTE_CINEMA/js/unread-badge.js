// Универсальный скрипт для обновления бейджа непрочитанных сообщений в хедере
async function updateUnreadBadgeGlobal() {
    const badge = document.getElementById('unread-badge');
    if (!badge) return;
    try {
        const response = await fetch('/api/chats');
        if (!response.ok) return;
        const data = await response.json();
        const chats = data.chats || [];
        const totalUnread = chats.reduce((sum, chat) => sum + (chat.unread_count || 0), 0);
        if (totalUnread > 0) {
            badge.textContent = totalUnread > 99 ? '99+' : totalUnread;
            badge.style.display = 'inline-flex';
        } else {
            badge.style.display = 'none';
        }
    } catch (e) {
        badge.style.display = 'none';
    }
}

function tryInitUnreadBadge() {
    if (document.getElementById('unread-badge')) {
        updateUnreadBadgeGlobal();
        setInterval(updateUnreadBadgeGlobal, 30000);
    } else {
        setTimeout(tryInitUnreadBadge, 100);
    }
}

document.addEventListener('DOMContentLoaded', tryInitUnreadBadge);
document.addEventListener('headerLoaded', tryInitUnreadBadge); 