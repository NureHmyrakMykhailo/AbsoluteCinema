// Навешиваем обработчик на кнопку после загрузки страницы
// и предотвращаем дублирование формы

document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const mediaId = urlParams.get('id');

    // Загружаем рецензии при загрузке страницы
    if (mediaId) {
        loadReviews(mediaId);
    }

    // Навешиваем обработчик на существующую кнопку
    const writeBtn = document.getElementById('writeReviewBtn');
    if (writeBtn) {
        writeBtn.addEventListener('click', () => {
            // Проверяем, не открыта ли уже форма
            if (!document.querySelector('.review-form')) {
                showReviewForm(mediaId);
            }
        });
    }
});

// Функция для отображения формы рецензии
function showReviewForm(mediaId) {
    // Проверяем авторизацию
    fetch('/api/auth/status')
        .then(response => response.json())
        .then(data => {
            if (!data.authenticated) {
                alert('Для написания рецензии необходимо авторизоваться');
                return;
            }

            const reviewForm = document.createElement('div');
            reviewForm.className = 'review-form';
            reviewForm.innerHTML = `
                <h3>Написать рецензию</h3>
                <div class="rating-container">
                    <label>Оценка:</label>
                    <div class="star-rating">
                        ${Array(5).fill().map((_, i) => `
                            <span class="star" data-rating="${i + 1}">★</span>
                        `).join('')}
                    </div>
                </div>
                <textarea id="reviewContent" placeholder="Напишите вашу рецензию..." rows="4"></textarea>
                <div class="spoiler-checkbox">
                    <input type="checkbox" id="containsSpoilers">
                    <label for="containsSpoilers">Содержит спойлеры</label>
                </div>
                <button onclick="submitReview(${mediaId})">Опубликовать рецензию</button>
            `;

            // Вставляем форму перед списком рецензий
            const reviewsContainer = document.querySelector('.reviews-container');
            const reviewsList = reviewsContainer.querySelector('.reviews-list');
            reviewsContainer.insertBefore(reviewForm, reviewsList);

            // Добавляем обработчики для звезд рейтинга
            const stars = reviewForm.querySelectorAll('.star');
            stars.forEach(star => {
                star.addEventListener('click', function() {
                    const rating = this.dataset.rating;
                    stars.forEach(s => s.classList.remove('active'));
                    for (let i = 0; i < rating; i++) {
                        stars[i].classList.add('active');
                    }
                });
            });
        })
        .catch(error => {
            console.error('Ошибка при проверке авторизации:', error);
            alert('Произошла ошибка при проверке авторизации');
        });
}

// Функция для отправки рецензии
async function submitReview(mediaId) {
    const content = document.getElementById('reviewContent').value;
    const rating = document.querySelectorAll('.star.active').length;
    const containsSpoilers = document.getElementById('containsSpoilers').checked;

    if (!content || !rating) {
        alert('Пожалуйста, заполните все обязательные поля');
        return;
    }

    try {
        const response = await fetch('/api/reviews', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                mediaId,
                content,
                rating,
                containsSpoilers
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Ошибка при отправке рецензии');
        }

        // Очищаем форму и обновляем список рецензий
        document.querySelector('.review-form').remove();
        loadReviews(mediaId);
    } catch (error) {
        console.error('Ошибка:', error);
        alert(error.message || 'Произошла ошибка при отправке рецензии');
    }
}

// Функция для загрузки рецензий
async function loadReviews(mediaId) {
    try {
        const response = await fetch(`/api/reviews/${mediaId}`);
        if (!response.ok) {
            throw new Error('Ошибка при загрузке рецензий');
        }
        
        const reviews = await response.json();

        const reviewsContainer = document.querySelector('.reviews-list');
        reviewsContainer.innerHTML = '';

        if (reviews.length === 0) {
            reviewsContainer.innerHTML = '<p class="no-reviews">Пока нет рецензий</p>';
            return;
        }

        reviews.forEach(review => {
            const reviewElement = document.createElement('div');
            reviewElement.className = 'review-item';
            reviewElement.innerHTML = `
                <div class="review-header">
                    <span class="review-author">${review.username}</span>
                    <div class="review-rating">
                        ${Array(5).fill().map((_, i) => `
                            <span class="star ${i < review.rating ? 'active' : ''}">★</span>
                        `).join('')}
                    </div>
                </div>
                ${review.contains_spoilers ? '<div class="spoiler-warning">⚠️ Содержит спойлеры</div>' : ''}
                <div class="review-content">${review.content}</div>
                <div class="review-date">${new Date(review.created_at).toLocaleDateString('ru-RU')}</div>
            `;
            reviewsContainer.appendChild(reviewElement);
        });
    } catch (error) {
        console.error('Ошибка при загрузке рецензий:', error);
        const reviewsContainer = document.querySelector('.reviews-list');
        reviewsContainer.innerHTML = '<p class="error-message">Ошибка при загрузке рецензий</p>';
    }
} 