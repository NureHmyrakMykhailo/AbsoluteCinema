// Функция для загрузки популярных фильмов
async function loadPopularMovies() {
    try {
        const response = await fetch('/api/popular-movies');
        if (!response.ok) {
            throw new Error('Не удалось загрузить популярные фильмы');
        }

        const data = await response.json();
        const movies = data.movies || [];

        // Получаем контейнер для популярных фильмов
        const popularMoviesTrack = document.getElementById('popularMoviesTrack');
        if (!popularMoviesTrack) return;

        // Очищаем контейнер
        popularMoviesTrack.innerHTML = '';

        // Добавляем фильмы в контейнер
        movies
            .filter(movie => Number(movie.imdb_rating) >= 8)
            .forEach((movie, index) => {
                const movieCard = document.createElement('div');
                movieCard.className = 'popular-movie-card';
                movieCard.setAttribute('data-index', index);

                // Форматируем дату релиза
                const releaseDate = movie.release_date ? new Date(movie.release_date) : null;
                const releaseYear = releaseDate ? releaseDate.getFullYear() : '';

                // Сокращаем описание если оно слишком длинное
                const shortDescription = movie.description && movie.description.length > 120 
                    ? movie.description.substring(0, 120) + '...' 
                    : (movie.description || 'Опис відсутній');

                // Формируем блок с рейтингами
                const imdbRating = movie.imdb_rating 
                    ? `<span class="star">★</span> ${movie.imdb_rating}/10` 
                    : `<span class="star">★</span> ?/10`;
                
                // Оценка глядачів
                const userRating = `<span class="user-rating">Оцінка глядачів: ${typeof movie.average_rating === 'number' && !isNaN(movie.average_rating) ? movie.average_rating : '—'}</span>`;

                movieCard.innerHTML = `
                    <div class="movie-poster">
                        <img src="${movie.poster_url || 'https://via.placeholder.com/150x225?text=Немає+постера'}" alt="${movie.title}">
                        <div class="watch-overlay">
                            <button class="watch-button" style="background-color: #f4ff60; color: #000000;">Детальніше</button>
                        </div>
                    </div>
                    <div class="movie-info">
                        <h3 title="${movie.title}">${movie.title}</h3>
                        <div class="movie-rating">
                            ${imdbRating}
                            <br>
                            ${userRating}
                        </div>
                        <div class="movie-genres">${movie.genres || releaseYear}</div>
                        <div class="popular-movie-description">
                            ${shortDescription}
                        </div>
                    </div>
                `;

                // Добавляем обработчик клика для просмотра фильма
                const watchButton = movieCard.querySelector('.watch-button');
                watchButton.addEventListener('click', () => {
                    window.location.href = `/movie/${movie.id}`;
                });

                popularMoviesTrack.appendChild(movieCard);
            });

        // Инициализация карусели для популярных фильмов
        try {
            if (typeof window.initPopularMoviesCarousel === 'function' && movies.length > 0) {
                window.initPopularMoviesCarousel();
            }
        } catch (carouselError) {
            console.error('Ошибка инициализации карусели популярных фильмов:', carouselError);
        }
    } catch (error) {
        console.error('Ошибка при загрузке популярных фильмов:', error);
        const popularMoviesTrack = document.getElementById('popularMoviesTrack');
        if (popularMoviesTrack) {
            popularMoviesTrack.innerHTML = `
                <div class="error-container">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>Помилка при завантаженні популярних фільмів: ${error.message}</p>
                </div>
            `;
        }
    }
}

// Загружаем популярные фильмы при загрузке страницы
document.addEventListener('DOMContentLoaded', loadPopularMovies);

// Удаляем эту заглушку, чтобы не конфликтовала с основной функцией в script.js
// function initPopularMoviesCarousel() {} 