// particles.js - Анимация геометрических фигур на фоне страницы профиля

document.addEventListener('DOMContentLoaded', function() {
    initParticlesAnimation();
});

function initParticlesAnimation() {
    // Анимация частиц в основном канвасе
    const canvas = document.getElementById('particles-canvas');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Установка размеров canvas
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();
    
    // Настройки частиц
    const particles = [];
    const particleCount = 180; // Увеличено количество частиц
    const minSize = 1;
    const maxSize = 3;
    const repelRadius = 100;
    const repelForce = 0.3;
    
    // Создание частиц
    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 0.3,
            vy: (Math.random() - 0.5) * 0.3,
            size: Math.random() * (maxSize - minSize) + minSize,
            color: getRandomColor(),
            shape: Math.floor(Math.random() * 3)
        });
    }
    
    // Функция для генерации случайного цвета
    function getRandomColor() {
        // Выбираем из палитры желто-золотых оттенков
        const colors = [
            `hsla(51, 50%, 70%, ${Math.random() * 0.3 + 0.2})`, // Светлый хаки
            `hsla(43, 74%, 49%, ${Math.random() * 0.3 + 0.2})`, // Золотистый
            `hsla(54, 76%, 60%, ${Math.random() * 0.3 + 0.2})`, // Желтый
            `hsla(48, 90%, 58%, ${Math.random() * 0.3 + 0.2})` // Горчичный
        ];
        return colors[Math.floor(Math.random() * colors.length)];
    }
    
    // Обработчик движения мыши
    let mouseX = null;
    let mouseY = null;
    
    window.addEventListener('mousemove', function(e) {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });
    
    window.addEventListener('mouseout', function() {
        mouseX = null;
        mouseY = null;
    });
    
    // Анимация
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        particles.forEach(p => {
            // Отталкивание от курсора
            if (mouseX !== null && mouseY !== null) {
                const dx = p.x - mouseX;
                const dy = p.y - mouseY;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < repelRadius) {
                    const angle = Math.atan2(dy, dx);
                    const force = (repelRadius - distance) / repelRadius * repelForce;
                    
                    p.vx += Math.cos(angle) * force * 2;
                    p.vy += Math.sin(angle) * force * 2;
                }
            }
            
            // Движение частиц
            p.x += p.vx;
            p.y += p.vy;
            
            // Отражение от границ
            if (p.x < 0 || p.x > canvas.width) p.vx *= -0.8;
            if (p.y < 0 || p.y > canvas.height) p.vy *= -0.8;
            
            // Ограничение позиций
            p.x = Math.max(0, Math.min(canvas.width, p.x));
            p.y = Math.max(0, Math.min(canvas.height, p.y));
            
            // Рисование частиц
            ctx.fillStyle = p.color;
            
            switch (p.shape) {
                case 0: // Круг
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                    ctx.fill();
                    break;
                case 1: // Квадрат
                    ctx.fillRect(p.x - p.size, p.y - p.size, p.size * 2, p.size * 2);
                    break;
                case 2: // Треугольник
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y - p.size);
                    ctx.lineTo(p.x + p.size, p.y + p.size);
                    ctx.lineTo(p.x - p.size, p.y + p.size);
                    ctx.closePath();
                    ctx.fill();
                    break;
            }
        });
        
        requestAnimationFrame(animate);
    }
    
    animate();
    
    window.addEventListener('resize', function() {
        resizeCanvas();
    });

    // Удаление анимации с модального окна - оставляем только на основной странице
    // Находим и удаляем canvas из модального окна
    const modalCanvas = document.getElementById('modal-particles-canvas');
    if (modalCanvas) {
        modalCanvas.remove();
    }
} 