/* script.js – основной JavaScript файл проекта ABSOLUTE CINEMA */

document.addEventListener('DOMContentLoaded', function() {
    // ======= ОБЩИЕ ФУНКЦИИ И ОБРАБОТЧИКИ =======
    
    // Изменение фона шапки при прокрутке
    window.addEventListener('scroll', function() {
        const header = document.getElementById('main-header');
        if (window.scrollY > 20) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
    
    // Обработка клика по логотипу
    const logoLink = document.getElementById('logo-link');
    if (logoLink) {
        logoLink.addEventListener('click', function(e) {
            if (window.location.pathname === '/') {
                e.preventDefault();
            }
        });
    }
    
    // ======= ФУНКЦИИ ПОИСКА =======
    
    // Улучшенный код для поискового попапа
    const searchIcon = document.getElementById('search-icon');
    const searchPopup = document.getElementById('search-popup');
    
    if (searchIcon && searchPopup) {
        searchIcon.addEventListener('click', function() {
            searchPopup.classList.toggle('active');
            searchIcon.classList.toggle('active');
            
            // Автофокус на поисковое поле когда открывается попап
            if (searchPopup.classList.contains('active')) {
                setTimeout(() => {
                    const searchInput = searchPopup.querySelector('input');
                    if (searchInput) searchInput.focus();
                }, 300); // Задержка соответствует времени анимации
            }
        });
        
        // Закрытие поиска при клике вне попапа
        document.addEventListener('click', function(e) {
            if (!searchIcon.contains(e.target) && !searchPopup.contains(e.target)) {
                searchPopup.classList.remove('active');
                searchIcon.classList.remove('active');
            }
        });
        
        // Закрытие поиска при нажатии Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && searchPopup.classList.contains('active')) {
                searchPopup.classList.remove('active');
                searchIcon.classList.remove('active');
            }
        });
        
        // Обработка ввода в поиске
        const searchInput = document.querySelector('.search-container input');
        const searchResults = document.querySelector('.search-results');
        
        if (searchInput && searchResults) {
            // Демонстрационные данные для поиска
            const movieData = [
                { title: 'Початок', year: 2010, image: 'https://via.placeholder.com/50x70' },
                { title: 'Втеча з Шоушенка', year: 1994, image: 'https://via.placeholder.com/50x70' },
                { title: 'Темний лицар', year: 2008, image: 'https://via.placeholder.com/50x70' },
                { title: 'Кримінальне чтиво', year: 1994, image: 'https://via.placeholder.com/50x70' },
                { title: 'Бійцівський клуб', year: 1999, image: 'https://via.placeholder.com/50x70' }
            ];
            
            searchInput.addEventListener('input', function() {
                const searchTerm = searchInput.value.toLowerCase().trim();
                
                if (searchTerm.length > 2) {
                    // Фильтрация результатов
                    const filteredMovies = movieData.filter(movie => 
                        movie.title.toLowerCase().includes(searchTerm)
                    );
                    
                    // Отображение результатов
                    displaySearchResults(filteredMovies);
                } else {
                    searchResults.innerHTML = '';
                }
            });
            
            function displaySearchResults(movies) {
                searchResults.innerHTML = '';
                
                if (movies.length === 0) {
                    searchResults.innerHTML = '<div class="no-results">Фільми не знайдені</div>';
                    return;
                }
                
                movies.forEach(movie => {
                    const resultItem = document.createElement('div');
                    resultItem.className = 'search-result-item';
                    
                    resultItem.innerHTML = `
                        <div class="search-result-img">
                            <img src="${movie.image}" alt="${movie.title}">
                        </div>
                        <div class="search-result-info">
                            <div class="search-result-title">${movie.title}</div>
                            <div class="search-result-year">${movie.year}</div>
                        </div>
                    `;
                    
                    resultItem.addEventListener('click', () => {
                        // Перенаправление на страницу фильма (заглушка)
                        console.log(`Перехід до фільму: ${movie.title}`);
                    });
                    
                    searchResults.appendChild(resultItem);
                });
            }
        }
    }
    
    // ======= ОБРАБОТКА ИСТОРИИ ПРОСМОТРОВ =======
    
    // Код для обработки значка истории просмотров
    const historyIcon = document.getElementById('history-icon');
    const historyPopup = document.getElementById('history-popup');
    
    if (historyIcon && historyPopup) {
        // Открытие/закрытие всплывающего окна истории при наведении
        historyIcon.addEventListener('mouseenter', function() {
            historyPopup.classList.add('active');
        });
        
        historyIcon.addEventListener('mouseleave', function(e) {
            // Задержка перед закрытием, чтобы пользователь мог перевести курсор на окно
            setTimeout(() => {
                if (!historyPopup.matches(':hover')) {
                    historyPopup.classList.remove('active');
                }
            }, 300);
        });
        
        historyPopup.addEventListener('mouseleave', function() {
            historyPopup.classList.remove('active');
        });
        
        // Обработчик для очистки истории
        const historyClearBtn = document.querySelector('.history-clear-btn');
        if (historyClearBtn) {
            historyClearBtn.addEventListener('click', function() {
                const historyItems = document.querySelector('.history-items');
                historyItems.innerHTML = '<p style="text-align: center; color: #777; padding: 20px;">Історія переглядів порожня</p>';
                this.style.display = 'none';
            });
        }
        
        // Обработка кликов по элементам истории
        const historyItems = document.querySelectorAll('.history-item');
        historyItems.forEach(item => {
            item.addEventListener('click', function() {
                const title = this.querySelector('.history-item-title').textContent;
                console.log(`Перехід до фільму: ${title}`);
                // Здесь можно добавить код для перехода на страницу фильма
            });
        });
    }

    // ======= ФУНКЦИИ ДЛЯ РАЗДЕЛА ОБСУЖДЕНИЙ =======
    async function loadDiscussionsPreview() {
        const grid = document.querySelector('.discussions-grid');
        if (!grid) return;
        grid.innerHTML = '<div class="loading-discussions">Завантаження обговорень...</div>';
        try {
            const res = await fetch('/api/discussions/preview');
            const data = await res.json();
            if (!data.discussions || !Array.isArray(data.discussions)) throw new Error('Некорректный ответ сервера');
            if (data.discussions.length === 0) {
                grid.innerHTML = '<div class="no-discussions">Обговорень поки немає</div>';
                return;
            }
            grid.innerHTML = '';
            data.discussions.forEach(discussion => {
                const card = document.createElement('div');
                card.className = 'discussion-card';
                card.innerHTML = `
                    <h3 class="discussion-title">${discussion.title}</h3>
                    <div class="discussion-description">${discussion.description ? discussion.description : ''}</div>
                    <div class="discussion-author">
                        <img src="${discussion.author.avatar_url}" alt="Автор">
                        <span>${discussion.author.username}</span>
                    </div>
                    <div class="comments-count">
                        <i class="fas fa-comments"></i> ${discussion.comments_count} коментар${discussion.comments_count === 1 ? '': (discussion.comments_count < 5 ? 'і' : 'ів')}
                    </div>
                    ${discussion.first_comment ? `<div class="first-comment"><div class="comment-author">${discussion.first_comment.username}</div><div class="comment-text">${discussion.first_comment.content}</div></div>` : ''}
                `;
                grid.appendChild(card);
            });
            // Анимация карточек при загрузке (оставляем как было)
            const discussionCards = document.querySelectorAll('.discussion-card');
            discussionCards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100 + index * 100);
            });
        } catch (e) {
            grid.innerHTML = '<div class="error-discussions">Помилка завантаження обговорень</div>';
        }
    }

    function initDiscussionsSection() {
        const grid = document.querySelector('.discussions-grid');
        if (!grid) return;

        grid.addEventListener('click', function(e) {
            const card = e.target.closest('.discussion-card');
            if (card && e.button === 0) {
                window.location.href = '/discussions.html';
            }
        });

        // Анимация карточек при загрузке
        const discussionCards = grid.querySelectorAll('.discussion-card');
        discussionCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 100 + index * 100);
        });
    }

    // ======= ИНИЦИАЛИЗАЦИЯ ВСЕХ КОМПОНЕНТОВ =======
    // Инициализация слайдера
    initInfiniteCarousel();
    
    // Инициализация блока Новинки
    initLatestMoviesCarousel();
    
    // Инициализация блока популярных фильмов
    initPopularMoviesCarousel();
    
    // Инициализация раздела обсуждений
    loadDiscussionsPreview();
    initDiscussionsSection();
    
    // Инициализация анимаций
    initScrollAnimations();
    
    // Инициализация модального окна авторизации
    initAuthModal();
    
    // Инициализация анимации частиц
    initParticlesAnimation();

    // === МОДАЛЬНОЕ ОКНО ВСЕХ ФИЛЬМОВ ===
    const allMoviesBtn = document.querySelector('button, .all-movies-btn, .all-movies-link, .all-movies-cta, .all-movies-show-btn, .all-movies-show');
    const allMoviesModal = document.getElementById('all-movies-modal');
    const closeAllMoviesModal = document.getElementById('closeAllMoviesModal');
    const allMoviesList = document.getElementById('allMoviesList');
    const sortMovies = document.getElementById('sortMovies');
    const genreFilter = document.getElementById('genreFilter');

    // Найти кнопку 'усі' по тексту
    let usiBtn = null;
    document.querySelectorAll('button, .all-movies-btn').forEach(btn => {
        if (btn.textContent.trim() === 'УСІ' || btn.textContent.trim() === 'усі') usiBtn = btn;
    });

    if (usiBtn && allMoviesModal) {
        usiBtn.addEventListener('click', function() {
            allMoviesModal.style.display = 'flex';
            loadAndRenderAllMovies();
        });
    }
    if (closeAllMoviesModal) {
        closeAllMoviesModal.addEventListener('click', function() {
            allMoviesModal.style.display = 'none';
        });
    }
    // Закрытие по клику вне окна
    if (allMoviesModal) {
        allMoviesModal.addEventListener('click', function(e) {
            if (e.target === allMoviesModal) allMoviesModal.style.display = 'none';
        });
    }
    // Фильтрация и сортировка
    if (sortMovies && genreFilter) {
        sortMovies.addEventListener('change', loadAndRenderAllMovies);
        genreFilter.addEventListener('change', loadAndRenderAllMovies);
    }

    async function loadAndRenderAllMovies() {
        allMoviesList.innerHTML = '<div style="color:#ffe066;text-align:center;padding:30px;">Завантаження...</div>';
        // Получаем все фильмы (пример: с API или window.allMovies)
        let movies = [];
        try {
            // Попробуем получить с API
            const res = await fetch('/api/movies?minRating=8');
            if (res.ok) {
                movies = await res.json();
            } else {
                allMoviesList.innerHTML = '<div style="color:#e74c3c;text-align:center;padding:30px;">Не вдалося завантажити фільми</div>';
                return;
            }
        } catch {
            allMoviesList.innerHTML = '<div style="color:#e74c3c;text-align:center;padding:30px;">Не вдалося завантажити фільми</div>';
            return;
        }
        // Фильтрация по жанру
        const genre = genreFilter.value;
        if (genre !== 'all') {
            movies = movies.filter(m => (m.genres||[]).map(g=>g.toLowerCase()).includes(genre));
        }
        // Сортировка
        if (sortMovies.value === 'latest') {
            movies.sort((a,b) => (b.release_year||0)-(a.release_year||0));
        } else {
            movies.sort((a,b) => (b.imdb_rating||0)-(a.imdb_rating||0));
        }
        // Рендер
        if (!movies.length) {
            allMoviesList.innerHTML = '<div style="color:#ffe066;text-align:center;padding:30px;">Фільмів не знайдено</div>';
            return;
        }
        allMoviesList.innerHTML = movies.map(m => `
            <div class="all-movie-card" onclick="window.location='/movie/${m.id}'">
                <img src="${m.poster_url||'https://via.placeholder.com/150x225?text=No+Poster'}" alt="${m.title}">
                <div class="all-movie-card-title">${m.title}</div>
                <div class="all-movie-card-rating">IMDB: ${m.imdb_rating||'—'}</div>
                <div class="all-movie-card-genres">${(m.genres||[]).join(', ')}</div>
                <div class="all-movie-card-year" style="color:#aaa;font-size:12px;">${m.release_year||''}</div>
            </div>
        `).join('');
    }

    // ======= Переход по кнопкам 'УСІ' в новинках и популярных =======
    const latestViewAllBtn = document.querySelector('.latest-view-all');
    if (latestViewAllBtn) {
        latestViewAllBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = '/movies.html?sort=latest';
        });
    }
    const popularViewAllBtn = document.querySelector('.popular-view-all');
    if (popularViewAllBtn) {
        popularViewAllBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = '/movies.html?sort=popular';
        });
    }

    // === Переход по кнопке "Дивитися фільми" на страницу movies ===
    const ctaButton = document.querySelector('.cta-button');
    if (ctaButton) {
        ctaButton.addEventListener('click', function() {
            window.location.href = '/movies.html';
        });
    }
});

// Ниже будут идти все вынесенные функции 

// ======= ФУНКЦИИ ДЛЯ СЛАЙДЕРА И КАРУСЕЛИ =======

// Функция инициализации главного слайдера
function initInfiniteCarousel() {
    const carouselTrack = document.getElementById('carouselTrack');
    if (!carouselTrack) return;
    
    const slides = Array.from(carouselTrack.querySelectorAll('.carousel-slide'));
    const indicators = document.querySelectorAll('.indicator');
    const prevButton = document.getElementById('prevSlide');
    const nextButton = document.getElementById('nextSlide');
    
    let currentIndex = 0;
    let slideInterval;
    const slideDelay = 5000;
    let isResizing = false;
    
    // Клонируем первый и последний слайды для создания эффекта бесконечности
    const firstSlideClone = slides[0].cloneNode(true);
    const lastSlideClone = slides[slides.length - 1].cloneNode(true);
    
    // Добавляем клоны в начало и конец карусели
    carouselTrack.appendChild(firstSlideClone);
    carouselTrack.insertBefore(lastSlideClone, carouselTrack.firstChild);
    
    // Устанавливаем активный слайд с учетом клонов (начинаем с первого реального слайда)
    currentIndex = 1;
    
    function setActiveSlide(index, withAnimation = true) {
        // Защита от установки некорректного индекса
        if (index < 0 || index > slides.length + 1) {
            return;
        }
        
        // Обновляем классы для всех слайдов
        const allSlides = Array.from(carouselTrack.querySelectorAll('.carousel-slide'));
        allSlides.forEach(slide => slide.classList.remove('active'));
        
        if (allSlides[index]) {
            allSlides[index].classList.add('active');
        }
        
        // Определяем реальный индекс для индикаторов (без учета клонов)
        const realIndex = index - 1;
        // Обрабатываем случаи с клонами
        const indicatorIndex = realIndex < 0 ? slides.length - 1 : 
                               realIndex >= slides.length ? 0 : realIndex;
        
        // Обновляем индикаторы
        indicators.forEach(ind => ind.classList.remove('active'));
        indicators[indicatorIndex].classList.add('active');
        
        // Пересчитываем размеры слайдов если окно было изменено
        if (isResizing) {
            centerCarouselTrack();
            isResizing = false;
        }
        
        // Перемещаем карусель с анимацией или без
        const slideWidth = allSlides[0].offsetWidth;
        
        if (!withAnimation) {
            carouselTrack.style.transition = 'none';
        } else {
            carouselTrack.style.transition = 'transform 0.5s ease-out';
        }
        
        carouselTrack.style.transform = `translateX(-${index * slideWidth}px)`;
        currentIndex = index;
        resetSlideTimer();
    }
    
    function handleTransitionEnd() {
        // Если дошли до клона последнего слайда или первого слайда
        if (currentIndex === 0 || currentIndex === slides.length + 1) {
            // Отключаем ВСЕ анимации для слайдов и контейнера
            const allSlides = Array.from(carouselTrack.querySelectorAll('.carousel-slide'));
            
            // Добавляем специальный класс для отключения анимаций
            document.body.classList.add('freeze-animations');
            carouselTrack.classList.add('no-transition');
            allSlides.forEach(slide => slide.classList.add('no-transition'));
            
            // Перемещаемся к нужному слайду
            const targetIndex = (currentIndex === 0) ? slides.length : 1;
            setActiveSlide(targetIndex, false);
            
            // Добавляем небольшую задержку перед возвращением анимаций
            setTimeout(() => {
                document.body.classList.remove('freeze-animations');
                carouselTrack.classList.remove('no-transition');
                allSlides.forEach(slide => slide.classList.remove('no-transition'));
            }, 50);
        }
    }
    
    function nextSlide() {
        setActiveSlide(currentIndex + 1);
    }
    
    function prevSlide() {
        setActiveSlide(currentIndex - 1);
    }
    
    function resetSlideTimer() {
        clearInterval(slideInterval);
        slideInterval = setInterval(nextSlide, slideDelay);
    }
    
    // Центрируем слайды в окне просмотра с учетом всех размеров
    function centerCarouselTrack() {
        const windowWidth = window.innerWidth;
        const containerWidth = document.querySelector('.carousel-container').offsetWidth;
        const allSlides = Array.from(carouselTrack.querySelectorAll('.carousel-slide'));
        
        // Получаем актуальную ширину слайда
        const slideWidth = allSlides[0].offsetWidth;
        
        // Расчитаваем отступ, чтобы центрировать слайды
        const offset = (containerWidth - slideWidth) / 2;
        
        // Применяем отступы и обновляем позицию активного слайда
        carouselTrack.style.paddingLeft = `${offset}px`;
        carouselTrack.style.paddingRight = `${offset}px`;
        
        // Обновляем позицию карусели без анимации
        carouselTrack.style.transition = 'none';
        carouselTrack.style.transform = `translateX(-${currentIndex * slideWidth}px)`;
        
        // Форсируем перекомпоновку (reflow)
        carouselTrack.offsetHeight;
    }
    
    // Дебаунсинг функция для отслеживания изменения размера окна
    function debounce(func, delay) {
        let timeoutId;
        return function() {
            const context = this;
            const args = arguments;
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => {
                func.apply(context, args);
            }, delay);
        };
    }
    
    // Обработчик изменения размера окна с дебаунсингом
    const handleResize = debounce(() => {
        isResizing = true;
        
        // Временно отключаем переходы
        const allSlides = Array.from(carouselTrack.querySelectorAll('.carousel-slide'));
        carouselTrack.classList.add('no-transition');
        allSlides.forEach(slide => slide.classList.add('no-transition'));
        
        // Обновляем позиции и размеры
        centerCarouselTrack();
        
        // Ждем завершения операций изменения размера
        setTimeout(() => {
            // Возвращаем переходы и обновляем активный слайд
            carouselTrack.classList.remove('no-transition');
            allSlides.forEach(slide => slide.classList.remove('no-transition'));
            setActiveSlide(currentIndex, false);
        }, 50);
    }, 100);
    
    // Инициализация
    centerCarouselTrack();
    // Начинаем с первого оригинального слайда (учитывая клон в начале)
    setActiveSlide(1, false);
    
    // Обработчики событий
    carouselTrack.addEventListener('transitionend', handleTransitionEnd);
    prevButton.addEventListener('click', prevSlide);
    nextButton.addEventListener('click', nextSlide);
    
    // Обработчики для индикаторов
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
            // Индекс + 1 из-за клона в начале
            setActiveSlide(index + 1);
        });
    });
    
    // Улучшенный обработчик изменения размера окна
    window.addEventListener('resize', handleResize);
    
    // Контроль автопрокрутки
    const sliderContainer = document.querySelector('.carousel-container');
    sliderContainer.addEventListener('mouseenter', () => clearInterval(slideInterval));
    sliderContainer.addEventListener('mouseleave', resetSlideTimer);
}

// Функция для инициализации карусели последних фильмов
window.initLatestMoviesCarousel = function() {
    const container = document.getElementById('latestMoviesContainer');
    if (!container) return;
    
    const track = document.getElementById('latestMoviesTrack');
    const cards = Array.from(track.querySelectorAll('.movie-card'));
    
    if (!cards || cards.length === 0) {
        console.warn('Нет карточек фильмов для инициализации карусели');
        return;
    }
    
    const prevBtn = document.getElementById('latestPrevMovie');
    const nextBtn = document.getElementById('latestNextMovie');
    const progressBar = document.getElementById('latestProgressBar');
    
    let position = 0;
    let cardsPerView = getCardsPerView();
    let cardWidth = cards[0].offsetWidth + 20; // ширина карточки + margin
    let maxPosition = Math.max(0, cards.length - cardsPerView);
    const scrollStep = 2; // Увеличиваем до 2 карточек для прокрутки за раз
    let autoScrollInterval;
    
    // Центрируем карточки
    function centerCardsContainer() {
        const containerWidth = document.querySelector('.movies-carousel-container').offsetWidth;
        const totalCardsWidth = cardsPerView * cardWidth;
        const marginOffset = (containerWidth - totalCardsWidth) / 2;
        
        if (marginOffset > 0) {
            track.style.marginLeft = `${marginOffset}px`;
        } else {
            track.style.marginLeft = '0';
        }
    }
    
    // Функция для определения количества видимых карточек
    function getCardsPerView() {
        const width = window.innerWidth;
        if (width >= 1400) return 6;
        if (width >= 1200) return 5;
        if (width >= 992) return 4;
        if (width >= 768) return 3;
        if (width >= 576) return 2;
        return 1;
    }
    
    // Обновляем прогресс-бар
    function updateProgressBar() {
        const maxSteps = Math.max(1, Math.floor(maxPosition / scrollStep));
        const currentStep = Math.min(maxSteps, Math.floor(position / scrollStep));
        const progress = (currentStep / maxSteps) * 100;
        progressBar.style.width = `${progress}%`;
    }
    
    // Функция перемещения карусели
    function moveCarousel(newPosition) {
        // Ограничиваем позицию
        position = Math.max(0, Math.min(newPosition, maxPosition));
        track.style.transform = `translateX(-${position * cardWidth}px)`;
        updateProgressBar();
    }
    
    // Обработчики кнопок навигации
    nextBtn.addEventListener('click', () => {
        // Проверяем, не достигли ли мы последнего слайда
        if (position + scrollStep > maxPosition) {
            // Если осталось меньше карточек чем scrollStep, показываем оставшиеся
            if (position < maxPosition) {
                moveCarousel(maxPosition);
            } else {
                // Если достигли конца, возвращаемся в начало с плавной анимацией
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(0);
            }
        } else {
            track.style.transition = 'transform 0.3s ease';
            moveCarousel(position + scrollStep);
        }
    });
    
    prevBtn.addEventListener('click', () => {
        if (position - scrollStep < 0) {
            // Если достигли начала, перемещаемся к началу
            moveCarousel(0);
        } else {
            track.style.transition = 'transform 0.3s ease';
            moveCarousel(position - scrollStep);
        }
    });
    
    // Автоматическая прокрутка
    function startAutoScroll() {
        autoScrollInterval = setInterval(() => {
            if (position + scrollStep > maxPosition) {
                // Если достигли конца, возвращаемся в начало
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(0);
            } else {
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(position + scrollStep);
            }
        }, 5000);
    }
    
    function resetAutoScroll() {
        clearInterval(autoScrollInterval);
        startAutoScroll();
    }
    
    function stopAutoScroll() {
        clearInterval(autoScrollInterval);
    }
    
    container.addEventListener('mouseenter', stopAutoScroll);
    container.addEventListener('mouseleave', startAutoScroll);
    
    // Обработчик изменения размера окна
    window.addEventListener('resize', () => {
        // Пересчитываем параметры карусели
        cardsPerView = getCardsPerView();
        cardWidth = cards[0].offsetWidth + 20;
        maxPosition = cards.length - cardsPerView;
        
        // Обновляем позицию
        moveCarousel(Math.min(position, maxPosition));
        
        // Центрируем карточки
        centerCardsContainer();
    });
    
    // Добавляем поддержку свайпов для мобильных устройств
    let touchStartX = 0;
    let touchEndX = 0;
    
    track.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });
    
    track.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    }, { passive: true });
    
    function handleSwipe() {
        const swipeThreshold = 50; // Минимальное расстояние для свайпа
        
        if (touchStartX - touchEndX > swipeThreshold) {
            // Свайп влево - следующий слайд
            if (position + scrollStep > maxPosition) {
                // Если осталось меньше карточек чем scrollStep, показываем оставшиеся
                if (position < maxPosition) {
                    moveCarousel(maxPosition);
                } else {
                    // Если достигли конца, возвращаемся в начало
                    moveCarousel(0);
                }
            } else {
                moveCarousel(position + scrollStep);
            }
            resetAutoScroll();
        } else if (touchEndX - touchStartX > swipeThreshold) {
            // Свайп вправо - предыдущий слайд
            if (position - scrollStep < 0) {
                moveCarousel(0);
            } else {
                moveCarousel(position - scrollStep);
            }
            resetAutoScroll();
        }
    }
    
    // Инициализация
    centerCardsContainer();
    moveCarousel(0);
    startAutoScroll();
}

// Функция для инициализации карусели популярных фильмов
window.initPopularMoviesCarousel = function() {
    const container = document.getElementById('popularMoviesContainer');
    if (!container) return;
    
    const track = document.getElementById('popularMoviesTrack');
    const cards = Array.from(track.querySelectorAll('.popular-movie-card'));
    
    if (!cards || cards.length === 0) {
        console.warn('Нет карточек фильмов для инициализации карусели популярных фильмов');
        return;
    }
    
    const prevBtn = document.getElementById('popularPrevMovie');
    const nextBtn = document.getElementById('popularNextMovie');
    const progressBar = document.getElementById('popularProgressBar');
    
    let position = 0;
    let cardsPerView = getPopularCardsPerView();
    let cardWidth = cards[0].offsetWidth + 30; // ширина карточки + margin
    let maxPosition = Math.max(0, cards.length - cardsPerView);
    const scrollStep = 2; // Количество карточек для прокрутки за раз
    let autoScrollInterval;
    
    // Функция для определения количества видимых карточек
    // Увеличиваем количество карточек в ряду, так как они теперь горизонтальные
    function getPopularCardsPerView() {
        const width = window.innerWidth;
        if (width >= 1200) return 4;
        if (width >= 992) return 3;
        if (width >= 768) return 2;
        return 1;
    }
    
    // Центрируем карточки
    function centerCardsContainer() {
        const containerWidth = container.offsetWidth;
        const totalCardsWidth = cardsPerView * cardWidth;
        const marginOffset = (containerWidth - totalCardsWidth) / 2;
        
        if (marginOffset > 0) {
            track.style.marginLeft = `${marginOffset}px`;
        } else {
            track.style.marginLeft = '0';
        }
    }
    
    // Обновляем прогресс-бар
    function updateProgressBar() {
        const maxSteps = Math.max(1, Math.floor(maxPosition / scrollStep));
        const currentStep = Math.min(maxSteps, Math.floor(position / scrollStep));
        const progress = (currentStep / maxSteps) * 100;
        progressBar.style.width = `${progress}%`;
    }
    
    // Функция перемещения карусели
    function moveCarousel(newPosition) {
        // Ограничиваем позицию
        position = Math.max(0, Math.min(newPosition, maxPosition));
        track.style.transform = `translateX(-${position * cardWidth}px)`;
        updateProgressBar();
    }
    
    // Обработчики кнопок навигации
    nextBtn.addEventListener('click', () => {
        // Проверяем, не достигли ли мы последнего слайда
        if (position + scrollStep > maxPosition) {
            // Если осталось меньше карточек чем scrollStep, показываем оставшиеся
            if (position < maxPosition) {
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(maxPosition);
            } else {
                // Если достигли конца, возвращаемся в начало с плавной анимацией
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(0);
            }
        } else {
            track.style.transition = 'transform 0.3s ease';
            moveCarousel(position + scrollStep);
        }
    });
    
    prevBtn.addEventListener('click', () => {
        if (position - scrollStep < 0) {
            moveCarousel(0);
        } else {
            track.style.transition = 'transform 0.3s ease';
            moveCarousel(position - scrollStep);
        }
    });
    
    // Автоматическая прокрутка
    function startAutoScroll() {
        autoScrollInterval = setInterval(() => {
            if (position + scrollStep > maxPosition) {
                // Если достигли конца, возвращаемся в начало
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(0);
            } else {
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(position + scrollStep);
            }
        }, 6000);
    }
    
    function resetAutoScroll() {
        clearInterval(autoScrollInterval);
        startAutoScroll();
    }
    
    function stopAutoScroll() {
        clearInterval(autoScrollInterval);
    }
    
    // Обработчик изменения размера окна
    window.addEventListener('resize', () => {
        // Пересчитываем параметры карусели
        cardsPerView = getPopularCardsPerView();
        cardWidth = cards[0].offsetWidth + 30;
        maxPosition = cards.length - cardsPerView;
        
        // Обновляем позицию
        moveCarousel(Math.min(position, maxPosition));
        
        // Центрируем карточки
        centerCardsContainer();
    });
    
    // Обработчики наведения мыши
    container.addEventListener('mouseenter', stopAutoScroll);
    container.addEventListener('mouseleave', startAutoScroll);
    
    // Добавляем поддержку свайпов для мобильных устройств
    let touchStartX = 0;
    let touchEndX = 0;
    
    track.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });
    
    track.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    }, { passive: true });
    
    function handleSwipe() {
        const swipeThreshold = 50; // Минимальное расстояние для свайпа
        
        if (touchStartX - touchEndX > swipeThreshold) {
            // Свайп влево - следующий слайд
            if (position + scrollStep > maxPosition) {
                if (position < maxPosition) {
                    moveCarousel(maxPosition);
                } else {
                    moveCarousel(0);
                }
            } else {
                moveCarousel(position + scrollStep);
            }
            resetAutoScroll();
        } else if (touchEndX - touchStartX > swipeThreshold) {
            // Свайп вправо - предыдущий слайд
            if (position - scrollStep < 0) {
                moveCarousel(0);
            } else {
                moveCarousel(position - scrollStep);
            }
            resetAutoScroll();
        }
    }
    
    // Инициализация
    centerCardsContainer();
    moveCarousel(0);
    startAutoScroll();
}

// ======= ФУНКЦИИ ДЛЯ МОДАЛЬНОГО ОКНА АВТОРИЗАЦИИ =======

function initAuthModal() {
    const loginButton = document.querySelector('.login-button a');
    const authModal = document.getElementById('auth-modal');
    
    if (!loginButton || !authModal) return;
    
    const modalClose = document.querySelector('.modal-close');
    const modalOverlay = document.querySelector('.modal-overlay');
    const modalTabs = document.querySelectorAll('.modal-tab');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const resetPasswordForm = document.getElementById('reset-password-form');
    const forgotPasswordLink = document.querySelector('.forgot-password');
    const backToLoginLink = document.getElementById('back-to-login');
    const passwordToggles = document.querySelectorAll('.password-toggle');
    
    // Открытие модального окна при клике на кнопку Входа/Регистрации
    loginButton.addEventListener('click', function(e) {
        e.preventDefault();
        authModal.classList.add('active');
        document.body.style.overflow = 'hidden'; // Блокируем прокрутку страницы
    });
    
    // Закрытие модального окна при клике на крестик или затемненную область
    if (modalClose) modalClose.addEventListener('click', closeModal);
    if (modalOverlay) modalOverlay.addEventListener('click', closeModal);
    
    // Переключение между вкладками Вход/Регистрация
    modalTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Убираем активный класс у всех вкладок
            modalTabs.forEach(t => t.classList.remove('active'));
            // Добавляем активный класс кликнутой вкладке
            this.classList.add('active');
            
            // Скрываем форму восстановления пароля
            if (resetPasswordForm) resetPasswordForm.classList.remove('active');
            
            // Переключение между формами
            const tabType = this.getAttribute('data-tab');
            if (tabType === 'login') {
                if (loginForm) loginForm.classList.add('active');
                if (registerForm) registerForm.classList.remove('active');
            } else {
                if (registerForm) registerForm.classList.add('active');
                if (loginForm) loginForm.classList.remove('active');
            }
        });
    });
    
    // Переход к форме восстановления пароля
    if (forgotPasswordLink && resetPasswordForm) {
        forgotPasswordLink.addEventListener('click', function(e) {
            e.preventDefault();
            if (loginForm) loginForm.classList.remove('active');
            if (registerForm) registerForm.classList.remove('active');
            resetPasswordForm.classList.add('active');
            
            // Убираем активный класс с вкладок
            modalTabs.forEach(t => t.classList.remove('active'));
        });
    }
    
    // Возврат к форме входа из формы восстановления пароля
    if (backToLoginLink && loginForm) {
        backToLoginLink.addEventListener('click', function(e) {
            e.preventDefault();
            if (resetPasswordForm) resetPasswordForm.classList.remove('active');
            loginForm.classList.add('active');
            
            // Активируем вкладку входа
            if (modalTabs[0]) modalTabs[0].classList.add('active');
        });
    }
    
    // Функция закрытия модального окна
    function closeModal() {
        authModal.classList.remove('active');
        document.body.style.overflow = ''; // Восстанавливаем прокрутку страницы
        
        // Задержка перед сбросом форм
        setTimeout(() => {
            // Сброс всех форм на исходное состояние
            if (resetPasswordForm) resetPasswordForm.classList.remove('active');
            if (registerForm) registerForm.classList.remove('active');
            if (loginForm) loginForm.classList.add('active');
            
            // Сброс вкладок
            modalTabs.forEach((t, index) => {
                if (index === 0) {
                    t.classList.add('active');
                } else {
                    t.classList.remove('active');
                }
            });
            
            // Очистка полей форм
            const formInputs = authModal.querySelectorAll('input');
            formInputs.forEach(input => {
                if (input.type !== 'checkbox') {
                    input.value = '';
                } else {
                    input.checked = false;
                }
            });
        }, 300);
    }
    
    // Закрытие модального окна при нажатии Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && authModal.classList.contains('active')) {
            closeModal();
        }
    });
    
    // Переключение видимости пароля
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const passwordField = this.previousElementSibling;
            
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                this.classList.remove('fa-eye');
                this.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                this.classList.remove('fa-eye-slash');
                this.classList.add('fa-eye');
            }
        });
    });
    
    // Предотвращение отправки форм (для демонстрации)
    const authSubmitButtons = document.querySelectorAll('.auth-submit');
    authSubmitButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Здесь можно добавить валидацию форм и отправку данных на сервер
            let message = '';
            
            if (loginForm && loginForm.classList.contains('active')) {
                message = 'Виконується вхід...';
            } else if (registerForm && registerForm.classList.contains('active')) {
                message = 'Реєстрація користувача...';
            } else if (resetPasswordForm && resetPasswordForm.classList.contains('active')) {
                message = 'Відправка інструкцій для відновлення пароля...';
                
                // Имитация успешной отправки
                setTimeout(() => {
                    alert('Інструкції з відновлення пароля відправлені на вказаний email');
                    closeModal();
                }, 1000);
            }
            
            console.log(message);
        });
    });
}

// ======= ФУНКЦИИ ДЛЯ АНИМАЦИИ СКРОЛЛА =======

function initScrollAnimations() {
    // Находим все элементы для анимации, убираем исключение для latestMoviesContainer
    const animateElements = document.querySelectorAll('.animate-on-scroll:not(.section-header h2)');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
                
                // Если это контейнер с карточками
                if (entry.target.id === 'latestMoviesContainer' || 
                    entry.target.id === 'popularMoviesContainer') {
                    
                    // Находим все карточки внутри контейнера
                    let cards;
                    if (entry.target.id === 'latestMoviesContainer') {
                        cards = entry.target.querySelectorAll('.movie-card');
                    } else {
                        cards = entry.target.querySelectorAll('.popular-movie-card');
                    }
                    
                    // Анимируем каждую карточку с задержкой
                    cards.forEach((card, index) => {
                        card.style.setProperty('--card-index', index);
                    });
                }
            }
        });
    }, { 
        threshold: 0.1
    });
    
    animateElements.forEach(element => {
        observer.observe(element);
    });
    
    // Отдельно обрабатываем заголовки секций
    const sectionHeaders = document.querySelectorAll('.section-header h2');
    sectionHeaders.forEach(header => {
        header.classList.add('animate');
    });
}

// ======= ФУНКЦИИ ДЛЯ АНИМАЦИИ ЧАСТИЦ =======

function initParticlesAnimation() {
    // Анимация частиц в основном канвасе
    const canvas = document.getElementById('particles-canvas');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Установка размеров canvas
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();
    
    // Настройки частиц
    const particles = [];
    const particleCount = 150;
    const minSize = 1;
    const maxSize = 3;
    const repelRadius = 100;
    const repelForce = 0.3;
    
    // Создание частиц
    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 0.3,
            vy: (Math.random() - 0.5) * 0.3,
            size: Math.random() * (maxSize - minSize) + minSize,
            color: `hsla(${Math.random() * 30 + 30}, 80%, 75%, ${Math.random() * 0.3 + 0.2})`,
            shape: Math.floor(Math.random() * 3)
        });
    }
    
    // Обработчик движения мыши
    let mouseX = null;
    let mouseY = null;
    
    window.addEventListener('mousemove', function(e) {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });
    
    window.addEventListener('mouseout', function() {
        mouseX = null;
        mouseY = null;
    });
    
    // Анимация
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        particles.forEach(p => {
            // Отталкивание от курсора
            if (mouseX !== null && mouseY !== null) {
                const dx = p.x - mouseX;
                const dy = p.y - mouseY;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < repelRadius) {
                    const angle = Math.atan2(dy, dx);
                    const force = (repelRadius - distance) / repelRadius * repelForce;
                    
                    p.vx += Math.cos(angle) * force * 2;
                    p.vy += Math.sin(angle) * force * 2;
                }
            }
            
            // Движение частиц
            p.x += p.vx;
            p.y += p.vy;
            
            // Отражение от границ
            if (p.x < 0 || p.x > canvas.width) p.vx *= -0.8;
            if (p.y < 0 || p.y > canvas.height) p.vy *= -0.8;
            
            // Ограничение позиций
            p.x = Math.max(0, Math.min(canvas.width, p.x));
            p.y = Math.max(0, Math.min(canvas.height, p.y));
            
            // Рисование частиц
            ctx.fillStyle = p.color;
            
            switch (p.shape) {
                case 0: // Круг
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                    ctx.fill();
                    break;
                case 1: // Квадрат
                    ctx.fillRect(p.x - p.size, p.y - p.size, p.size * 2, p.size * 2);
                    break;
                case 2: // Треугольник
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y - p.size);
                    ctx.lineTo(p.x + p.size, p.y + p.size);
                    ctx.lineTo(p.x - p.size, p.y + p.size);
                    ctx.closePath();
                    ctx.fill();
                    break;
            }
        });
        
        requestAnimationFrame(animate);
    }
    
    animate();
    
    window.addEventListener('resize', function() {
        resizeCanvas();
    });
    
    // Анимация частиц в футере
    const footerCanvas = document.getElementById('footer-particles');
    if (footerCanvas) {
        const footerCtx = footerCanvas.getContext('2d');
        
        footerCanvas.width = footerCanvas.parentElement.offsetWidth;
        footerCanvas.height = footerCanvas.parentElement.offsetHeight;
        
        // Настройки частиц в футере
        const footerParticles = [];
        const footerParticleCount = 25;
        const footerParticleMaxSize = 2;
        
        // Создание частиц в футере
        for (let i = 0; i < footerParticleCount; i++) {
            footerParticles.push({
                x: Math.random() * footerCanvas.width,
                y: Math.random() * footerCanvas.height,
                size: Math.random() * footerParticleMaxSize + 0.5,
                speedX: Math.random() * 0.3 - 0.15,
                speedY: Math.random() * 0.3 - 0.15,
                opacity: Math.random() * 0.3 + 0.1
            });
        }
        
        // Анимация частиц в футере
        function animateFooterParticles() {
            footerCtx.clearRect(0, 0, footerCanvas.width, footerCanvas.height);
            
            footerParticles.forEach(particle => {
                // Обновление позиции
                particle.x += particle.speedX;
                particle.y += particle.speedY;
                
                // Проверка границ
                if (particle.x < 0 || particle.x > footerCanvas.width) {
                    particle.speedX = -particle.speedX;
                }
                if (particle.y < 0 || particle.y > footerCanvas.height) {
                    particle.speedY = -particle.speedY;
                }
                
                // Отрисовка частицы
                footerCtx.beginPath();
                footerCtx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
                footerCtx.fillStyle = `rgba(245, 197, 6, ${particle.opacity})`;
                footerCtx.fill();
            });
            
            requestAnimationFrame(animateFooterParticles);
        }
        
        // Запуск анимации в футере
        animateFooterParticles();
        
        // Обновление размера канваса при изменении размера окна
        window.addEventListener('resize', () => {
            footerCanvas.width = footerCanvas.parentElement.offsetWidth;
            footerCanvas.height = footerCanvas.parentElement.offsetHeight;
        });
    }
} 