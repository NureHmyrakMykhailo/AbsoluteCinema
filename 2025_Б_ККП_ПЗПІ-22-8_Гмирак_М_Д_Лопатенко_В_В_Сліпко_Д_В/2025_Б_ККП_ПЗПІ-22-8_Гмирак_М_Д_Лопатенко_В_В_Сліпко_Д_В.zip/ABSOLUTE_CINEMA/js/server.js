// Обрабатываем статические файлы
app.use(express.static(path.join(__dirname))); 