// Функция для загрузки новинок
async function loadLatestMovies() {
    try {
        const response = await fetch('/api/latest-movies');
        if (!response.ok) {
            throw new Error('Не удалось загрузить новинки');
        }

        const data = await response.json();
        const movies = data.movies || [];

        // Получаем контейнер для новинок
        const latestMoviesTrack = document.getElementById('latestMoviesTrack');
        if (!latestMoviesTrack) return;

        // Очищаем контейнер
        latestMoviesTrack.innerHTML = '';

        // Добавляем фильмы в контейнер
        movies.forEach((movie, index) => {
            const movieCard = document.createElement('div');
            movieCard.className = 'movie-card';
            movieCard.setAttribute('data-index', index);

            // Форматируем дату релиза
            const releaseDate = movie.release_date ? new Date(movie.release_date) : null;
            const releaseYear = releaseDate ? releaseDate.getFullYear() : '';

            // Форматируем рейтинг IMDB
            const imdbRating = `<div class="movie-rating"><span class="star">★</span> ${movie.imdb_rating ? movie.imdb_rating : '?'} /10</div>`;

            movieCard.innerHTML = `
                <div class="movie-poster">
                    <img src="${movie.poster_url || 'https://via.placeholder.com/150x225?text=Немає+постера'}" alt="${movie.title}">
                    <div class="watch-overlay">
                        <button class="watch-button" style="background-color: #f4ff60; color: #000000;">Детальніше</button>
                    </div>
                </div>
                <div class="movie-info">
                    <h3 title="${movie.title}">${movie.title}</h3>
                    ${imdbRating}
                    <div class="movie-genres">${releaseYear}</div>
                </div>
            `;

            // Добавляем обработчик клика для просмотра фильма
            const watchButton = movieCard.querySelector('.watch-button');
            watchButton.addEventListener('click', () => {
                window.location.href = `/movie/${movie.id}`;
            });

            latestMoviesTrack.appendChild(movieCard);
        });

        // Вызываем инициализацию карусели если есть фильмы
        try {
            if (typeof window.initLatestMoviesCarousel === 'function' && movies.length > 0) {
                window.initLatestMoviesCarousel();
            }
        } catch (carouselError) {
            console.error('Ошибка инициализации карусели:', carouselError);
        }
    } catch (error) {
        console.error('Ошибка при загрузке новинок:', error);
        const latestMoviesTrack = document.getElementById('latestMoviesTrack');
        if (latestMoviesTrack) {
            latestMoviesTrack.innerHTML = `
                <div class="error-container">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>Помилка при завантаженні новинок: ${error.message}</p>
                </div>
            `;
        }
    }
}

// Загружаем новинки при загрузке страницы
document.addEventListener('DOMContentLoaded', loadLatestMovies);

// Удаляем эту заглушку, чтобы не конфликтовала с основной функцией в script.js
// function initLatestMoviesCarousel() {} 