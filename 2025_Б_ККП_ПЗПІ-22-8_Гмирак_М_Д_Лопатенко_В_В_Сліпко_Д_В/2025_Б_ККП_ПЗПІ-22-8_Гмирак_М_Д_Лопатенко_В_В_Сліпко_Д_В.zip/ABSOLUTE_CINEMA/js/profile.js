/* profile.js - Скрипты для страницы профиля ABSOLUTE CINEMA */

// Класс для управления страницей профиля
class ProfileManager {
  constructor() {
    // Основные элементы профиля
    this.avatar = document.getElementById('profile-avatar-img');
    this.username = document.getElementById('profile-username');
    this.joinDate = document.getElementById('profile-join-date');
    this.bio = document.getElementById('profile-bio');
    this.socialLinks = document.getElementById('social-links');
    
    // Счетчики статистики
    this.reviewsCount = document.getElementById('reviews-count');
    this.favoritesCount = document.getElementById('favorites-count');
    this.commentsCount = document.getElementById('comments-count');
    
    // Вкладки профиля
    this.tabs = document.querySelectorAll('.profile-tabs .tab');
    this.tabContents = document.querySelectorAll('.tab-content');
    
    // Модальное окно редактирования
    this.editProfileModal = document.getElementById('edit-profile-modal');
    this.editAvatarBtn = document.getElementById('edit-avatar-btn');
    this.editProfileBtn = document.getElementById('edit-profile-btn');
    
    // Поля формы редактирования
    this.editUsernameInput = document.getElementById('edit-username');
    this.editBioInput = document.getElementById('edit-bio');
    this.socialInputs = {
      imdb: document.getElementById('imdb-link'),
      instagram: document.getElementById('instagram-link'),
      twitter: document.getElementById('twitter-link'),
      letterboxd: document.getElementById('letterboxd-link')
    };
    
    // Данные профиля
    this.profileData = null;
    
    // Инициализация
    this.init();
  }
  
  // Инициализация страницы профиля
  async init() {
    try {
      console.log('Инициализация профиля пользователя...');
      
      document.body.classList.add('loading');
      
      // Загружаем хедер (компонент)
      console.log('Загрузка хедера для профиля...');
      await this.loadHeader();
      
      // Получаем id пользователя из URL
      const params = new URLSearchParams(window.location.search);
      const profileUserId = params.get('id');
      this.profileUserId = profileUserId;
      
      // Загружаем данные профиля
      console.log('Загрузка данных профиля...');
      const profileData = await this.loadProfileData();
      
      if (!profileData) {
        console.error('Данные профиля не загружены');
        this.showNotification('Не вдалося завантажити дані профілю. Спробуйте оновити сторінку.', 'error');
      }
      
      // Настройка обработчиков событий
      console.log('Настройка обработчиков событий...');
      this.setupEventListeners();
      
      // По умолчанию активна первая вкладка
      console.log('Активация первой вкладки...');
      this.tabs[0].click();
      
      document.body.classList.remove('loading');
      console.log('Инициализация профиля завершена');
    } catch (error) {
      console.error('Критическая ошибка при инициализации профиля:', error);
      this.showNotification('Критична помилка при завантаженні профілю: ' + error.message, 'error');
      document.body.classList.remove('loading');
    }
  }
  
  // Загрузка хедера
  async loadHeader() {
    try {
      const headerContainer = document.getElementById('header-container');
      if (!headerContainer) {
        console.error('Контейнер хедера не найден');
        return;
      }
      
      // Используем функцию из компонентов
      if (typeof window.loadHeader === 'function') {
        console.log('Вызов функции loadHeader из компонентов...');
        await window.loadHeader();
        console.log('Хедер успешно загружен');
      } else {
        console.warn('Функция загрузки хедера не найдена, создаю базовый хедер');
        
        // Резервный вариант - создаем простой хедер с навигацией к главной
        headerContainer.innerHTML = `
          <header id="main-header">
            <div class="header-container">
              <div class="logo">
                <a href="/" id="logo-link">ABSOLUTE CINEMA</a>
              </div>
              <nav class="main-nav">
                <ul>
                  <li><a href="/" class="nav-link"><i class="fas fa-home"></i>ГОЛОВНА</a></li>
                  <li><a href="/movies" class="nav-link"><i class="fas fa-film"></i>ФІЛЬМИ</a></li>
                  <li><a href="/series" class="nav-link"><i class="fas fa-tv"></i>СЕРІАЛИ</a></li>
                  <li><a href="/discussions" class="nav-link"><i class="fas fa-comments"></i>ЧАТИ</a></li>
                  <li><a href="/ratings" class="nav-link"><i class="fas fa-star"></i>РЕЙТИНГИ</a></li>
                </ul>
              </nav>
              <div class="header-controls">
                <div class="login-button">
                  <a href="/" id="profile-link">ПОВЕРНУТИСЯ НА ГОЛОВНУ</a>
                </div>
              </div>
            </div>
          </header>
        `;
      }
    } catch (error) {
      console.error('Ошибка при загрузке хедера для профиля:', error);
      throw new Error('Не вдалося завантажити хедер: ' + error.message);
    }
  }
  
  // Загрузка данных профиля с сервера
  async loadProfileData() {
    try {
      console.log('Начинаю загрузку данных профиля...');
      
      // Добавляем задержку для завершения загрузки хедера и других компонентов
      await new Promise(resolve => setTimeout(resolve, 300));
      
      let url = '/api/profile';
      if (this.profileUserId) {
        url = `/api/users/${this.profileUserId}`;
      }
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Cache-Control': 'no-cache'
        },
        credentials: 'include'
      });
      
      console.log('Получен ответ от API:', response.status, response.statusText);
      
      if (!response.ok) {
        console.error('Ошибка при загрузке профиля. Статус:', response.status);
        let errorMessage = 'Не удалось загрузить данные профиля';
        
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorMessage;
        } catch (e) {
          console.error('Не удалось прочитать ответ от сервера:', e);
        }
        
        throw new Error(errorMessage);
      }
      
      let data;
      try {
        data = await response.json();
        console.log('Получены данные профиля:', data);
      } catch (e) {
        console.error('Ошибка при разборе JSON:', e);
        throw new Error('Неверный формат данных профиля');
      }
      
      // Проверка наличия профиля
      if (!data.profile) {
        console.error('Профиль не найден в ответе API');
        // Создание базовой структуры для отображения
        data = {
          profile: {
            username: 'Невідомий користувач',
            created_at: new Date().toISOString(),
            bio: 'Інформація відсутня',
            social_links: {}
          },
          stats: {
            reviews: 0,
            favorites: 0,
            comments: 0
          }
        };
        
        this.showNotification('Профіль користувача не знайдено. Відображаються базові дані.', 'warning');
      }
      
      this.profileData = data;
      
      // Отображаем данные на странице
      this.renderProfileData();
      
      return data;
    } catch (error) {
      console.error('Ошибка при загрузке данных профиля:', error);
      this.showNotification('Не удалось загрузить данные профиля: ' + error.message, 'error');
      
      // Перенаправляем на страницу входа, если пользователь не авторизован
      if (error.message.includes('не авторизован') || error.message.includes('unauthorized')) {
        console.log('Перенаправление на страницу входа из-за отсутствия авторизации');
        window.location.href = '/login';
        return null;
      }
      
      // Создаем базовый профиль для аварийного отображения
      this.profileData = {
        profile: {
          username: 'Помилка завантаження',
          created_at: new Date().toISOString(),
          bio: 'Не вдалося завантажити дані профілю. Спробуйте оновити сторінку.',
          social_links: {}
        },
        stats: {
          reviews: 0,
          favorites: 0,
          comments: 0
        }
      };
      
      // Отображаем доступные данные
      this.renderProfileData();
      
      return null;
    }
  }
  
  // Отображение данных профиля на странице
  renderProfileData() {
    if (!this.profileData || !this.profileData.profile) {
      this.showNotification('Данные профиля отсутствуют', 'warning');
      return;
    }
    
    const { profile, stats } = this.profileData;
    
    // Основная информация
    this.username.textContent = profile.username || 'Нет имени';
    
    // Аватар
    if (profile.avatar_url) {
      this.avatar.src = profile.avatar_url;
    } else {
      // Стандартный аватар, если нет загруженного
      this.avatar.src = 'https://via.placeholder.com/150?text=' + profile.username.charAt(0).toUpperCase();
    }
    
    // Дата регистрации
    const createdDate = new Date(profile.created_at);
    const dateOptions = { day: 'numeric', month: 'long', year: 'numeric' };
    this.joinDate.innerHTML = `На сайті з: <span>${createdDate.toLocaleDateString('uk-UA', dateOptions)}</span>`;
    
    // Биография
    if (profile.bio) {
      this.bio.textContent = profile.bio;
    } else {
      this.bio.textContent = 'Інформація відсутня';
      this.bio.classList.add('empty-bio');
    }
    
    // Социальные сети
    this.renderSocialLinks(profile.social_links);
    
    // Статистика
    if (stats) {
      this.reviewsCount.textContent = stats.reviews;
      this.favoritesCount.textContent = stats.favorites;
      this.commentsCount.textContent = stats.comments;
    }
    
    // Заполняем форму редактирования текущими данными
    this.populateEditForm(profile);

    // Скрываем кнопку редактирования, если это не ваш профиль
    let isOwnProfile = true;
    if (this.profileUserId && window.authManager && window.authManager.currentUser) {
      isOwnProfile = (window.authManager.currentUser.user_id == this.profileUserId);
    } else if (this.profileUserId) {
      isOwnProfile = false;
    }
    if (this.editProfileBtn) {
      this.editProfileBtn.style.display = isOwnProfile ? '' : 'none';
    }
    if (this.editAvatarBtn) {
      this.editAvatarBtn.style.display = isOwnProfile ? '' : 'none';
    }
    // Скрываем вкладку "Обране" для чужих профилей
    const favoritesTab = document.querySelector('.profile-tabs .tab[data-tab="favorites"]');
    const favoritesContent = document.getElementById('favorites-tab');
    if (favoritesTab && favoritesContent) {
      if (!isOwnProfile) {
        favoritesTab.style.display = 'none';
        favoritesContent.style.display = 'none';
      } else {
        favoritesTab.style.display = '';
        // Не активируем вкладку, просто показываем если свой профиль
      }
    }

    // Кнопка 'Написати' для чужого профиля
    let writeBtn = document.getElementById('write-message-btn');
    if (!isOwnProfile) {
      if (!writeBtn) {
        writeBtn = document.createElement('button');
        writeBtn.className = 'write-message-btn';
        writeBtn.id = 'write-message-btn';
        writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
        const actions = document.querySelector('.profile-actions');
        if (actions) actions.appendChild(writeBtn);
      }
      // Сброс состояния кнопки всегда при рендере
      writeBtn.style.display = '';
      writeBtn.disabled = false;
      writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
      writeBtn.onclick = async () => {
        try {
          writeBtn.disabled = true;
          writeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Зачекайте...';
          const response = await fetch('/api/chats', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: this.profileUserId })
          });
          const data = await response.json();
          if (response.ok && data.chat && data.chat.id) {
            window.location.href = '/chats.html?chat=' + data.chat.id;
          } else {
            alert('Не вдалося створити або знайти чат: ' + (data.error || 'Невідома помилка'));
            writeBtn.disabled = false;
            writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
          }
        } catch (e) {
          alert('Сталася помилка: ' + e.message);
          writeBtn.disabled = false;
          writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
        }
      };
    } else if (writeBtn) {
      writeBtn.style.display = 'none';
      writeBtn.disabled = false;
      writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
    }
  }
  
  // Отображение социальных ссылок
  renderSocialLinks(socialLinks) {
    // Очищаем контейнер
    this.socialLinks.innerHTML = '';
    
    if (!socialLinks || Object.keys(socialLinks).length === 0) {
      const noLinks = document.createElement('div');
      noLinks.className = 'no-social-links';
      noLinks.textContent = 'Соціальні мережі не додані';
      this.socialLinks.appendChild(noLinks);
      return;
    }
    
    // Создаем ссылки для каждой социальной сети
    for (const [network, url] of Object.entries(socialLinks)) {
      if (!url) continue;
      
      const link = document.createElement('a');
      // Убедимся, что URL начинается с http:// или https://
      const fullUrl = url.startsWith('http://') || url.startsWith('https://') ? url : `https://${url}`;
      link.href = fullUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.className = `social-link ${network}`;
      
      // Определяем иконку
      let icon;
      let networkName;
      
      switch (network) {
        case 'imdb':
          icon = 'fa-imdb';
          networkName = 'IMDb';
          break;
        case 'instagram':
          icon = 'fa-instagram';
          networkName = 'Instagram';
          break;
        case 'twitter':
          icon = 'fa-twitter';
          networkName = 'Twitter';
          break;
        case 'letterboxd':
          icon = 'fa-letterboxd';
          networkName = 'Letterboxd';
          break;
        default:
          icon = 'fa-link';
          networkName = network.charAt(0).toUpperCase() + network.slice(1);
      }
      
      link.innerHTML = `<i class="fab ${icon}"></i> ${networkName}`;
      this.socialLinks.appendChild(link);
    }
  }
  
  // Заполнение формы редактирования профиля текущими данными
  populateEditForm(profile) {
    this.editUsernameInput.value = profile.username || '';
    this.editBioInput.value = profile.bio || '';
    
    // Заполняем социальные ссылки
    const socialLinks = profile.social_links || {};
    
    for (const [network, input] of Object.entries(this.socialInputs)) {
      input.value = socialLinks[network] || '';
    }
  }
  
  // Обработка отправки формы редактирования профиля
  async handleProfileUpdate(e) {
    e.preventDefault();
    
    try {
      // Собираем данные формы
      const username = this.editUsernameInput.value.trim();
      const bio = this.editBioInput.value.trim();
      
      // Проверяем имя пользователя
      if (!username) {
        throw new Error('Ім\'я користувача не може бути порожнім');
      }
      
      // Собираем социальные ссылки
      const socialLinks = {};
      for (const [network, input] of Object.entries(this.socialInputs)) {
        const value = input.value.trim();
        if (value) {
          socialLinks[network] = value;
        }
      }
      
      // Отправляем запрос на обновление
      const response = await fetch('/api/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          username,
          bio,
          social_links: socialLinks
        }),
        credentials: 'include'
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Не удалось обновить профиль');
      }
      
      const data = await response.json();
      
      // Обновляем данные профиля и перерисовываем страницу
      if (this.profileData) {
        this.profileData.profile = data.profile;
        this.renderProfileData();
      }
      
      // Закрываем модальное окно
      this.closeEditModal();
      
      // Показываем уведомление об успешном обновлении
      this.showNotification('Профіль успішно оновлено', 'success');
    } catch (error) {
      console.error('Ошибка при обновлении профиля:', error);
      this.showFormError(error.message);
    }
  }
  
  // Обработка загрузки нового аватара
  async handleAvatarUpdate() {
    try {
      // Здесь будет код для загрузки аватара (требуется дополнительная логика для загрузки файлов)
      // В простейшем случае можем использовать URL
      const avatarUrl = prompt('Введіть URL зображення для аватара:', this.profileData?.profile?.avatar_url || '');
      
      if (!avatarUrl) return;
      
      // Отправляем запрос на обновление аватара
      const response = await fetch('/api/profile/avatar', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          avatar_url: avatarUrl
        }),
        credentials: 'include'
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Не удалось обновить аватар');
      }
      
      const data = await response.json();
      
      // Обновляем данные профиля и перерисовываем страницу
      if (this.profileData) {
        this.profileData.profile = data.profile;
        this.renderProfileData();
      }
      
      // Показываем уведомление об успешном обновлении
      this.showNotification('Аватар успішно оновлено', 'success');
    } catch (error) {
      console.error('Ошибка при обновлении аватара:', error);
      this.showNotification(error.message, 'error');
    }
  }
  
  // Настройка обработчиков событий
  setupEventListeners() {
    // Переключение вкладок
    this.tabs.forEach(tab => {
      tab.addEventListener('click', () => this.switchTab(tab));
    });
    
    // Открытие модального окна редактирования профиля
    if (this.editProfileBtn) {
      this.editProfileBtn.addEventListener('click', () => this.openEditModal());
    }
    
    // Закрытие модального окна
    const closeModalBtn = this.editProfileModal?.querySelector('.modal-close');
    const modalOverlay = this.editProfileModal?.querySelector('.modal-overlay');
    
    if (closeModalBtn) {
      closeModalBtn.addEventListener('click', () => this.closeEditModal());
    }
    
    if (modalOverlay) {
      modalOverlay.addEventListener('click', () => this.closeEditModal());
    }
    
    // Отправка формы редактирования профиля
    const editProfileForm = document.getElementById('edit-profile-form');
    if (editProfileForm) {
      editProfileForm.addEventListener('submit', (e) => this.handleProfileUpdate(e));
    }
    
    // Обработка загрузки аватара
    if (this.editAvatarBtn) {
      this.editAvatarBtn.addEventListener('click', () => this.handleAvatarUpdate());
    }
    
    // Предзагрузка данных для вкладок при переключении
    if (this.tabs) {
      this.tabs.forEach(tab => {
        tab.addEventListener('click', () => {
          const tabName = tab.getAttribute('data-tab');
          switch (tabName) {
            case 'reviews':
              this.loadUserReviews();
              break;
            case 'favorites':
              this.loadUserFavorites();
              break;
          }
        });
      });
    }
  }
  
  // Переключение между вкладками
  switchTab(selectedTab) {
    // Получаем имя вкладки
    const tabName = selectedTab.getAttribute('data-tab');
    
    // Убираем активный класс у всех вкладок
    this.tabs.forEach(tab => tab.classList.remove('active'));
    
    // Добавляем активный класс выбранной вкладке
    selectedTab.classList.add('active');
    
    // Скрываем все содержимое вкладок
    this.tabContents.forEach(content => content.classList.remove('active'));
    
    // Показываем содержимое выбранной вкладки
    const selectedContent = document.getElementById(`${tabName}-tab`);
    if (selectedContent) {
      selectedContent.classList.add('active');
    }
  }
  
  // Открытие модального окна редактирования профиля
  openEditModal() {
    try {
      if (this.editProfileModal) {
        // Сначала убедимся, что форма заполнена актуальными данными
        if (this.profileData && this.profileData.profile) {
          this.populateEditForm(this.profileData.profile);
        }
        
        // Блокируем прокрутку body
        document.body.classList.add('modal-open');
        
        // Отображаем модальное окно
        this.editProfileModal.classList.add('active');
        
        console.log('Модальное окно редактирования профиля открыто');
      } else {
        console.error('Модальное окно не найдено');
      }
    } catch (error) {
      console.error('Ошибка при открытии модального окна:', error);
    }
  }
  
  // Закрытие модального окна редактирования профиля
  closeEditModal() {
    try {
      if (this.editProfileModal) {
        // Скрываем модальное окно
        this.editProfileModal.classList.remove('active');
        
        // Разблокируем прокрутку body
        document.body.classList.remove('modal-open');
        
        // Удаляем сообщение об ошибке, если оно есть
        const errorMessage = this.editProfileModal.querySelector('.form-error');
        if (errorMessage) {
          errorMessage.remove();
        }
        
        console.log('Модальное окно редактирования профиля закрыто');
      }
    } catch (error) {
      console.error('Ошибка при закрытии модального окна:', error);
    }
  }
  
  // Отображение ошибки формы
  showFormError(errorMessage) {
    const form = document.getElementById('edit-profile-form');
    if (!form) return;
    
    // Удаляем предыдущее сообщение об ошибке, если оно есть
    const existingError = form.querySelector('.form-error');
    if (existingError) {
      existingError.remove();
    }
    
    // Создаем элемент для отображения ошибки
    const errorElement = document.createElement('div');
    errorElement.className = 'form-error';
    errorElement.textContent = errorMessage;
    
    // Вставляем сообщение об ошибке перед кнопкой отправки
    const submitButton = form.querySelector('.save-profile-btn');
    form.insertBefore(errorElement, submitButton);
  }
  
  // Отображение уведомления
  showNotification(message, type = 'info') {
    // Удаляем предыдущее уведомление, если оно есть
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
      existingNotification.remove();
    }
    
    // Создаем элемент уведомления
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    // Добавляем иконку в зависимости от типа уведомления
    let icon = '';
    switch (type) {
      case 'success':
        icon = '<i class="fas fa-check-circle"></i>';
        break;
      case 'error':
        icon = '<i class="fas fa-exclamation-circle"></i>';
        break;
      case 'warning':
        icon = '<i class="fas fa-exclamation-triangle"></i>';
        break;
      default:
        icon = '<i class="fas fa-info-circle"></i>';
    }
    
    // Формируем содержимое уведомления
    notification.innerHTML = `
      ${icon}
      <span>${message}</span>
      <button class="notification-close"><i class="fas fa-times"></i></button>
    `;
    
    // Добавляем уведомление на страницу
    document.body.appendChild(notification);
    
    // Добавляем обработчик закрытия уведомления
    const closeButton = notification.querySelector('.notification-close');
    if (closeButton) {
      closeButton.addEventListener('click', () => {
        notification.classList.add('closing');
        setTimeout(() => {
          notification.remove();
        }, 300);
      });
    }
    
    // Автоматическое скрытие уведомления через 5 секунд
    setTimeout(() => {
      if (document.body.contains(notification)) {
        notification.classList.add('closing');
        setTimeout(() => {
          if (document.body.contains(notification)) {
            notification.remove();
          }
        }, 300);
      }
    }, 5000);
  }
  
  // Загрузка рецензий пользователя
  async loadUserReviews() {
    const reviewsList = document.getElementById('reviews-list');
    if (!reviewsList) return;
    
    try {
      // Показываем анимацию загрузки
      reviewsList.innerHTML = `
        <div class="loading-container">
          <i class="fas fa-spinner fa-spin"></i>
          <p>Завантаження рецензій...</p>
        </div>
      `;
      
      // Получаем ID пользователя из данных профиля
      if (!this.profileData || !this.profileData.profile) {
        await this.loadProfileData();
      }
      
      const userId = this.profileData?.profile?.user_id;
      if (!userId) {
        throw new Error('Данные пользователя не знайдені');
      }
      
      // Определяем, свой ли это профиль
      let isOwnProfile = true;
      if (this.profileUserId && window.authManager && window.authManager.currentUser) {
        isOwnProfile = (window.authManager.currentUser.user_id == this.profileUserId);
      } else if (this.profileUserId) {
        isOwnProfile = false;
      }
      
      // Запрашиваем список рецензій пользователя
      const response = await fetch(`/api/reviews/user/${userId}`, {
        method: 'GET',
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Не удалось загрузить рецензії');
      }
      
      const data = await response.json();
      const reviews = data.reviews || [];
      
      // Если список пуст, показываем соответствующее сообщение
      if (reviews.length === 0) {
        reviewsList.innerHTML = '<div class="empty-content">У вас поки немає рецензій</div>';
        return;
      }
      
      // Формируем HTML с рецензіями
      let reviewsHTML = '';
      for (const review of reviews) {
        // Обрезаем длинные рецензии и добавляем кнопку 'Дивитись повністю', полный текст и короткий текст в data-атрибутах
        const maxLength = 350;
        let isLong = review.content.length > maxLength;
        let shortText = isLong ? review.content.slice(0, maxLength) + '…' : review.content;
        let reviewTextHtml = `<p class="review-text" data-full-text="${encodeURIComponent(review.content)}" data-short-text="${encodeURIComponent(shortText)}">${shortText}</p>`;
        if (isLong) {
          reviewTextHtml += `<button class="show-full-review-btn toggle-review-btn">Дивитись повністю...</button>`;
        }
        reviewsHTML += `
          <div class="review-item">
            <div class="review-media">
              <a href="/movie/${review.media?.id || ''}">
                <img src="${review.media?.poster_url || 'https://via.placeholder.com/150x225?text=Немає+постера'}" alt="${review.media?.title || 'Фільм'}">
              </a>
              <div class="review-rating">${review.rating.toFixed(1)}</div>
            </div>
            <div class="review-content">
              ${isOwnProfile ? `<button class="delete-review-btn" data-id="${review.id}" style="background:#c0392b; color:#fff; border:none; border-radius:6px; padding:10px 16px; cursor:pointer; font-size:22px; display:inline-flex; align-items:center; justify-content:center; position:absolute; top:12px; right:16px; z-index:2;"><i class="fas fa-trash"></i></button>` : ''}
              <h3 class="review-title">
                <a href="/movie/${review.media?.id || ''}">${review.media?.title || 'Фільм видалено'}</a>
                <span class="review-year">${review.media?.release_date ? new Date(review.media.release_date).getFullYear() : ''}</span>
              </h3>
              <div class="review-date">${new Date(review.created_at).toLocaleDateString('uk-UA')}</div>
              ${reviewTextHtml}
            </div>
          </div>
        `;
      }
      
      reviewsList.innerHTML = reviewsHTML;
      // Добавляю обработчик для показа/сворачивания полного текста рецензии
      const showFullBtns = reviewsList.querySelectorAll('.show-full-review-btn');
      showFullBtns.forEach((btn) => {
        btn.addEventListener('click', function() {
          const reviewText = btn.closest('.review-content').querySelector('.review-text');
          const isExpanded = reviewText.classList.contains('expanded-review');
          if (!isExpanded) {
            // Раскрываем
            const fullText = decodeURIComponent(reviewText.getAttribute('data-full-text'));
            reviewText.textContent = fullText;
            reviewText.classList.add('expanded-review');
            btn.textContent = 'Приховати...';
            const reviewContent = reviewText.parentElement;
            const reviewItem = reviewText.closest('.review-item');
            if (reviewContent) reviewContent.classList.add('expanded-review');
            if (reviewItem) reviewItem.classList.add('expanded-review');
          } else {
            // Сворачиваем
            const shortText = decodeURIComponent(reviewText.getAttribute('data-short-text'));
            reviewText.textContent = shortText;
            reviewText.classList.remove('expanded-review');
            btn.textContent = 'Дивитись повністю...';
            const reviewContent = reviewText.parentElement;
            const reviewItem = reviewText.closest('.review-item');
            if (reviewContent) reviewContent.classList.remove('expanded-review');
            if (reviewItem) reviewItem.classList.remove('expanded-review');
          }
          // Перемещаем кнопку после текста
          reviewText.after(btn);
        });
      });
      // Добавляю обработчик для удаления рецензии
      const deleteButtons = reviewsList.querySelectorAll('.delete-review-btn');
      deleteButtons.forEach(button => {
        button.addEventListener('click', async () => {
          const reviewId = button.getAttribute('data-id');
          if (confirm('Ви дійсно хочете видалити цю рецензію?')) {
            await window.profileManager.deleteUserReview(reviewId, button);
          }
        });
      });
    } catch (error) {
      console.error('Ошибка при загрузке рецензий:', error);
      reviewsList.innerHTML = `
        <div class="error-container">
          <i class="fas fa-exclamation-circle"></i>
          <p>Помилка при завантаженні рецензій: ${error.message}</p>
        </div>
      `;
    }
  }
  
  // Загрузка избранного пользователя
  async loadUserFavorites() {
    const favoritesList = document.getElementById('favorites-list');
    if (!favoritesList) return;
    
    try {
      // Показываем анимацию загрузки
      favoritesList.innerHTML = `
        <div class="loading-container">
          <i class="fas fa-spinner fa-spin"></i>
          <p>Завантаження обраного...</p>
        </div>
      `;
      
      // Получаем ID пользователя из данных профиля
      if (!this.profileData || !this.profileData.profile) {
        await this.loadProfileData();
      }
      
      const userId = this.profileData?.profile?.user_id;
      if (!userId) {
        throw new Error('Данные пользователя не найдены');
      }
      
      // Запрашиваем список избранного пользователя
      const response = await fetch(`/api/favorites/user/${userId}`, {
        method: 'GET',
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Не удалось загрузить избранное');
      }
      
      const data = await response.json();
      const favorites = data.favorites || [];
      
      // Если список пуст, показываем соответствующее сообщение
      if (favorites.length === 0) {
        favoritesList.innerHTML = '<div class="empty-content">У вас поки немає обраних фільмів</div>';
        return;
      }
      
      // Формируем HTML с избранным
      let favoritesHTML = '<div class="favorites-grid">';
      
      for (const favorite of favorites) {
        favoritesHTML += `
          <div class="favorite-item" data-favorite-id="${favorite.favorites_id}" style="position:relative;">
            <div class="favorite-poster" data-movie-id="${favorite.media.id}" style="cursor:pointer;">
              <img src="${favorite.media.poster_url}" alt="${favorite.media.title}">
            </div>
            <div class="favorite-info">
              <h3 data-movie-id="${favorite.media.id}" style="cursor:pointer;">${favorite.media.title}</h3>
              <p>Рейтинг: ${favorite.media.imdb_rating || 'Н/Д'}</p>
            </div>
            <button class="favorite-delete-icon-btn" data-favorite-id="${favorite.favorites_id}" title="Видалити з обраного">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        `;
      }
      
      favoritesHTML += '</div>';
      favoritesList.innerHTML = favoritesHTML;
      // Добавляем обработчики для кнопок удаления из избранного
      const removeButtons = favoritesList.querySelectorAll('.favorite-delete-icon-btn');
      removeButtons.forEach(button => {
        button.addEventListener('click', async () => {
          const favoriteId = button.getAttribute('data-favorite-id');
          await this.removeFavorite(favoriteId, button);
        });
      });
      // Добавляю обработчики перехода на страницу фильма
      const posterLinks = favoritesList.querySelectorAll('.favorite-poster, .favorite-info h3');
      posterLinks.forEach(el => {
        el.addEventListener('click', function() {
          const movieId = el.getAttribute('data-movie-id');
          if (movieId) {
            window.location.href = `/movie/${movieId}`;
          }
        });
      });
    } catch (error) {
      console.error('Ошибка при загрузке избранного:', error);
      favoritesList.innerHTML = `
        <div class="error-container">
          <i class="fas fa-exclamation-circle"></i>
          <p>Помилка при завантаженні обраного: ${error.message}</p>
        </div>
      `;
    }
  }
  
  // Метод для удаления фильма из избранного
  async removeFavorite(favoriteId, buttonElement) {
    try {
      // Изменяем текст кнопки и делаем ее неактивной
      const originalText = buttonElement.innerHTML;
      buttonElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Видаляю...';
      buttonElement.disabled = true;
      
      const response = await fetch(`/api/favorites/${favoriteId}`, {
        method: 'DELETE',
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Не удалось удалить из избранного');
      }
      
      // Если удаление прошло успешно, обновляем UI
      buttonElement.closest('.favorite-item').remove();
      
      // Обновляем счетчик избранного
      const count = parseInt(this.favoritesCount.textContent) - 1;
      this.favoritesCount.textContent = count >= 0 ? count : 0;
      
      // Если после удаления элементов не осталось, показываем сообщение
      const favoritesGrid = document.querySelector('.favorites-grid');
      if (favoritesGrid && favoritesGrid.children.length === 0) {
        document.getElementById('favorites-list').innerHTML = '<div class="empty-content">У вас поки немає обраних фільмів</div>';
      }
      
      // Показываем уведомление
      this.showNotification('Фільм видалено з обраного', 'success');
    } catch (error) {
      console.error('Ошибка при удалении из избранного:', error);
      // Восстанавливаем состояние кнопки
      buttonElement.innerHTML = originalText;
      buttonElement.disabled = false;
      
      this.showNotification('Помилка при видаленні з обраного: ' + error.message, 'error');
    }
  }
  
  // Добавляю метод для удаления рецензии пользователя
  deleteUserReview = async function(reviewId, buttonElement) {
    try {
      buttonElement.disabled = true;
      buttonElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Видаляю...';
      const response = await fetch(`/api/reviews/${reviewId}`, {
        method: 'DELETE',
        credentials: 'include'
      });
      if (!response.ok) {
        throw new Error('Не вдалося видалити рецензію');
      }
      // Удаляем элемент из DOM
      buttonElement.closest('.review-item').remove();
      this.showNotification('Рецензію видалено', 'success');
    } catch (error) {
      buttonElement.disabled = false;
      buttonElement.innerHTML = '<i class="fas fa-trash"></i> Видалити рецензію';
      this.showNotification('Помилка при видаленні рецензії: ' + error.message, 'error');
    }
  };
}

// Инициализация менеджера профиля при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
  const profileManager = new ProfileManager();
  
  // Экспортируем экземпляр для использования в других модулях
  window.profileManager = profileManager;
});

async function removeFromFavorites(favoriteId) {
  try {
    const response = await fetch(`/api/favorites/${favoriteId}`, {
      method: 'DELETE',
      credentials: 'include'
    });

    if (!response.ok) {
      throw new Error('Ошибка при удалении из избранного');
    }

    // Удаляем элемент из DOM
    const favoriteItem = document.querySelector(`[data-favorite-id="${favoriteId}"]`);
    if (favoriteItem) {
      favoriteItem.remove();
    }

    // Проверяем, остались ли еще избранные фильмы
    const favoritesGrid = document.querySelector('.favorites-grid');
    if (favoritesGrid && favoritesGrid.children.length === 0) {
      document.getElementById('favorites-list').innerHTML = 
        '<p>У вас пока нет избранных фильмов</p>';
    }
  } catch (error) {
    console.error('Ошибка:', error);
    alert('Не удалось удалить из избранного');
  }
}

// Сброс состояния кнопки 'Написати' при возврате назад (bfcache/pageshow)
window.addEventListener('pageshow', function() {
  const writeBtn = document.getElementById('write-message-btn');
  const params = new URLSearchParams(window.location.search);
  const profileUserId = params.get('id');
  const currentUser = window.authManager?.currentUser;
  if (writeBtn && profileUserId && currentUser && currentUser.user_id != profileUserId) {
    writeBtn.disabled = false;
    writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
  }
}); 