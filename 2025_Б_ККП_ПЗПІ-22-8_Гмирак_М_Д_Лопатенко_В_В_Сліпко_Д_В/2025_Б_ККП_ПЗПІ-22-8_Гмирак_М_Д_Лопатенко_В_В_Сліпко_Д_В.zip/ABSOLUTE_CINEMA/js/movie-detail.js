// movie-detail.js - скрипт для страницы с детальной информацией о фильме

function getMovieIdFromUrl() {
    const pathParts = window.location.pathname.split('/');
    return pathParts[pathParts.length - 1];
}

function formatDate(dateString) {
    if (!dateString) return 'Дата невідома';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'Дата невідома';
    return date.toLocaleDateString('uk-UA');
}

async function loadMovieDetails() {
    const movieContent = document.getElementById('movieContent');
    if (!movieContent) return;
    try {
        const movieId = getMovieIdFromUrl();
        if (!movieId) throw new Error('ID фільму не знайдено');

        const res = await fetch(`/api/movie/${movieId}`);
        if (!res.ok) throw new Error('Фільм не знайдено');
        const movie = await res.json();

        let genres = [];
        try {
            const genresRes = await fetch(`/api/movie/${movieId}/genres`);
            if (genresRes.ok) {
                const genresData = await genresRes.json();
                genres = genresData.genres || [];
            }
        } catch {}

        let cast = [];
        try {
            const castRes = await fetch(`/api/movie/${movieId}/cast`);
            if (castRes.ok) {
                const castData = await castRes.json();
                cast = castData.cast || [];
            }
        } catch {}

        // Получаем среднюю оценку зрителей
        let averageRating = null;
        try {
            const reviewsRes = await fetch(`/api/movie/${movieId}/reviews`, { credentials: 'include' });
            if (reviewsRes.ok) {
                const reviewsData = await reviewsRes.json();
                averageRating = reviewsData.average_rating;
            }
        } catch {}

        movieContent.className = 'movie-detail-card';
        const posterHtml = movie.poster_url
            ? `<div class="movie-poster"><img src="${movie.poster_url}" alt="${movie.title}"></div>`
            : `<div class="movie-poster no-poster"><i class="fas fa-film fa-5x"></i><span>Немає постера</span></div>`;
        movieContent.innerHTML = `
            ${posterHtml}
            <div class="movie-info">
                <h1 class="movie-title">${movie.title}</h1>
                <div class="movie-meta">
                    <div class="movie-meta-item"><i class="fas fa-calendar"></i> <span>${formatDate(movie.release_date)}</span></div>
                    <div class="movie-meta-item"><i class="fas fa-clock"></i> <span>${movie.duration_min || '?'} хв</span></div>
                    <div class="movie-meta-item"><i class="fas fa-star"></i> <span>${movie.imdb_rating || '?'} / 10</span></div>
                    ${averageRating !== null ? `<div class="movie-meta-item"><i class="fas fa-users"></i> <span>Оцінка глядачів: <b>${averageRating}</b></span></div>` : ''}
                    <div class="movie-meta-item"><i class="fas fa-film"></i> <span>${genres.join(', ') || '—'}</span></div>
                    <div class="movie-meta-item"><i class="fas fa-user"></i> <span>Режисер: ${movie.director || '—'}</span></div>
                </div>
                <p class="movie-description">${movie.description || 'Опис відсутній'}</p>
                <div class="movie-actions">
                    <button class="action-button favorite-button"><i class="fas fa-heart"></i> Додати в обране</button>
                    <button class="action-button review-button"><i class="fas fa-comment"></i> Написати рецензію</button>
                </div>
                ${cast.length > 0 ? `
                <div class="movie-cast">
                    <h2 class="cast-title">Акторський склад</h2>
                    <p class="movie-cast-text">${cast.map(actor => actor.full_name).join(', ')}</p>
                </div>` : ''}
            </div>
            <div class="movie-reviews">
                <h2 class="reviews-title">Рецензії</h2>
                <div id="reviewsContainer" class="reviews-container">
                    <i class="fas fa-spinner fa-spin fa-2x"></i>
                    <p>Завантаження рецензій...</p>
                </div>
            </div>
        `;
        await updateFavoriteButtonState(movieId);
        setupButtonHandlers(movieId);
        loadReviews(movieId);
    } catch (e) {
        showError(e.message);
    }
}

function showError(message) {
    const movieContent = document.getElementById('movieContent');
    if (movieContent) {
        movieContent.className = 'movie-detail-card error-container';
        movieContent.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <p>Помилка: ${message}</p>
            <a href="/" style="color: #e50914; margin-top: 15px; display: inline-block;">Повернутися на головну</a>
        `;
    }
}

async function checkAuth() {
    try {
        const res = await fetch('/api/auth/status', { credentials: 'include' });
        const data = await res.json();
        return data.authenticated;
    } catch {
        return false;
    }
}

function setupButtonHandlers(movieId) {
    const favoriteButton = document.querySelector('.favorite-button');
    if (favoriteButton) {
        favoriteButton.addEventListener('click', async () => {
            try {
                const isAuthenticated = await checkAuth();
                if (!isAuthenticated) {
                    const confirmLogin = confirm('Для додавання фільму в обране необхідно авторизуватися. Перейти на сторінку входу?');
                    if (confirmLogin) {
                        localStorage.setItem('returnUrl', window.location.href);
                        window.location.href = '/login';
                    }
                    return;
                }

                const isFavorite = favoriteButton.classList.contains('active');
                if (isFavorite) {
                    const favoriteId = favoriteButton.dataset.favoriteId;
                    if (favoriteId) {
                        await removeFromFavorites(favoriteId, movieId);
                    } else {
                        await updateFavoriteButtonState(movieId);
                    }
                } else {
                    const response = await fetch(`/api/favorites`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ movieId }),
                        credentials: 'include'
                    });

                    // В любом случае после попытки добавить — обновляем состояние кнопки
                    await updateFavoriteButtonState(movieId);

                    if (!response.ok) {
                        if (response.status === 401) {
                            const confirmLogin = confirm('Ваша сесія закінчилася. Перейти на сторінку входу?');
                            if (confirmLogin) {
                                localStorage.setItem('returnUrl', window.location.href);
                                window.location.href = '/login';
                            }
                            return;
                        }
                        // Если 409 — просто обновляем состояние кнопки, не показываем ошибку
                        if (response.status === 409) {
                            return;
                        }
                        throw new Error('Не вдалося додати фільм в обране');
                    }
                }
            } catch (error) {
                console.error('Ошибка при работе с избранным:', error);
                alert('Помилка: ' + error.message);
            }
        });
    }

    const reviewButton = document.querySelector('.review-button');
    if (reviewButton) {
        reviewButton.addEventListener('click', () => {
            const reviewsContainer = document.getElementById('reviewsContainer');
            if (!reviewsContainer) return;
            // Если форма уже есть — не добавлять ещё раз
            if (document.querySelector('.review-form')) return;

            // Проверка авторизации
            fetch('/api/auth/status')
                .then(response => response.json())
                .then(data => {
                    if (!data.authenticated) {
                        alert('Для написання рецензії потрібно авторизуватись');
                        return;
                    }
                    const reviewForm = document.createElement('div');
                    reviewForm.className = 'review-form';
                    reviewForm.innerHTML = `
                        <h3>Написати рецензію</h3>
                        <div class="rating-container">
                            <label>Оцінка:</label>
                            <div class="star-rating">
                                ${Array(10).fill().map((_, i) => `
                                    <span class="star" data-rating="${i + 1}">★</span>
                                `).join('')}
                            </div>
                        </div>
                        <textarea id="reviewContent" placeholder="Напишіть вашу рецензію..." rows="4"></textarea>
                        <button type="button" id="submitReviewBtn">Опублікувати рецензію</button>
                        <button type="button" id="cancelReviewBtn" style="margin-left:10px; background:#888;">Скасувати</button>
                    `;
                    // Вставляем форму перед списком рецензій
                    reviewsContainer.prepend(reviewForm);
                    // Звёзды рейтинга
                    const stars = reviewForm.querySelectorAll('.star');
                    stars.forEach(star => {
                        star.addEventListener('click', function() {
                            const rating = this.dataset.rating;
                            stars.forEach(s => s.classList.remove('active'));
                            for (let i = 0; i < rating; i++) {
                                stars[i].classList.add('active');
                            }
                        });
                    });
                    // Кнопка отправки
                    reviewForm.querySelector('#submitReviewBtn').addEventListener('click', async () => {
                        const content = document.getElementById('reviewContent').value;
                        const rating = reviewForm.querySelectorAll('.star.active').length;
                        if (!content || !rating) {
                            alert('Будь ласка, заповніть всі обовʼязкові поля');
                            return;
                        }
                        try {
                            const mediaId = getMovieIdFromUrl();
                            const response = await fetch('/api/reviews', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ mediaId, content, rating })
                            });
                            if (!response.ok) {
                                const error = await response.json();
                                throw new Error(error.error || 'Помилка при відправці рецензії');
                            }
                            reviewForm.remove();
                            loadReviews(mediaId);
                        } catch (error) {
                            alert(error.message || 'Сталася помилка при відправці рецензії');
                        }
                    });
                    // Кнопка отмены
                    reviewForm.querySelector('#cancelReviewBtn').addEventListener('click', () => {
                        reviewForm.remove();
                    });
                });
        });
    }
}

async function loadReviews(movieId) {
    const container = document.getElementById('reviewsContainer');
    if (!container) return;
    container.innerHTML = Array(3).fill().map(() => '<div class="skeleton"></div>').join('');
    try {
        // Получаем текущего пользователя
        const authRes = await fetch('/api/auth/status', { credentials: 'include' });
        const authData = await authRes.json();
        const currentUserId = authData?.user?.id;

        const res = await fetch(`/api/movie/${movieId}/reviews`, { credentials: 'include' });
        const data = await res.json();
        const reviews = Array.isArray(data) ? data : (data.reviews || []);
        if (!res.ok) {
            if (res.status === 404) throw { code: 404 };
            throw new Error(data.error || 'Не вдалося завантажити рецензії');
        }
        if (reviews.length === 0) {
            container.innerHTML = `
                <p>Поки немає рецензій.</p>
                <button class="action-button write-first-button"><i class="fas fa-comment"></i> Написати першу рецензію</button>
            `;
            const writeBtn = container.querySelector('.write-first-button');
            if (writeBtn) writeBtn.addEventListener('click', () => {
                document.querySelector('.review-button')?.click();
            });
            return;
        }
        container.innerHTML = reviews.map(r => {
            const isOwn = currentUserId && r.user_id === currentUserId;
            const likeBtnClass = r.is_liked ? 'like-review-btn liked' : 'like-review-btn';
            const maxLength = 350;
            const isLong = r.content.length > maxLength;
            const shortText = isLong ? r.content.slice(0, maxLength) + '…' : r.content;
            let reviewTextHtml = `<p class="review-content review-text" data-full-text="${encodeURIComponent(r.content)}" data-short-text="${encodeURIComponent(shortText)}">${shortText}</p>`;
            if (isLong) {
                reviewTextHtml += `<button class="show-full-review-btn toggle-review-btn">Дивитись повністю...</button>`;
            }
            return `
            <div class="review" style="position:relative;">
                <div class="review-header">
                    <span class="review-rating">${'★'.repeat(r.rating) + '☆'.repeat(10 - r.rating)}</span>
                    <span class="review-date">${formatDate(r.created_at)}</span>
                    <span class="review-author" style="margin-left:15px; color:#ffd700;">
                      ${isOwn
                        ? (r.username ? r.username : 'Анонім')
                        : `<a href=\"/profile.html?id=${r.user_id}\" style=\"color:#ffd700; text-decoration:underline; cursor:pointer;\">${r.username ? r.username : 'Анонім'}</a>`}
                    </span>
                </div>
                ${reviewTextHtml}
                ${!isOwn ? `<button class=\"${likeBtnClass}\" data-id=\"${r.id}\" style=\"background:none;border:none;font-size:22px;cursor:pointer;display:inline-flex;align-items:center;gap:4px;position:absolute;right:15px;bottom:15px;\"><i class=\"fas fa-thumbs-up\"></i> <span class=\"like-count\">${r.likes_count || 0}</span></button>` : ''}
                ${isOwn ? `<button class=\"delete-review-btn\" data-id=\"${r.id}\" style=\"position:absolute; right:60px; bottom:15px; background:#c0392b; color:#fff; border:none; border-radius:6px; padding:10px 16px; cursor:pointer; font-size:22px;\"><i class='fas fa-trash'></i></button>` : ''}
            </div>
        `;
        }).join('');
        // Добавляю обработчик для удаления рецензии
        const deleteButtons = container.querySelectorAll('.delete-review-btn');
        deleteButtons.forEach(button => {
            button.addEventListener('click', async () => {
                const reviewId = button.getAttribute('data-id');
                if (confirm('Ви дійсно хочете видалити цю рецензію?')) {
                    button.disabled = true;
                    button.innerHTML = "<i class='fas fa-spinner fa-spin'></i>";
                    const response = await fetch(`/api/reviews/${reviewId}`, {
                        method: 'DELETE',
                        credentials: 'include'
                    });
                    if (response.ok) {
                        button.closest('.review').remove();
                    } else {
                        button.disabled = false;
                        button.innerHTML = "<i class='fas fa-trash'></i>";
                        alert('Помилка при видаленні рецензії');
                    }
                }
            });
        });
        // Добавляю обработчик для лайков
        const likeButtons = container.querySelectorAll('.like-review-btn');
        likeButtons.forEach(button => {
            button.addEventListener('click', async () => {
                const reviewId = button.getAttribute('data-id');
                const isLiked = button.classList.contains('liked');
                try {
                    button.disabled = true;
                    let res;
                    if (!isLiked) {
                        // Ставим лайк
                        res = await fetch('/api/review-likes', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            credentials: 'include',
                            body: JSON.stringify({ review_id: reviewId })
                        });
                    } else {
                        // Снимаем лайк
                        res = await fetch('/api/review-likes', {
                            method: 'DELETE',
                            headers: { 'Content-Type': 'application/json' },
                            credentials: 'include',
                            body: JSON.stringify({ review_id: reviewId })
                        });
                    }
                    if (!res.ok) throw new Error('Не вдалося оновити лайк');
                    // Обновляем UI: пересчитываем лайки и меняем класс
                    const countSpan = button.querySelector('.like-count');
                    let count = parseInt(countSpan.textContent);
                    if (!isLiked) {
                        countSpan.textContent = count + 1;
                        button.classList.add('liked');
                    } else {
                        countSpan.textContent = Math.max(0, count - 1);
                        button.classList.remove('liked');
                    }
                    button.disabled = false;
                } catch (e) {
                    button.disabled = false;
                    alert(e.message || 'Помилка при лайку');
                }
            });
        });
        // Добавляю обработчик для сворачивания/разворачивания рецензий
        const showFullBtns = container.querySelectorAll('.show-full-review-btn');
        showFullBtns.forEach((btn) => {
            btn.addEventListener('click', function() {
                const reviewText = btn.closest('.review').querySelector('.review-text');
                const isExpanded = reviewText.classList.contains('expanded-review');
                if (!isExpanded) {
                    // Раскрываем
                    const fullText = decodeURIComponent(reviewText.getAttribute('data-full-text'));
                    reviewText.textContent = fullText;
                    reviewText.classList.add('expanded-review');
                    btn.textContent = 'Приховати...';
                } else {
                    // Сворачиваем
                    const shortText = decodeURIComponent(reviewText.getAttribute('data-short-text'));
                    reviewText.textContent = shortText;
                    reviewText.classList.remove('expanded-review');
                    btn.textContent = 'Дивитись повністю...';
                }
                // Перемещаем кнопку после текста
                reviewText.after(btn);
            });
        });
    } catch (err) {
        if (err.code === 404) {
            container.innerHTML = `
                <p>Поки немає рецензій.</p>
                <button class="action-button write-first-button"><i class="fas fa-comment"></i> Написати першу рецензію</button>
            `;
            const writeBtn = container.querySelector('.write-first-button');
            if (writeBtn) writeBtn.addEventListener('click', () => {
                document.querySelector('.review-button')?.click();
            });
        } else {
            container.innerHTML = `<p>Помилка: ${err.message || err}</p>`;
        }
    }
}

async function updateFavoriteButtonState(movieId) {
    try {
        const profileRes = await fetch('/api/profile', { credentials: 'include' });
        if (!profileRes.ok) return;
        const profileData = await profileRes.json();
        const userId = profileData?.profile?.user_id;
        if (!userId) return;

        const favRes = await fetch(`/api/favorites/user/${userId}`, { credentials: 'include' });
        if (!favRes.ok) return;
        const favData = await favRes.json();
        const favorites = favData.favorites || [];

        const favoriteRecord = favorites.find(fav =>
            String(fav.media_id) === String(movieId) ||
            (fav.media && String(fav.media.id) === String(movieId))
        );

        const favoriteButton = document.querySelector('.favorite-button');
        if (favoriteButton) {
            if (favoriteRecord) {
                favoriteButton.innerHTML = '<i class="fas fa-heart-broken"></i> Видалити з обраного';
                favoriteButton.classList.add('active', 'remove-favorite-btn');
                favoriteButton.dataset.favoriteId = favoriteRecord.favorites_id;
            } else {
                favoriteButton.innerHTML = '<i class="fas fa-heart"></i> Додати в обране';
                favoriteButton.classList.remove('active', 'remove-favorite-btn');
                delete favoriteButton.dataset.favoriteId;
            }
        }
    } catch (e) {
        console.warn('Не удалось проверить избранное:', e);
    }
}

async function removeFromFavorites(favoriteId, movieId) {
    try {
        const response = await fetch(`/api/favorites/${favoriteId}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Ошибка при удалении из избранного');
        }

        // Обновляем состояние кнопки
        await updateFavoriteButtonState(movieId);
    } catch (error) {
        console.error('Ошибка:', error);
        alert('Не удалось удалить из избранного');
    }
}

document.addEventListener('DOMContentLoaded', loadMovieDetails);