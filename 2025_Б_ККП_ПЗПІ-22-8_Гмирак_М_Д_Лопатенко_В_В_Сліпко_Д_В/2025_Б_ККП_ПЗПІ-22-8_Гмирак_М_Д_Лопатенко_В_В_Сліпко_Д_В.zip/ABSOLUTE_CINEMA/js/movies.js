document.addEventListener('DOMContentLoaded', function() {
  const allMoviesList = document.getElementById('allMoviesList');
  const typeFilter = document.getElementById('typeFilter');
  const sortMovies = document.getElementById('sortMovies');
  const genreFilter = document.getElementById('genreFilter');
  const yearFilter = document.getElementById('yearFilter');
  const resetFilters = document.getElementById('resetFilters');
  const movieSearch = document.getElementById('movieSearch');

  // Сопоставление единственного и множественного числа для жанров
  const genrePluralMap = {
    'Бойовик': 'Бойовики',
    'Комедія': 'Комедії',
    'Драма': 'Драми',
    'Жахи': 'Жахи',
    'Фантастика': 'Фантастика',
    'Трилер': 'Трилери',
    'Мультфільм': 'Мультфільми',
    'Документальний': 'Документальні',
    'Аніме': 'Аніме',
    'Артхаус': 'Артхауси',
    'Детектив': 'Детективи',
    'Мелодрама': 'Мелодрами'
  };

  function updateMoviesTitle() {
    const titleEl = document.querySelector('.movies-page-title');
    if (!titleEl) return;
    const type = typeFilter.value;
    const genre = genreFilter.value;
    const year = yearFilter.value;
    const plural = genrePluralMap[genre] || genre;
    
    let title = '';
    
    if (type === 'latest' && genre !== 'all') {
      title = `Новинки: ${plural}`;
    } else if (type === 'popular' && genre !== 'all') {
      title = `Популярні: ${plural}`;
    } else if (type === 'latest') {
      title = 'Новинки';
    } else if (type === 'popular') {
      title = 'Популярні';
    } else if (genre !== 'all') {
      title = `Усі фільми: ${plural}`;
    } else {
      title = 'Усі фільми';
    }

    // Добавляем год к заголовку если он выбран
    if (year !== 'all') {
      if (year === 'older') {
        title += ' (до 2015)';
      } else {
        title += ` (${year})`;
      }
    }

    titleEl.textContent = title;
  }

  typeFilter.addEventListener('change', () => {
    updateMoviesTitle();
    loadAndRenderAllMovies();
  });
  sortMovies.addEventListener('change', () => {
    loadAndRenderAllMovies();
  });
  genreFilter.addEventListener('change', () => {
    updateMoviesTitle();
    loadAndRenderAllMovies();
  });
  yearFilter.addEventListener('change', () => {
    updateMoviesTitle();
    loadAndRenderAllMovies();
  });

  // Обработчик для поиска
  let searchTimeout;
  movieSearch.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      updateMoviesTitle();
      loadAndRenderAllMovies();
    }, 300); // Задержка 300мс для оптимизации
  });

  // Обработчик для кнопки сброса фильтров
  resetFilters.addEventListener('click', () => {
    // Сбрасываем все фильтры к значениям по умолчанию
    typeFilter.value = 'all';
    sortMovies.value = 'default';
    genreFilter.value = 'all';
    yearFilter.value = 'all';
    movieSearch.value = ''; // Очищаем поле поиска

    // Очищаем URL от параметров фильтрации
    const url = new URL(window.location.href);
    url.search = '';
    window.history.pushState({}, '', url);

    // Обновляем заголовок и список фильмов
    updateMoviesTitle();
    loadAndRenderAllMovies();
  });

  // Устанавливаем фильтры из query-параметров
  function setFiltersFromQuery() {
    const params = new URLSearchParams(window.location.search);
    const sort = params.get('sort');
    // Новое: поддержка ?sort=latest и ?sort=popular для автоматического выбора фильтра
    if (sort === 'latest') {
      typeFilter.value = 'latest';
    } else if (sort === 'popular') {
      typeFilter.value = 'popular';
    }
    const type = params.get('type');
    const genre = params.get('genre');
    const year = params.get('year');
    const search = params.get('search');
    if (type && (type === 'popular' || type === 'latest' || type === 'all')) {
      typeFilter.value = type;
    }
    if (sort && (sort === 'default' || sort === 'year_desc' || sort === 'year_asc' || sort === 'rating_desc' || sort === 'rating_asc')) {
      sortMovies.value = sort;
    }
    if (genre && genreFilter.querySelector(`option[value="${genre}"]`)) {
      genreFilter.value = genre;
    }
    if (year && yearFilter.querySelector(`option[value="${year}"]`)) {
      yearFilter.value = year;
    }
    if (search) {
      movieSearch.value = search;
    }
  }

  setFiltersFromQuery();
  updateMoviesTitle();
  loadAndRenderAllMovies();

  async function loadAndRenderAllMovies() {
    allMoviesList.innerHTML = '<div style="color:#ffe066;text-align:center;padding:30px;">Завантаження...</div>';
    let movies = [];
    try {
      const res = await fetch('/api/high-rated-movies');
      if (res.ok) {
        const data = await res.json();
        movies = data.movies || [];
      } else {
        allMoviesList.innerHTML = '<div style="color:#e74c3c;text-align:center;padding:30px;">Не вдалося завантажити фільми</div>';
        return;
      }
    } catch {
      allMoviesList.innerHTML = '<div style="color:#e74c3c;text-align:center;padding:30px;">Не вдалося завантажити фільми</div>';
      return;
    }

    // Фильтрация по типу
    const type = typeFilter.value;
    const sort = sortMovies.value;
    const genre = genreFilter.value;
    const year = yearFilter.value;
    const searchQuery = movieSearch.value.toLowerCase().trim();

    // Поиск по названию
    if (searchQuery) {
      movies = movies.filter(m => m.title.toLowerCase().includes(searchQuery));
    }

    // Фильтрация по типу
    if (type === 'latest') {
      // Новинки: фильмы за последний месяц
      const now = new Date();
      const monthAgo = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
      movies = movies.filter(m => {
        if (!m.release_date) return false;
        const d = new Date(m.release_date);
        return d >= monthAgo && d <= now;
      });
    } else if (type === 'popular') {
      // Популярные: только с рейтингом >= 8
      movies = movies.filter(m => Number(m.imdb_rating) >= 8);
    }

    // Сортировка
    if (sort === 'year_desc') {
      // Сортировка по году (новые сначала)
      movies.sort((a,b) => {
        const yearA = a.release_date ? new Date(a.release_date).getFullYear() : 0;
        const yearB = b.release_date ? new Date(b.release_date).getFullYear() : 0;
        return yearB - yearA;
      });
    } else if (sort === 'year_asc') {
      // Сортировка по году (старые сначала)
      movies.sort((a,b) => {
        const yearA = a.release_date ? new Date(a.release_date).getFullYear() : 0;
        const yearB = b.release_date ? new Date(b.release_date).getFullYear() : 0;
        return yearA - yearB;
      });
    } else if (sort === 'rating_desc') {
      // Сортировка по рейтингу (высокий сначала)
      movies.sort((a,b) => (b.imdb_rating||0)-(a.imdb_rating||0));
    } else if (sort === 'rating_asc') {
      // Сортировка по рейтингу (низкий сначала)
      movies.sort((a,b) => (a.imdb_rating||0)-(b.imdb_rating||0));
    }

    // Фильтрация по жанру
    if (genre !== 'all') {
      movies = movies.filter(m => (m.genres||[]).includes(genre));
    }

    // Фильтрация по году
    if (year !== 'all') {
      movies = movies.filter(m => {
        if (!m.release_date) return false;
        const movieYear = new Date(m.release_date).getFullYear();
        if (year === 'older') {
          return movieYear < 2015;
        }
        return movieYear === parseInt(year);
      });
    }

    // Обновляем URL с параметрами поиска
    const url = new URL(window.location.href);
    if (searchQuery) {
      url.searchParams.set('search', searchQuery);
    } else {
      url.searchParams.delete('search');
    }
    window.history.pushState({}, '', url);

    // Рендер
    if (!movies.length) {
      allMoviesList.innerHTML = '<div style="color:#ffe066;text-align:center;padding:30px;">Фільмів не знайдено</div>';
      return;
    }
    allMoviesList.innerHTML = movies.map(m => `
      <div class="all-movie-card" onclick="window.location='/movie/${m.id}'">
        <img src="${m.poster_url||'https://via.placeholder.com/150x225?text=No+Poster'}" alt="${m.title}">
        <div class="all-movie-card-title">${m.title}</div>
        <div class="all-movie-card-rating" style="color:#ffe066;font-size:18px;font-weight:600;display:flex;align-items:center;justify-content:center;gap:6px;">
          <span style="color:#ffe066;font-size:20px;">★</span> ${(m.imdb_rating !== undefined && m.imdb_rating !== null && m.imdb_rating !== '' && m.imdb_rating !== '?') ? m.imdb_rating : '?'}<span style="color:#fff;font-size:16px;">/10</span>
        </div>
        <div class="all-movie-card-genres">${(m.genres||[]).join(', ')}</div>
        <div class="all-movie-card-year" style="color:#aaa;font-size:12px;">${(m.release_date||'').slice(0,4)}</div>
      </div>
    `).join('');
  }

  // Обновление UI авторизации после загрузки хедера
  if (window.authManager && typeof window.authManager.updateUI === 'function') {
    window.authManager.updateUI();
  }
}); 