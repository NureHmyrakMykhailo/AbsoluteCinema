// Инициализация переменных
let currentUser = null;
let currentChatId = null;
let chats = [];
let activeChatUser = null;
let isModalOpen = false;
let socket = null;

// DOM элементы
const chatsList = document.getElementById('chats-list');
const noChat = document.getElementById('no-chat-selected');
const activeChat = document.getElementById('active-chat');
const chatMessages = document.getElementById('chat-messages');
const chatHeader = document.getElementById('chat-header');
const chatInput = document.getElementById('chat-input');
const sendBtn = document.getElementById('send-btn');
const newChatBtn = document.getElementById('new-chat-btn');
const newChatModal = document.getElementById('new-chat-modal');
const searchChatInput = document.getElementById('search-chat-input');
const searchUserInput = document.getElementById('search-user-input');
const searchUserBtn = document.getElementById('search-user-btn');
const searchResults = document.getElementById('search-results');
const emojiBtn = document.getElementById('emoji-btn');
const chatDeleteBtn = document.getElementById('chat-delete-btn');

// Событие загрузки DOM
document.addEventListener('DOMContentLoaded', async function() {
    // Инициализация компонентов
    initComponents();
    
    try {
        // Проверка авторизации
        await checkAuth();
        
        // Загрузка чатов пользователя
        if (currentUser) {
            await loadChats();
            // Открытие чата по параметру chat
            const params = new URLSearchParams(window.location.search);
            const chatId = params.get('chat');
            if (chatId) {
                // Ждём, пока чаты загрузятся, затем ищем нужный чат
                const chatItem = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
                if (chatItem) {
                    chatItem.click();
                } else {
                    // Если чат не найден (например, только что создан), пробуем открыть напрямую
                    // Для этого нужно найти userId собеседника
                    // Можно попробовать найти в массиве chats
                    const chatObj = chats.find(c => String(c.id) === String(chatId));
                    if (chatObj) {
                        const otherUserId = chatObj.user1_id === currentUser.user_id ? chatObj.user2.user_id : chatObj.user1.user_id;
                        openChat(chatId, otherUserId);
                    }
                }
            }
        } else {
            // Если пользователь не авторизован, показываем сообщение
            chatsList.innerHTML = '<div class="empty-chats"><p>Вы не авторизованы</p><p>Войдите, чтобы получить доступ к чатам</p></div>';
            showLoginPrompt();
        }
    } catch (error) {
        console.error('Ошибка при инициализации:', error);
        chatsList.innerHTML = '<div class="error-message">Ошибка загрузки чатов</div>';
    }
    
    // Инициализация событий
    initEvents();
    
    // Инициализация эмодзи-пикера
    initEmojiPicker();
});

// Инициализация компонентов страницы
async function initComponents() {
    try {
        // Здесь может быть дополнительная инициализация компонентов
        console.log('Компоненты инициализированы');
    } catch (error) {
        console.error('Ошибка при инициализации компонентов:', error);
    }
}

// Инициализация WebSocket соединения
function initWebSocket() {
    if (!currentUser) {
        console.log('initWebSocket: currentUser не определен');
        return;
    }

    console.log('initWebSocket: Инициализация WebSocket для пользователя', currentUser.user_id);

    // Закрываем существующее соединение, если оно есть
    if (socket) {
        console.log('initWebSocket: Закрываем существующее соединение');
        socket.close();
    }

    // Создаем новое WebSocket соединение
    const wsUrl = `ws://${window.location.host}/ws/chat`;
    console.log('initWebSocket: Создаем новое соединение по URL', wsUrl);
    socket = new WebSocket(wsUrl);

    socket.onopen = async function(e) {
        console.log('WebSocket соединение установлено для пользователя', currentUser.user_id);
        
        try {
            // Получаем токен через API
            console.log('Запрашиваем токен через API');
            const response = await fetch('/api/auth/token');
            const data = await response.json();
            
            if (!data.token) {
                console.error('Токен не получен от сервера');
                return;
            }

            console.log('Токен получен, отправляем для аутентификации');
            // Отправляем токен для аутентификации
            socket.send(JSON.stringify({
                type: 'auth',
                token: data.token
            }));
            console.log('Токен отправлен для аутентификации');
        } catch (error) {
            console.error('Ошибка при получении токена:', error);
        }
    };

    socket.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);
            console.log('Получено сообщение через WebSocket для пользователя', currentUser.user_id, ':', data);
            
            switch (data.type) {
                case 'message':
                    // Если сообщение для текущего чата
                    if (data.chat_id === currentChatId) {
                        console.log('Добавляем новое сообщение в чат:', data);
                        // Добавляем новое сообщение в чат
                        const messageHTML = `
                            <div class="message message-received">
                                <div class="message-content">${data.content}</div>
                                <div class="message-time">${formatTime(new Date(data.sent_at))}</div>
                            </div>
                        `;
                        chatMessages.insertAdjacentHTML('beforeend', messageHTML);
                        scrollToBottom();
                    } else {
                        console.log('Сообщение не для текущего чата:', data.chat_id, 'текущий чат:', currentChatId);
                    }
                    
                    // Обновляем список чатов
                    loadChats();
                    updateUnreadBadge();
                    break;

                case 'message_sent':
                    console.log('Сообщение успешно доставлено:', data);
                    // Можно добавить визуальное подтверждение доставки
                    break;

                case 'message_error':
                    console.error('Ошибка отправки сообщения:', data.error);
                    alert('Ошибка отправки сообщения: ' + data.error);
                    break;

                case 'message_status':
                    if (data.status === 'recipient_offline') {
                        console.log('Получатель не в сети');
                        // Можно добавить визуальное уведомление
                    }
                    break;
            }
        } catch (error) {
            console.error('Ошибка при обработке WebSocket сообщения:', error);
        }
    };

    socket.onclose = function(event) {
        console.log('WebSocket соединение закрыто:', event.code, event.reason);
        // Пытаемся переподключиться через 5 секунд
        setTimeout(initWebSocket, 5000);
    };

    socket.onerror = function(error) {
        console.error('WebSocket ошибка:', error);
    };
}

// Модифицируем функцию checkAuth
async function checkAuth() {
    try {
        const response = await fetch('/api/auth/status');
        const data = await response.json();
        
        if (data.authenticated) {
            currentUser = data.user;
            console.log('Пользователь авторизован:', currentUser);
            
            // Загружаем полную информацию о профиле
            const profileResponse = await fetch('/api/profile');
            const profileData = await profileResponse.json();
            
            if (profileData.profile) {
                currentUser = { ...currentUser, ...profileData.profile };
            }

            // Инициализируем WebSocket после успешной авторизации
            initWebSocket();
        } else {
            console.log('Пользователь не авторизован');
            currentUser = null;
        }
    } catch (error) {
        console.error('Ошибка при проверке авторизации:', error);
        throw error;
    }
}

// Показать сообщение о необходимости входа
function showLoginPrompt() {
    noChat.innerHTML = `
        <div class="login-prompt">
            <div class="login-icon">
                <i class="fas fa-user-lock"></i>
            </div>
            <h2>Войдите в аккаунт</h2>
            <p>Чтобы начать общение, необходимо войти или зарегистрироваться</p>
            <button class="login-btn" onclick="openAuthModal()">
                <i class="fas fa-sign-in-alt"></i> ВХІД/РЕЄСТРАЦІЯ
            </button>
        </div>
    `;
}

// Загрузка чатов пользователя
async function loadChats() {
    try {
        chatsList.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i><p>Завантаження чатів...</p></div>';
        
        // Запрос к API для получения чатов пользователя
        const response = await fetch(`/api/chats`);
        const data = await response.json();
        
        if (response.ok) {
            chats = data.chats || [];
            renderChats();
            updateUnreadBadge();
        } else {
            console.error('Ошибка при загрузке чатов:', data.error);
            chatsList.innerHTML = '<div class="error-message">Помилка завантаження чатів</div>';
        }
    } catch (error) {
        console.error('Ошибка при загрузке чатов:', error);
        chatsList.innerHTML = '<div class="error-message">Помилка завантаження чатів</div>';
    }
}

// Отображение списка чатов
function renderChats() {
    if (chats.length === 0) {
        chatsList.innerHTML = '<div class="empty-chats"><p>У вас поки немає чатів</p><p>Натисніть "Новий чат", щоб почати спілкування</p></div>';
        return;
    }
    
    let chatsHTML = '';
    
    chats.forEach(chat => {
        // Определяем собеседника (другого пользователя)
        const otherUser = chat.user1_id === currentUser.user_id ? chat.user2 : chat.user1;
        const userProfile = otherUser && otherUser.profile ? otherUser.profile : otherUser;
        // Форматируем время последнего сообщения
        const lastMessageTime = chat.last_message ? formatTime(new Date(chat.last_message.sent_at)) : '';
        // Создаем HTML элемент чата
        chatsHTML += `
            <div class="chat-item${chat.id === currentChatId ? ' active' : ''}" data-chat-id="${chat.id}" data-user-id="${userProfile.user_id}">
                <div class="chat-avatar">
                    <img src="${userProfile.avatar_url || 'https://via.placeholder.com/50'}" alt="${userProfile.username}">
                </div>
                <div class="chat-preview">
                    <h3>${userProfile.username}</h3>
                    <p>${chat.last_message ? chat.last_message.content : 'Немає повідомлень'}</p>
                </div>
                <div class="chat-meta">
                    <div class="chat-time">${lastMessageTime}</div>
                    ${chat.unread_count > 0 ? `<div class="chat-unread">${chat.unread_count}</div>` : ''}
                </div>
            </div>
        `;
    });
    
    chatsList.innerHTML = chatsHTML;
    
    // Добавляем обработчики для каждого чата
    document.querySelectorAll('.chat-item').forEach(item => {
        item.addEventListener('click', function() {
            const chatId = this.getAttribute('data-chat-id');
            const userId = this.getAttribute('data-user-id');
            openChat(chatId, userId);
        });
    });
}

// Открытие чата
async function openChat(chatId, userId) {
    // Удаляем активный класс со всех чатов и добавляем новому
    document.querySelectorAll('.chat-item').forEach(item => {
        item.classList.remove('active');
    });
    
    const chatItem = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
    if (chatItem) {
        chatItem.classList.add('active');
    }
    
    currentChatId = chatId;
    
    // Показываем окно активного чата
    noChat.style.display = 'none';
    activeChat.style.display = 'flex';
    
    // Загружаем информацию о пользователе
    await loadChatUser(userId);
    
    // Загружаем сообщения
    await loadMessages(chatId);
    
    // Отмечаем сообщения как прочитанные
    markMessagesAsRead(chatId);
}

// Загрузка информации о пользователе чата
async function loadChatUser(userId) {
    try {
        console.log('loadChatUser получает userId:', userId, 'currentUser:', currentUser.user_id);
        const response = await fetch(`/api/users/${userId}`);
        const data = await response.json();
        if (response.ok) {
            const userProfile = data.profile;
            activeChatUser = userProfile;
            console.log('Получена информация о пользователе:', activeChatUser);
            // Обновляем заголовок чата
            document.getElementById('chat-user-name').textContent = activeChatUser.username;
            document.getElementById('chat-user-avatar').src = activeChatUser.avatar_url || 'https://via.placeholder.com/40';
            // Отображаем биографию пользователя
            const userBioElement = document.getElementById('chat-user-bio');
            if (userBioElement) {
                userBioElement.textContent = activeChatUser.bio || 'Біографія відсутня';
            }
            // Добавляем возможность перехода на профиль пользователя
            const userNameElement = document.getElementById('chat-user-name');
            const userAvatarElement = document.getElementById('chat-user-avatar').parentElement;
            userNameElement.style.cursor = 'pointer';
            userAvatarElement.style.cursor = 'pointer';
            userNameElement.onclick = () => {
                console.log('Переход на профиль собеседника:', activeChatUser.user_id);
                window.location.href = `/profile.html?id=${activeChatUser.user_id}`;
            };
            userAvatarElement.onclick = () => {
                console.log('Переход на профиль собеседника:', activeChatUser.user_id);
                window.location.href = `/profile.html?id=${activeChatUser.user_id}`;
            };
        } else {
            console.error('Ошибка при загрузке пользователя:', data.error);
        }
    } catch (error) {
        console.error('Ошибка при загрузке пользователя:', error);
    }
}

// Загрузка сообщений чата
async function loadMessages(chatId) {
    try {
        chatMessages.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i><p>Завантаження повідомлень...</p></div>';
        
        const response = await fetch(`/api/chats/${chatId}/messages`);
        const data = await response.json();
        
        if (response.ok) {
            renderMessages(data.messages || []);
        } else {
            console.error('Ошибка при загрузке сообщений:', data.error);
            chatMessages.innerHTML = '<div class="error-message">Помилка завантаження повідомлень</div>';
        }
    } catch (error) {
        console.error('Ошибка при загрузке сообщений:', error);
        chatMessages.innerHTML = '<div class="error-message">Помилка завантаження повідомлень</div>';
    }
}

// Функция для автоматической прокрутки чата
function scrollToBottom() {
    const chatMessages = document.getElementById('chat-messages');
    if (chatMessages) {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
}

// Отображение сообщений чата
function renderMessages(messages) {
    if (messages.length === 0) {
        chatMessages.innerHTML = '<div class="empty-messages"><p>Напишіть повідомлення, щоб почати спілкування</p></div>';
        return;
    }
    
    let messagesHTML = '';
    
    messages.forEach(message => {
        const isSent = message.sender_id === currentUser.user_id;
        const messageClass = isSent ? 'message-sent' : 'message-received';
        const messageTime = formatTime(new Date(message.sent_at));
        
        messagesHTML += `
            <div class="message ${messageClass}">
                <div class="message-content">${message.content}</div>
                <div class="message-time">${messageTime}</div>
            </div>
        `;
    });
    
    chatMessages.innerHTML = messagesHTML;
    
    // Прокручиваем к последнему сообщению
    scrollToBottom();
}

// Модифицируем функцию sendMessage
async function sendMessage() {
    if (!currentChatId || !chatInput.value.trim()) {
        return;
    }
    
    const messageContent = chatInput.value.trim();
    
    try {
        console.log('Отправка сообщения в чат:', currentChatId);
        console.log('Содержимое сообщения:', messageContent);
        
        // Отправляем сообщение на сервер
        const response = await fetch(`/api/chats/${currentChatId}/messages`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                content: messageContent
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            console.log('Сообщение успешно отправлено:', data.message);
            
            // Очищаем поле ввода
            chatInput.value = '';
            
            // Добавляем новое сообщение в чат
            const message = data.message;
            const messageHTML = `
                <div class="message message-sent">
                    <div class="message-content">${message.content}</div>
                    <div class="message-time">${formatTime(new Date(message.sent_at))}</div>
                </div>
            `;
            chatMessages.insertAdjacentHTML('beforeend', messageHTML);
            
            // Прокручиваем к новому сообщению
            scrollToBottom();

            // Отправляем сообщение через WebSocket
            if (socket && socket.readyState === WebSocket.OPEN) {
                socket.send(JSON.stringify({
                    type: 'message',
                    chat_id: currentChatId,
                    content: messageContent,
                    sender_id: currentUser.user_id,
                    sent_at: message.sent_at
                }));
                console.log('Сообщение отправлено через WebSocket');
            } else {
                console.error('WebSocket не подключен');
            }
        } else {
            console.error('Ошибка при отправке сообщения:', data.error);
            alert('Помилка відправки повідомлення: ' + (data.error || 'Невідома помилка'));
        }
    } catch (error) {
        console.error('Ошибка при отправке сообщения:', error);
        alert('Помилка відправки повідомлення: ' + error.message);
    }
}

// Отметка сообщений как прочитанных
async function markMessagesAsRead(chatId) {
    try {
        await fetch(`/api/chats/${chatId}/read`, {
            method: 'POST'
        });
        
        // Обновляем список чатов (чтобы скрыть индикатор непрочитанных сообщений)
        await loadChats();
    } catch (error) {
        console.error('Ошибка при отметке сообщений как прочитанных:', error);
    }
}

// Создание нового чата
async function createChat(userId) {
    try {
        const response = await fetch('/api/chats', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            // Закрываем модальное окно
            closeModal();
            
            // Обновляем список чатов
            await loadChats();
            
            // Открываем новый чат
            openChat(data.chat.id, userId);
        } else {
            console.error('Ошибка при создании чата:', data.error);
            alert('Помилка створення чату');
        }
    } catch (error) {
        console.error('Ошибка при создании чата:', error);
        alert('Помилка створення чату');
    }
}

// Поиск пользователей
async function searchUsers(query) {
    if (!query.trim()) {
        searchResults.innerHTML = '';
        return;
    }
    
    try {
        searchResults.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i><p>Пошук користувачів...</p></div>';
        
        const response = await fetch(`/api/users/search?query=${encodeURIComponent(query)}`);
        const data = await response.json();
        
        if (response.ok) {
            renderSearchResults(data.users || []);
        } else {
            console.error('Ошибка при поиске пользователей:', data.error);
            searchResults.innerHTML = '<div class="error-message">Помилка пошуку користувачів</div>';
        }
    } catch (error) {
        console.error('Ошибка при поиске пользователей:', error);
        searchResults.innerHTML = '<div class="error-message">Помилка пошуку користувачів</div>';
    }
}

// Отображение результатов поиска пользователей
function renderSearchResults(users) {
    if (users.length === 0) {
        searchResults.innerHTML = '<div class="empty-results">Користувачів не знайдено</div>';
        return;
    }
    
    let resultsHTML = '';
    
    users.forEach(user => {
        // Пропускаем текущего пользователя
        if (user.user_id === currentUser.user_id) {
            return;
        }
        
        resultsHTML += `
            <div class="user-result" data-user-id="${user.user_id}">
                <div class="user-result-avatar">
                    <img src="${user.avatar_url || 'https://via.placeholder.com/40'}" alt="${user.username}">
                </div>
                <div class="user-result-details">
                    <h3>${user.username}</h3>
                    <p>${user.bio ? user.bio.substring(0, 50) + (user.bio.length > 50 ? '...' : '') : 'Немає інформації'}</p>
                </div>
            </div>
        `;
    });
    
    searchResults.innerHTML = resultsHTML;
    
    // Добавляем обработчики для каждого результата
    document.querySelectorAll('.user-result').forEach(item => {
        item.addEventListener('click', function() {
            const userId = this.getAttribute('data-user-id');
            createChat(userId);
        });
    });
}

// Открытие модального окна
function openModal() {
    newChatModal.style.display = 'flex';
    searchUserInput.value = '';
    searchResults.innerHTML = '';
    isModalOpen = true;
}

// Закрытие модального окна
function closeModal() {
    newChatModal.style.display = 'none';
    isModalOpen = false;
}

// Поиск чатов
function filterChats(query) {
    const chatItems = document.querySelectorAll('.chat-item');
    
    chatItems.forEach(item => {
        const username = item.querySelector('h3').textContent.toLowerCase();
        const lastMessage = item.querySelector('p').textContent.toLowerCase();
        
        if (username.includes(query.toLowerCase()) || lastMessage.includes(query.toLowerCase())) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}

// Открытие модального окна авторизации
function openAuthModal() {
    // Если есть функция из auth.js, вызываем ее
    if (typeof showAuthModal === 'function') {
        showAuthModal('login');
    } else {
        alert('Для спілкування в чаті потрібно авторизуватися');
    }
}

// Форматирование времени
function formatTime(date) {
    // Получаем текущую дату
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    // Проверяем, сегодня ли сообщение
    if (date > today) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    // Проверяем, вчера ли сообщение
    if (date > yesterday) {
        return 'Вчора';
    }
    
    // Иначе возвращаем дату
    return date.toLocaleDateString();
}

// Инициализация эмодзи-пикера
function initEmojiPicker() {
    // Проверяем, загружена ли библиотека
    if (typeof EmojiButton !== 'function') {
        // Если библиотека не загружена, подключаем ее
        const emojiScript = document.createElement('script');
        emojiScript.src = 'https://cdn.jsdelivr.net/npm/@joeattardi/emoji-button@3.1.1/dist/index.min.js';
        document.head.appendChild(emojiScript);
        
        const emojiCSS = document.createElement('link');
        emojiCSS.rel = 'stylesheet';
        emojiCSS.href = 'https://cdn.jsdelivr.net/npm/@joeattardi/emoji-button@3.1.1/dist/css/emoji-button.min.css';
        document.head.appendChild(emojiCSS);
        
        emojiScript.onload = setupEmojiPicker;
    } else {
        setupEmojiPicker();
    }
}

// Настройка эмодзи-пикера
function setupEmojiPicker() {
    if (!emojiBtn) return;
    
    const picker = new EmojiButton({
        position: 'top-start',
        theme: 'dark',
        autoHide: false,
        showVariants: true,
        emojiSize: '1.5em'
    });
    
    picker.on('emoji', emoji => {
        chatInput.value += emoji;
        chatInput.focus();
    });
    
    emojiBtn.addEventListener('click', () => {
        picker.togglePicker(emojiBtn);
    });
}

// Удаление чата
async function deleteChat(chatId) {
    if (!confirm('Ви впевнені, що хочете видалити цю переписку? Це не можна буде скасувати.')) {
        return;
    }
    
    try {
        console.log('Удаление чата с ID:', chatId);
        
        const response = await fetch(`/api/chats/${chatId}`, {
            method: 'DELETE'
        });
        
        const responseText = await response.text();
        console.log('Ответ сервера при удалении чата:', responseText);
        
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('Ошибка парсинга ответа при удалении чата:', parseError);
            alert('Помилка при видаленні чату: невірний формат відповіді');
            return;
        }
        
        if (response.ok) {
            console.log('Чат успешно удален:', data);
            
            // Закрываем чат
            currentChatId = null;
            activeChat.style.display = 'none';
            noChat.style.display = 'flex';
            
            // Обновляем список чатов
            await loadChats();
        } else {
            console.error('Ошибка при удалении чата:', data.error);
            alert('Помилка при видаленні чату: ' + (data.error || 'Невідома помилка'));
        }
    } catch (error) {
        console.error('Ошибка при удалении чата:', error);
        alert('Помилка при видаленні чату: ' + error.message);
    }
}

// Инициализация обработчиков событий
function initEvents() {
    // Отправка сообщения при нажатии на кнопку
    sendBtn.addEventListener('click', sendMessage);
    
    // Отправка сообщения при нажатии Enter (без Shift)
    chatInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Открытие модального окна для нового чата
    newChatBtn.addEventListener('click', openModal);
    
    // Закрытие модального окна - используем все кнопки закрытия на странице
    document.querySelectorAll('.modal-close').forEach(closeBtn => {
        closeBtn.addEventListener('click', closeModal);
    });
    
    // Закрытие модального окна при клике вне его
    newChatModal.addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    
    // Поиск пользователей
    searchUserBtn.addEventListener('click', function() {
        searchUsers(searchUserInput.value);
    });
    
    // Поиск пользователей при нажатии Enter
    searchUserInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            searchUsers(searchUserInput.value);
        }
    });
    
    // Поиск чатов
    searchChatInput.addEventListener('input', function() {
        filterChats(this.value);
    });
    
    // Закрытие модального окна при нажатии Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && isModalOpen) {
            closeModal();
        }
    });
    
    // Удаление чата
    if (chatDeleteBtn) {
        chatDeleteBtn.addEventListener('click', function() {
            if (currentChatId) {
                deleteChat(currentChatId);
            }
        });
    }
    
    // Инициализируем события рекомендаций, если они есть
    initRecommendationsEvents();
}

// Инициализация событий для рекомендаций
function initRecommendationsEvents() {
    // Обработчики для кнопок "Начать чат" с рекомендованными пользователями
    const startChatButtons = document.querySelectorAll('.start-chat-btn');
    startChatButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Получаем имя пользователя из родительской карточки
            const userName = this.closest('.user-card').querySelector('h4').textContent;
            
            // Заглушка - создаем заглушку для демонстрации
            alert(`Початок нового чату з користувачем ${userName}. В реальному додатку тут буде створено новий чат.`);
            
            // В реальном приложении здесь должен быть код для создания чата
            // createChat(userId);
        });
    });
}

// Функция для обновления индикатора непрочитанных сообщений в хедере
function updateUnreadBadge() {
    const badge = document.getElementById('unread-badge');
    if (!badge) return;
    // Суммируем все непрочитанные сообщения во всех чатах
    const totalUnread = chats.reduce((sum, chat) => sum + (chat.unread_count || 0), 0);
    if (totalUnread > 0) {
        badge.textContent = totalUnread > 99 ? '99+' : totalUnread;
        badge.style.display = 'inline-flex';
    } else {
        badge.style.display = 'none';
    }
} 