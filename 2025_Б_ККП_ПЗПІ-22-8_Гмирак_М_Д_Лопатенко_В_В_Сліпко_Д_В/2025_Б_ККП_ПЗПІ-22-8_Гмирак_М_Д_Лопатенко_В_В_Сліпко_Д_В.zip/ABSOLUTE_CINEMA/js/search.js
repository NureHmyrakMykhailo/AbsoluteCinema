window.initSearch = function() {
    console.log('Search script loaded');
    // Проверка на дубликаты .search-popup
    const allPopups = document.querySelectorAll('.search-popup');
    console.log('Найдено .search-popup:', allPopups.length, allPopups);
    if (allPopups.length > 1) {
        console.warn('ВНИМАНИЕ: В DOM найдено несколько элементов .search-popup! Это может вызвать проблемы с отображением поиска.');
    }
    
    const searchIcon = document.querySelector('.search-icon');
    const searchPopup = document.querySelector('.search-popup');
    const searchInput = document.querySelector('.search-container input');
    const searchResults = document.querySelector('.search-results');
    
    if (!searchIcon || !searchPopup || !searchInput || !searchResults) {
        console.error('Search elements not found:', {
            searchIcon: !!searchIcon,
            searchPopup: !!searchPopup,
            searchInput: !!searchInput,
            searchResults: !!searchResults
        });
        return;
    }

    let searchTimeout;

    // Функция для показа/скрытия попапа поиска
    function toggleSearchPopup() {
        console.log('Toggling search popup');
        searchPopup.classList.toggle('active');
        searchIcon.classList.toggle('active');
        
        if (searchPopup.classList.contains('active')) {
            console.log('Search popup activated');
            searchInput.focus();
            // Диагностика размеров и координат
            const rect = searchPopup.getBoundingClientRect();
            console.log('searchPopup bounding rect:', rect);
            console.log('searchPopup offsetWidth/offsetHeight:', searchPopup.offsetWidth, searchPopup.offsetHeight);
            console.log('searchPopup computed style:', window.getComputedStyle(searchPopup));
        } else {
            console.log('Search popup deactivated');
            searchInput.value = '';
            searchResults.innerHTML = '';
        }
    }

    // Обработчик клика по иконке поиска
    searchIcon.addEventListener('click', (e) => {
        console.log('Search icon clicked');
        e.preventDefault();
        e.stopPropagation();
        toggleSearchPopup();
        console.log('searchPopup.classList после toggle:', searchPopup.classList.value);
    });

    // Закрытие попапа при клике вне его
    document.addEventListener('click', (e) => {
        if (searchPopup.classList.contains('active') && 
            !searchPopup.contains(e.target) && 
            !searchIcon.contains(e.target)) {
            console.log('Closing search popup - clicked outside');
            searchPopup.classList.remove('active');
            searchIcon.classList.remove('active');
            searchInput.value = '';
            searchResults.innerHTML = '';
            console.log('searchPopup.classList после close:', searchPopup.classList.value);
        }
    });

    // Функция поиска фильмов
    async function searchMovies(query) {
        console.log('Searching for:', query);
        
        if (!query.trim()) {
            searchResults.innerHTML = '';
            return;
        }

        try {
            console.log('Fetching movies...');
            const response = await fetch('/api/high-rated-movies');
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log('Movies fetched:', data);
            
            const movies = data.movies || [];
            
            // Фильтрация фильмов по названию
            const filteredMovies = movies.filter(movie => 
                movie.title.toLowerCase().includes(query.toLowerCase())
            ).slice(0, 5);

            console.log('Filtered movies:', filteredMovies);

            // Отображение результатов
            if (filteredMovies.length > 0) {
                searchResults.innerHTML = filteredMovies.map(movie => `
                    <div class="search-result-item" onclick="window.location='/movie/${movie.id}'">
                        <div class="search-result-poster">
                            <img src="${movie.poster_url || 'https://via.placeholder.com/40x60?text=No+Poster'}" 
                                 alt="${movie.title}">
                        </div>
                        <div class="search-result-info">
                            <div class="search-result-title">${movie.title}</div>
                            <div class="search-result-details">
                                <span class="search-result-rating">★ ${movie.imdb_rating || '—'}</span>
                                <span class="search-result-year">${movie.release_date ? movie.release_date.slice(0,4) : '—'}</span>
                            </div>
                        </div>
                    </div>
                `).join('');
            } else {
                searchResults.innerHTML = '<div class="no-results">Фільмів не знайдено</div>';
            }
        } catch (error) {
            console.error('Search error:', error);
            searchResults.innerHTML = '<div class="no-results">Помилка пошуку</div>';
        }
    }

    // Обработчик ввода в поле поиска
    searchInput.addEventListener('input', (e) => {
        console.log('Search input changed:', e.target.value);
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            searchMovies(e.target.value);
        }, 300);
    });

    // Обработка нажатия Enter
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            console.log('Enter pressed, redirecting to search results');
            const query = e.target.value.trim();
            if (query) {
                window.location.href = `/movies.html?search=${encodeURIComponent(query)}`;
            }
        }
    });

    // Предотвращаем закрытие попапа при клике внутри него
    searchPopup.addEventListener('click', (e) => {
        e.stopPropagation();
    });

    console.log('Search initialization complete');
};

// Инициализация поиска
function initSearch() {
    const searchIcon = document.getElementById('search-icon');
    const searchPopup = document.getElementById('search-popup');
    const searchInput = searchPopup.querySelector('input');
    const searchResults = searchPopup.querySelector('.search-results');
    let searchTimeout;

    // Обработчик клика по иконке поиска
    searchIcon.addEventListener('click', (e) => {
        e.stopPropagation();
        searchPopup.classList.toggle('active');
        searchIcon.classList.toggle('active');
        if (searchPopup.classList.contains('active')) {
            searchInput.focus();
        } else {
            searchInput.value = '';
            searchResults.innerHTML = '';
        }
    });

    // Закрытие попапа при клике вне его
    document.addEventListener('click', (e) => {
        if (searchPopup.classList.contains('active') && 
            !searchPopup.contains(e.target) && 
            !searchIcon.contains(e.target)) {
            searchPopup.classList.remove('active');
            searchIcon.classList.remove('active');
            searchInput.value = '';
            searchResults.innerHTML = '';
        }
    });

    // Функция поиска фильмов
    async function searchMovies(query) {
        if (!query.trim()) {
            searchResults.innerHTML = '';
            return;
        }

        try {
            const response = await fetch(`/api/search?query=${encodeURIComponent(query)}`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            const movies = data.movies || [];

            // Отображение результатов
            if (movies.length > 0) {
                searchResults.innerHTML = movies.map(movie => `
                    <div class="search-result-item" onclick="window.location='/movie/${movie.id}'">
                        <div class="search-result-poster">
                            <img src="${movie.poster_url || 'https://via.placeholder.com/40x60?text=No+Poster'}" 
                                 alt="${movie.title}">
                        </div>
                        <div class="search-result-info">
                            <div class="search-result-title">${movie.title}</div>
                            <div class="search-result-details">
                                <span class="search-result-rating">★ ${movie.imdb_rating || '—'}</span>
                                <span class="search-result-year">${movie.release_date ? movie.release_date.slice(0,4) : '—'}</span>
                            </div>
                        </div>
                    </div>
                `).join('');
            } else {
                searchResults.innerHTML = '<div class="no-results">Фільмів не знайдено</div>';
            }
        } catch (error) {
            console.error('Search error:', error);
            searchResults.innerHTML = '<div class="no-results">Помилка пошуку</div>';
        }
    }

    // Обработчик ввода в поле поиска
    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            searchMovies(e.target.value);
        }, 300);
    });

    // Обработка нажатия Enter
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const query = e.target.value.trim();
            if (query) {
                window.location.href = `/movies.html?search=${encodeURIComponent(query)}`;
            }
        }
    });

    // Предотвращаем закрытие попапа при клике внутри него
    searchPopup.addEventListener('click', (e) => {
        e.stopPropagation();
    });
}

// Теперь инициализация поиска происходит только после загрузки header через loadHeader 