// recommendations.js - Скрипт для загрузки рекомендуемых фильмов и случайного фильма

document.addEventListener('DOMContentLoaded', () => {
    console.log('Recommendations.js: DOMContentLoaded вызван');
    loadRecommendedMovies();
    loadRandomMovie();
});

/**
 * Загружает рекомендуемые фильмы с высоким рейтингом (8+) и отображает их в блоке рекомендаций
 */
async function loadRecommendedMovies() {
    try {
        console.log('Загружаем рекомендуемые фильмы...');
        
        // Находим контейнер для рекомендаций
        const recommendationsGrid = document.querySelector('.recommendations-grid');
        if (!recommendationsGrid) {
            console.error('Не найден контейнер .recommendations-grid');
            return;
        }
        
        // Показываем индикатор загрузки
        recommendationsGrid.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i> Завантаження...</div>';
        
        // Запрашиваем фильмы с рейтингом 8 или выше с дополнительной информацией о жанрах
        console.log('Отправляем запрос к /api/high-rated-movies');
        const response = await fetch('/api/high-rated-movies', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Cache-Control': 'no-cache'
            }
        });
        
        console.log('Получен ответ от сервера:', response.status, response.statusText);
        
        if (!response.ok) {
            throw new Error(`Ошибка при загрузке рекомендуемых фильмов: ${response.status} ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log('Данные получены:', data);
        
        const recommendedMovies = data.movies || [];
        console.log(`Получено ${recommendedMovies.length} рекомендуемых фильмов`);
        
        // Очищаем контейнер перед добавлением новых рекомендаций
        recommendationsGrid.innerHTML = '';
        
        // Если нет фильмов, показываем заглушку
        if (recommendedMovies.length === 0) {
            console.log('Нет фильмов для отображения');
            recommendationsGrid.innerHTML = '<p class="no-results">Фільми не знайдені</p>';
            return;
        }
        
        // Ограничиваем количество отображаемых фильмов до 3 (или меньше, если их меньше)
        const moviesToShow = recommendedMovies.slice(0, 3);
        console.log(`Отображаем ${moviesToShow.length} фильмов`);
        
        // Создаем карточки для фильмов
        moviesToShow.forEach((movie, index) => {
            console.log(`Создаем карточку для фильма ${index + 1}:`, movie.title);
            
            // Форматируем год релиза
            const releaseYear = movie.release_date ? new Date(movie.release_date).getFullYear() : 'Не вказано';
            
            // Форматируем жанры
            const genres = movie.genres && movie.genres.length > 0 ? movie.genres.join(', ') : 'Жанр не вказаний';
            
            // Создаем HTML для карточки фильма
            const movieCard = document.createElement('div');
            movieCard.className = 'recommendation-card';
            movieCard.setAttribute('data-id', movie.id);
            
            movieCard.innerHTML = `
                <div class="recommendation-poster">
                    <img src="${movie.poster_url || 'https://via.placeholder.com/300x450?text=Немає+постера'}" alt="${movie.title}">
                    <div class="recommendation-overlay">
                        <button class="watch-button">Детальніше</button>
                    </div>
                </div>
                <div class="recommendation-info">
                    <h3>${movie.title}</h3>
                    <div class="movie-rating">
                        <span class="star">★</span> ${movie.imdb_rating}/10
                    </div>
                    <div class="movie-genres">${genres}</div>
                    <div class="recommendation-match">Рік: ${releaseYear}</div>
                </div>
            `;
            
            // Добавляем карточку в контейнер
            recommendationsGrid.appendChild(movieCard);
            
            // Добавляем обработчик события для кнопки просмотра
            const watchButton = movieCard.querySelector('.watch-button');
            if (watchButton) {
                watchButton.addEventListener('click', (e) => {
                    e.stopPropagation();
                    window.location.href = `/movie/${movie.id}`;
                });
            }
            
            // Добавляем обработчик события для клика по карточке
            movieCard.addEventListener('click', () => {
                window.location.href = `/movie/${movie.id}`;
            });
        });
        
        console.log('Рекомендуемые фильмы успешно загружены и отображены');
    } catch (error) {
        console.error('Ошибка при загрузке рекомендуемых фильмов:', error);
        const recommendationsGrid = document.querySelector('.recommendations-grid');
        if (recommendationsGrid) {
            recommendationsGrid.innerHTML = '<div class="error-container"><i class="fas fa-exclamation-circle"></i> Помилка при завантаженні фільмів</div>';
        }
    }
}

/**
 * Загружает случайный фильм из БД и отображает его в блоке случайного фильма
 */
async function loadRandomMovie() {
    try {
        console.log('Загружаем случайный фильм...');
        
        // Находим контейнер для случайного фильма
        const randomMovieContainer = document.querySelector('.random-movie-container');
        if (!randomMovieContainer) {
            console.error('Не найден контейнер .random-movie-container');
            return;
        }
        
        // Показываем индикатор загрузки
        randomMovieContainer.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i> Завантаження...</div>';
        
        // Получаем ID уже отображаемых фильмов в рекомендациях, чтобы избежать повторений
        const recommendedMovieIds = Array.from(document.querySelectorAll('.recommendation-card'))
            .map(card => card.getAttribute('data-id'));
        
        console.log('ID фильмов в рекомендациях:', recommendedMovieIds);
        
        // Используем API для получения всех фильмов (без ограничения по рейтингу)
        console.log('Отправляем запрос к /api/random-movie');
        
        const response = await fetch('/api/random-movie', {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Cache-Control': 'no-cache'
            }
        });
        
        console.log('Получен ответ от сервера:', response.status, response.statusText);
        
        if (!response.ok) {
            throw new Error(`Ошибка при загрузке фильмов: ${response.status} ${response.statusText}`);
        }
        
        // Получаем случайный фильм
        const movie = await response.json();
        console.log('Получен случайный фильм:', movie.title);
        
        // Если случайный фильм уже отображается в рекомендациях, пробуем загрузить другой
        if (recommendedMovieIds.includes(movie.id)) {
            console.log('Фильм уже отображается в рекомендациях, пробуем загрузить другой');
            return loadRandomMovie();
        }
        
        // Форматируем жанры
        const genres = movie.genres && movie.genres.length > 0 ? movie.genres.join(', ') : 'Жанр не вказаний';
        
        // Форматируем год релиза
        const releaseYear = movie.release_date ? new Date(movie.release_date).getFullYear() : 'Не вказано';
        
        // Форматируем описание фильма (ограничиваем длину)
        const description = movie.description || 'Опис відсутній';
        const formattedDescription = description.length > 300 
            ? description.substring(0, 300) + '...' 
            : description;
        
        // Создаем HTML для карточки случайного фильма
        const randomMovieCard = document.createElement('div');
        randomMovieCard.className = 'random-movie-card';
        randomMovieCard.setAttribute('data-id', movie.id);
        
        randomMovieCard.innerHTML = `
            <div class="random-movie-poster">
                <img src="${movie.poster_url || 'https://via.placeholder.com/300x450?text=Немає+постера'}" alt="${movie.title}">
            </div>
            <div class="random-movie-info">
                <h3>${movie.title}</h3>
                <div class="movie-rating">
                    <span class="star">★</span> ${movie.imdb_rating || '?'}/10
                </div>
                <div class="movie-genres">${genres}</div>
                <div class="movie-release-year">Рік: ${releaseYear}</div>
                <div class="random-movie-description">
                    ${formattedDescription}
                </div>
                <div class="random-movie-actions">
                    <button class="watch-random-button">Детальніше</button>
                    <button class="change-random-button">Змінити фільм</button>
                </div>
            </div>
        `;
        
        // Заменяем содержимое контейнера
        randomMovieContainer.innerHTML = '';
        randomMovieContainer.appendChild(randomMovieCard);
        
        // Добавляем обработчик события для кнопки просмотра
        const watchButton = randomMovieCard.querySelector('.watch-random-button');
        if (watchButton) {
            watchButton.addEventListener('click', () => {
                window.location.href = `/movie/${movie.id}`;
            });
        }
        
        // Добавляем обработчик события для кнопки смены фильма
        const changeButton = randomMovieCard.querySelector('.change-random-button');
        if (changeButton) {
            changeButton.addEventListener('click', (e) => {
                e.stopPropagation(); // Предотвращаем всплытие события
                loadRandomMovie();
            });
        }
        
        // Добавляем обработчик события клика по карточке фильма для перехода на страницу фильма
        randomMovieCard.addEventListener('click', () => {
            window.location.href = `/movie/${movie.id}`;
        });
        
        // Добавляем эффект при наведении на постер
        const posterImg = randomMovieCard.querySelector('.random-movie-poster img');
        if (posterImg) {
            posterImg.addEventListener('mouseenter', () => {
                posterImg.style.transform = 'scale(1.05)';
            });
            posterImg.addEventListener('mouseleave', () => {
                posterImg.style.transform = 'scale(1)';
            });
        }
        
        console.log('Случайный фильм успешно загружен и отображен');
    } catch (error) {
        console.error('Ошибка при загрузке случайного фильма:', error);
        const randomMovieContainer = document.querySelector('.random-movie-container');
        if (randomMovieContainer) {
            randomMovieContainer.innerHTML = `
                <div class="error-container">
                    <i class="fas fa-exclamation-circle"></i>
                    Помилка при завантаженні фільму: ${error.message}
                    <button id="retryRandomMovie">Спробувати ще раз</button>
                </div>
            `;
            
            // Добавляем обработчик для кнопки повторной попытки
            const retryButton = document.getElementById('retryRandomMovie');
            if (retryButton) {
                retryButton.addEventListener('click', loadRandomMovie);
            }
        }
    }
} 