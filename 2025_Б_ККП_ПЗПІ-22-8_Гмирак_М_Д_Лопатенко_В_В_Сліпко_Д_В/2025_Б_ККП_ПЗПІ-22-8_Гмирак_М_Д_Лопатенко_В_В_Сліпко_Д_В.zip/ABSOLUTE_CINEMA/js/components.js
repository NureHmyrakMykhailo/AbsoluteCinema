/* components.js - Компоненты UI для ABSOLUTE CINEMA */

// Функция инициализации компонентов
function initComponents() {
  // Проверяем, загружен ли хедер
  const headerContainer = document.getElementById('header-container');
  
  if (headerContainer && !headerContainer.innerHTML.trim()) {
    // Загружаем хедер, если контейнер пуст
    loadHeader();
  }
  
  // Обработчик скролла для затемнения хедера
  setupScrollEffects();
}

// Функция для обработки скролла и эффектов
function setupScrollEffects() {
  window.addEventListener('scroll', function() {
    const header = document.getElementById('main-header');
    if (header) {
      if (window.scrollY > 50) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }
  });
  
  // Запускаем один раз при загрузке страницы для установки текущего состояния
  const header = document.getElementById('main-header');
  if (header && window.scrollY > 50) {
    header.classList.add('scrolled');
  }
}

// Функция загрузки хедера
async function loadHeader() {
  try {
    const headerContainer = document.getElementById('header-container');
    if (!headerContainer) return;
    
    console.log('Загрузка хедера...');
    
    try {
      // Загружаем HTML хедера из файла компонента
      const response = await fetch('/components/header.html');
      
      // Проверяем успешность загрузки
      if (response.ok) {
        const html = await response.text();
        headerContainer.innerHTML = html;
        console.log('Хедер успешно загружен');
        if (window.initSearch) window.initSearch();
        if (window.initAuthModal) window.initAuthModal();
      } else {
        throw new Error(`Не удалось загрузить хедер: ${response.status} ${response.statusText}`);
      }
    } catch (fetchError) {
      console.error('Ошибка при загрузке хедера:', fetchError);
      
      // Резервный вариант хедера в случае ошибки
      headerContainer.innerHTML = `
        <header id="main-header">
          <div class="header-container">
            <div class="logo">
              <a href="/" id="logo-link">ABSOLUTE CINEMA</a>
            </div>
            <nav class="main-nav">
              <ul>
                <li><a href="/" class="nav-link"><i class="fas fa-home"></i>ГОЛОВНА</a></li>
                <li class="dropdown">
                  <a href="/movies.html"><i class="fas fa-film"></i>ФІЛЬМИ <i class="fas fa-chevron-down"></i></a>
                  <div class="dropdown-content">
                    <a href="/movies.html?genre=Бойовик">БОЙОВИКИ</a>
                    <a href="/movies.html?genre=Комедія">КOMЕДІЇ</a>
                    <a href="/movies.html?genre=Драма">ДРАМИ</a>
                    <a href="/movies.html?genre=Жахи">ЖАХИ</a>
                    <a href="/movies.html?genre=Фантастика">ФАНТАСТИКА</a>
                    <a href="/movies.html?genre=Трилер">ТРИЛЕРИ</a>
                    <a href="/movies.html?genre=Мультфільм">МУЛЬТФІЛЬМИ</a>
                    <a href="/movies.html?genre=Документальний">ДОКУМЕНТАЛЬНІ</a>
                    <a href="/movies.html?genre=Аніме">АНІМЕ</a>
                    <a href="/movies.html?genre=Артхаус">АРТХАУСИ</a>
                    <a href="/movies.html?genre=Детектив">ДЕТЕКТИВИ</a>
                    <a href="/movies.html?genre=Мелодрама">МЕЛОДРАМИ</a>
                  </div>
                </li>
                <li class="dropdown">
                  <a href="/series.html"><i class="fas fa-tv"></i>СЕРІАЛИ <i class="fas fa-chevron-down"></i></a>
                  <div class="dropdown-content">
                    <a href="/series/drama">ДРАМИ</a>
                    <a href="/series/comedy">КОМЕДІЇ</a>
                    <a href="/series/crime">КРИМІНАЛ</a>
                  </div>
                </li>
                <li><a href="/chats.html" class="nav-link"><i class="fas fa-comments"></i>ЧАТИ</a></li>
                <li><a href="/discussions.html" class="nav-link"><i class="fas fa-users"></i>ОБГОВОРЕННЯ</a></li>
                <li><a href="/ratings.html" class="nav-link"><i class="fas fa-star"></i>РЕЙТИНГИ</a></li>
              </ul>
            </nav>
            <div class="header-icons">
              <div class="history-icon" id="history-icon">
                <i class="fas fa-history"></i>
              </div>
              <div class="search-icon" id="search-icon">
                <i class="fas fa-search"></i>
              </div>
              <div class="login-button">
                <a href="/login">ВХІД / РЕЄСТРАЦІЯ</a>
              </div>
            </div>
          </div>
        </header>
        <div class="search-popup" id="search-popup">
          <div class="search-container">
            <input type="text" placeholder="Пошук фільмів...">
          </div>
          <div class="search-results"></div>
        </div>
      `;
      console.log('Загружен резервный хедер');
      if (window.initSearch) window.initSearch();
      if (window.initAuthModal) window.initAuthModal();
    }
    
    // Обработчики для элементов хедера
    setupHeaderEvents();
    
    // Если пользователь авторизован, обновляем UI
    if (window.authManager) {
      window.authManager.updateUI();
    }
    // Скрываем лупу, если это movies.html
    hideSearchIconOnMoviesPage();
  } catch (error) {
    console.error('Общая ошибка при инициализации хедера:', error);
  }
}

// Настройка обработчиков событий хедера
function setupHeaderEvents() {
  // Обработчик мобильного меню
  const mobileMenuButton = document.querySelector('.mobile-menu-button');
  const mainNav = document.querySelector('.main-nav');
  
  if (mobileMenuButton && mainNav) {
    mobileMenuButton.addEventListener('click', () => {
      mainNav.classList.toggle('active');
      mobileMenuButton.classList.toggle('active');
    });
  }
  
  // Обработчик для иконки истории
  const historyIcon = document.getElementById('history-icon');
  const historyPopup = document.getElementById('history-popup');
  
  if (historyIcon && historyPopup) {
    historyIcon.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      historyPopup.classList.toggle('active');
    });
    
    // Закрытие попапа при клике вне его
    document.addEventListener('click', (e) => {
      if (historyPopup && !historyIcon.contains(e.target) && !historyPopup.contains(e.target) && historyPopup.classList.contains('active')) {
        historyPopup.classList.remove('active');
      }
    });
  }
  
  // Обработчик для поиска
  const searchIcon = document.getElementById('search-icon');
  const searchPopup = document.getElementById('search-popup');
  
  if (searchIcon && searchPopup) {
    searchIcon.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      searchPopup.classList.toggle('active');
      
      // Фокусируемся на поле ввода
      const searchInput = searchPopup.querySelector('input');
      if (searchInput && searchPopup.classList.contains('active')) {
        setTimeout(() => searchInput.focus(), 100);
      }
    });
    
    // Закрытие попапа при клике вне его
    document.addEventListener('click', (e) => {
      if (searchPopup && !searchIcon.contains(e.target) && !searchPopup.contains(e.target) && searchPopup.classList.contains('active')) {
        searchPopup.classList.remove('active');
      }
    });
  }
  
  // Обработчик активной ссылки в меню
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.main-nav a');
  
  navLinks.forEach(link => {
    // Определяем активную ссылку по пути
    const linkPath = link.getAttribute('href');
    
    if (currentPath === linkPath || 
        (linkPath !== '/' && currentPath.startsWith(linkPath))) {
      // Убираем активный класс со всех ссылок
      navLinks.forEach(l => l.classList.remove('active'));
      // Добавляем активный класс текущей ссылке
      link.classList.add('active');
    }
  });
}

// После загрузки хедера, скрываю лупу если это movies.html
function hideSearchIconOnMoviesPage() {
  if (window.location.pathname.endsWith('/movies.html')) {
    const searchIcon = document.querySelector('.search-icon');
    if (searchIcon) searchIcon.style.display = 'none';
  }
}

// Вызов после загрузки хедера
window.addEventListener('DOMContentLoaded', () => {
  hideSearchIconOnMoviesPage();
});

// Экспортируем функции для использования в других модулях
window.initComponents = initComponents;
window.loadHeader = loadHeader;

// Инициализация компонентов при загрузке страницы
document.addEventListener('DOMContentLoaded', initComponents); 