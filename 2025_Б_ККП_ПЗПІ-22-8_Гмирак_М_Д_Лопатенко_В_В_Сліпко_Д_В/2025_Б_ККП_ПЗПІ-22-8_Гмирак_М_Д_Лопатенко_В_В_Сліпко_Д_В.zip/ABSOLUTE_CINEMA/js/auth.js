/* auth.js - функции аутентификации для ABSOLUTE CINEMA */

// Класс для управления аутентификацией
class AuthManager {
  constructor() {
    this.currentUser = null;
    this.isAuthenticated = false;
    this.authStateChanged = new EventTarget();
    
    // Элементы интерфейса
    this.loginButton = document.querySelector('.login-button a');
    this.authModal = document.getElementById('auth-modal');
    this.loginForm = document.getElementById('login-form');
    this.registerForm = document.getElementById('register-form');
    this.resetPasswordForm = document.getElementById('reset-password-form');
    
    // Инициализация
    this.init();
  }
  
  // Инициализация менеджера аутентификации
  async init() {
    // Проверяем статус аутентификации при загрузке страницы
    try {
      await this.checkAuthStatus();
    } catch (error) {
      console.error('Ошибка при проверке статуса аутентификации:', error);
    }
    
    // Настраиваем обработчики событий форм
    this.setupEventListeners();
  }
  
  // Проверка текущего статуса аутентификации
  async checkAuthStatus() {
    try {
      const response = await fetch('/api/auth/status', {
        method: 'GET',
        credentials: 'include' // Важно для отправки куки
      });
      
      const data = await response.json();
      
      if (data.authenticated && data.user) {
        this.isAuthenticated = true;
        this.currentUser = data.user;
        this.updateUI();
        
        // Уведомляем подписчиков о изменении статуса аутентификации
        const event = new CustomEvent('authStateChanged', { 
          detail: { isAuthenticated: true, user: this.currentUser } 
        });
        this.authStateChanged.dispatchEvent(event);
        
        // Получаем данные профиля пользователя
        await this.fetchUserProfile();
      }
    } catch (error) {
      console.error('Ошибка при проверке статуса аутентификации:', error);
    }
  }
  
  // Получение данных профиля пользователя
  async fetchUserProfile() {
    if (!this.isAuthenticated || !this.currentUser) {
      return null;
    }
    
    try {
      const response = await fetch('/api/profile', {
        method: 'GET',
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Не удалось получить данные профиля');
      }
      
      const data = await response.json();
      
      if (data.profile) {
        this.currentUser = {
          ...this.currentUser,
          profile: data.profile
        };
        
        // Обновляем UI с новыми данными профиля
        this.updateUI();
      }
      
      return this.currentUser.profile;
    } catch (error) {
      console.error('Ошибка при получении профиля:', error);
      return null;
    }
  }
  
  // Обработка входа пользователя
  async login(emailOrUsername, password, remember = false) {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ emailOrUsername, password, remember }),
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Ошибка при входе');
      }
      
      this.isAuthenticated = true;
      this.currentUser = data.user;
      
      // Закрываем модальное окно и обновляем UI
      this.closeModal();
      this.updateUI();
      
      // Получаем данные профиля пользователя
      await this.fetchUserProfile();
      
      // Уведомление о изменении статуса аутентификации
      const event = new CustomEvent('authStateChanged', { 
        detail: { isAuthenticated: true, user: this.currentUser } 
      });
      this.authStateChanged.dispatchEvent(event);
      
      // Показываем уведомление об успешном входе
      this.showNotification('Вы успешно вошли в систему', 'success');
      
      return { success: true, user: data.user };
    } catch (error) {
      console.error('Ошибка входа:', error);
      this.showFormError(this.loginForm, error.message);
      return { success: false, error: error.message };
    }
  }
  
  // Обработка регистрации пользователя
  async register(username, email, password) {
    try {
      console.log('Отправка запроса на регистрацию:', { username, email: email.slice(0, 3) + '***' });
      
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, email, password }),
        credentials: 'include'
      });
      
      // Получаем текст ответа для диагностики
      const responseText = await response.text();
      console.log('Получен ответ от сервера:', responseText);
      
      // Пытаемся распарсить JSON
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (parseError) {
        console.error('Ошибка разбора JSON:', parseError);
        throw new Error('Сервер вернул некорректный ответ: ' + responseText);
      }
      
      if (!response.ok) {
        throw new Error(data.error || data.details || 'Ошибка при регистрации');
      }
      
      this.isAuthenticated = true;
      this.currentUser = data.user;
      
      // Закрываем модальное окно и обновляем UI
      this.closeModal();
      this.updateUI();
      
      // Уведомление о изменении статуса аутентификации
      const event = new CustomEvent('authStateChanged', { 
        detail: { isAuthenticated: true, user: this.currentUser } 
      });
      this.authStateChanged.dispatchEvent(event);
      
      // Показываем уведомление об успешной регистрации
      this.showNotification('Вы успешно зарегистрировались', 'success');
      
      return { success: true, user: data.user };
    } catch (error) {
      console.error('Ошибка регистрации:', error);
      this.showFormError(this.registerForm, error.message);
      return { success: false, error: error.message };
    }
  }
  
  // Восстановление пароля
  async resetPassword(email) {
    try {
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email }),
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Ошибка при сбросе пароля');
      }
      
      // Показываем уведомление об отправке инструкций
      this.showNotification('Инструкции по восстановлению пароля отправлены на ваш email', 'info');
      
      // Возвращаемся к форме входа
      const loginTab = document.querySelector('.modal-tab[data-tab="login"]');
      if (loginTab) {
        loginTab.click();
      }
      
      return { success: true };
    } catch (error) {
      console.error('Ошибка сброса пароля:', error);
      this.showFormError(this.resetPasswordForm, error.message);
      return { success: false, error: error.message };
    }
  }
  
  // Выход пользователя из системы
  async logout() {
    try {
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Ошибка при выходе');
      }
      
      this.isAuthenticated = false;
      this.currentUser = null;
      
      // Обновляем UI
      this.updateUI();
      
      // Уведомление о изменении статуса аутентификации
      const event = new CustomEvent('authStateChanged', { 
        detail: { isAuthenticated: false, user: null } 
      });
      this.authStateChanged.dispatchEvent(event);
      
      // Показываем уведомление о выходе
      this.showNotification('Вы вышли из системы', 'info');

      // Перезагружаем страницу после успешного выхода
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      
      return { success: true };
    } catch (error) {
      console.error('Ошибка выхода:', error);
      return { success: false, error: error.message };
    }
  }
  
  // Обновление UI в соответствии с состоянием аутентификации
  updateUI() {
    const loginButton = document.querySelector('.login-button a');
    if (!loginButton) return;
    
    // Удаляем существующие обработчики, чтобы избежать дублирования
    const loginButtonContainer = document.querySelector('.login-button');
    const oldClone = loginButtonContainer.cloneNode(true);
    const newClone = loginButtonContainer.cloneNode(true);
    loginButtonContainer.parentNode.replaceChild(newClone, loginButtonContainer);
    
    // Получаем обновленные ссылки на элементы после замены
    const newLoginButton = newClone.querySelector('a');
    
    if (this.isAuthenticated && this.currentUser) {
      // Если пользователь авторизован
      const username = this.currentUser.profile ? this.currentUser.profile.username : 'ПРОФІЛЬ';
      newLoginButton.innerHTML = `<i class="fas fa-user"></i> ${username}`;
      
      // ВАЖНО: Полностью убираем атрибут href
      newLoginButton.removeAttribute('href');
      
      // Сразу создаем выпадающее меню профиля
      const dropdownHTML = `
        <div class="auth-dropdown" id="auth-dropdown">
          <div class="auth-dropdown-item profile-link"><a href="/profile"><i class="fas fa-id-card"></i> Мій профіль</a></div>
          <div class="auth-dropdown-divider"></div>
          <div class="auth-dropdown-item logout-btn"><i class="fas fa-sign-out-alt"></i> Вийти</div>
        </div>
      `;
      
      // Удаляем существующее выпадающее меню, если оно уже есть
      const existingDropdown = newClone.querySelector('#auth-dropdown');
      if (existingDropdown) {
        existingDropdown.remove();
      }
      
      // Добавляем новое выпадающее меню
      newClone.insertAdjacentHTML('beforeend', dropdownHTML);
      
      // Добавляем класс для стилизации
      newClone.classList.add('auth-active');
      
      // Обработчик нажатия на кнопку профиля для отображения выпадающего меню
      newClone.addEventListener('click', (e) => {
        // Останавливаем переход по ссылке
        e.preventDefault();
        e.stopPropagation();
        
        console.log('Клик по кнопке профиля');
        
        // Переключаем видимость выпадающего меню
        const dropdown = newClone.querySelector('#auth-dropdown');
        if (dropdown) {
          dropdown.classList.toggle('active');
          console.log('Состояние выпадающего меню:', dropdown.classList.contains('active') ? 'открыто' : 'закрыто');
        }
      });
      
      // Находим все ссылки в выпадающем меню
      const profileLinkItem = newClone.querySelector('.profile-link');
      if (profileLinkItem) {
        const profileLink = profileLinkItem.querySelector('a');
        if (profileLink) {
          console.log('Найдена ссылка на профиль:', profileLink.href);
          
          profileLink.addEventListener('click', (e) => {
            // Обработчик для ссылки на профиль
            e.stopPropagation();
            console.log('Клик по ссылке профиля:', profileLink.href);
            
            // Закрываем выпадающее меню
            const dropdown = newClone.querySelector('#auth-dropdown');
            if (dropdown) {
              dropdown.classList.remove('active');
            }
            
            // НЕ отменяем действие по умолчанию, чтобы переход по ссылке работал
          });
        }
      }
      
      // Обработчик нажатия на кнопку выхода (специальный случай)
      const logoutBtn = newClone.querySelector('.logout-btn');
      if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
          e.stopPropagation(); // Предотвращаем всплытие события
          this.logout();
        });
      }
      
      // Закрытие выпадающего меню при клике вне его
      document.addEventListener('click', (e) => {
        if (!newClone.contains(e.target)) {
          const dropdown = document.getElementById('auth-dropdown');
          if (dropdown && dropdown.classList.contains('active')) {
            dropdown.classList.remove('active');
          }
        }
      });
      
      // Обновляем ссылку на кнопку в объекте
      this.loginButton = newLoginButton;
    } else {
      // Если пользователь не авторизован
      newLoginButton.innerHTML = `ВХІД / РЕЄСТРАЦІЯ`;
      newLoginButton.setAttribute('href', '/login');
      
      // Удаляем выпадающее меню профиля, если оно есть
      const authDropdown = newClone.querySelector('#auth-dropdown');
      if (authDropdown) {
        authDropdown.remove();
      }
      
      newClone.classList.remove('auth-active');
      
      // Добавляем обработчик для открытия модального окна при клике
      newLoginButton.addEventListener('click', (e) => {
        e.preventDefault();
        this.openModal();
      });
      
      // Обновляем ссылку на кнопку в объекте
      this.loginButton = newLoginButton;
    }
  }
  
  // Настройка обработчиков событий форм
  setupEventListeners() {
    // Удаляем обработчик клика на кнопку входа из этого метода,
    // т.к. теперь он полностью управляется из метода updateUI
    
    // Обработчик закрытия модального окна
    if (this.authModal) {
      const closeButton = this.authModal.querySelector('.modal-close');
      const overlay = this.authModal.querySelector('.modal-overlay');
      
      if (closeButton) {
        closeButton.addEventListener('click', () => {
          this.closeModal();
        });
      }
      
      if (overlay) {
        overlay.addEventListener('click', () => {
          this.closeModal();
        });
      }
      
      // Переключение между вкладками
      const tabs = this.authModal.querySelectorAll('.modal-tab');
      tabs.forEach(tab => {
        tab.addEventListener('click', () => {
          // Убираем активный класс со всех вкладок
          tabs.forEach(t => t.classList.remove('active'));
          
          // Добавляем активный класс на выбранную вкладку
          tab.classList.add('active');
          
          // Скрываем все формы
          const forms = this.authModal.querySelectorAll('.modal-form');
          forms.forEach(form => form.classList.remove('active'));
          
          // Показываем выбранную форму
          const formId = tab.getAttribute('data-tab') + '-form';
          const selectedForm = document.getElementById(formId);
          if (selectedForm) {
            selectedForm.classList.add('active');
          }
        });
      });
      
      // Обработчик формы входа
      if (this.loginForm) {
        this.loginForm.querySelector('.auth-submit').addEventListener('click', async (e) => {
          e.preventDefault();
          
          const emailOrUsername = this.loginForm.querySelector('#login-email').value.trim();
          const password = this.loginForm.querySelector('#login-password').value;
          const remember = this.loginForm.querySelector('#remember')?.checked || false;
          
          if (!emailOrUsername || !password) {
            this.showFormError(this.loginForm, 'Пожалуйста, заполните все поля');
            return;
          }
          
          await this.login(emailOrUsername, password, remember);
        });
        
        // Обработчик ссылки "Забыли пароль?"
        const forgotPasswordLink = this.loginForm.querySelector('.forgot-password');
        if (forgotPasswordLink) {
          forgotPasswordLink.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Скрываем все формы
            const forms = this.authModal.querySelectorAll('.modal-form');
            forms.forEach(form => form.classList.remove('active'));
            
            // Показываем форму сброса пароля
            const resetForm = document.getElementById('reset-password-form');
            if (resetForm) {
              resetForm.classList.add('active');
            }
          });
        }
      }
      
      // Обработчик формы сброса пароля
      if (this.resetPasswordForm) {
        this.resetPasswordForm.querySelector('.auth-submit').addEventListener('click', async (e) => {
          e.preventDefault();
          
          const email = this.resetPasswordForm.querySelector('#reset-email').value.trim();
          
          if (!email) {
            this.showFormError(this.resetPasswordForm, 'Пожалуйста, введите email');
            return;
          }
          
          await this.resetPassword(email);
        });
        
        // Обработчик ссылки "Вернуться к форме входа"
        const backToLoginLink = this.resetPasswordForm.querySelector('#back-to-login');
        if (backToLoginLink) {
          backToLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Переключаемся на вкладку входа
            const loginTab = document.querySelector('.modal-tab[data-tab="login"]');
            if (loginTab) {
              loginTab.click();
            }
          });
        }
      }
      
      // Обработчик формы регистрации
      if (this.registerForm) {
        this.registerForm.querySelector('.auth-submit').addEventListener('click', async (e) => {
          e.preventDefault();
          
          // Отключаем кнопку на время выполнения запроса
          const submitButton = this.registerForm.querySelector('.auth-submit');
          const originalButtonText = submitButton.textContent;
          submitButton.disabled = true;
          submitButton.textContent = 'ОБРОБКА...';
          
          try {
            const username = this.registerForm.querySelector('#register-name').value.trim();
            const email = this.registerForm.querySelector('#register-email').value.trim();
            const password = this.registerForm.querySelector('#register-password').value;
            const passwordConfirm = this.registerForm.querySelector('#register-password-confirm').value;
            const termsAccepted = this.registerForm.querySelector('#terms')?.checked || false;
            
            // Валидация формы
            if (!username || !email || !password || !passwordConfirm) {
              this.showFormError(this.registerForm, 'Пожалуйста, заполните все поля');
              return;
            }
            
            if (password !== passwordConfirm) {
              this.showFormError(this.registerForm, 'Пароли не совпадают');
              return;
            }
            
            if (!termsAccepted) {
              this.showFormError(this.registerForm, 'Необходимо принять правила сайта');
              return;
            }
            
            await this.register(username, email, password);
          } catch (error) {
            console.error('Ошибка при обработке формы регистрации:', error);
            this.showFormError(this.registerForm, 'Произошла ошибка при обработке формы');
          } finally {
            // Восстанавливаем кнопку
            submitButton.disabled = false;
            submitButton.textContent = originalButtonText;
          }
        });
      }
      
      // Обработчики для переключателей видимости пароля
      const passwordToggles = this.authModal.querySelectorAll('.password-toggle');
      passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
          const passwordInput = toggle.previousElementSibling;
          if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggle.classList.remove('fa-eye');
            toggle.classList.add('fa-eye-slash');
          } else {
            passwordInput.type = 'password';
            toggle.classList.remove('fa-eye-slash');
            toggle.classList.add('fa-eye');
          }
        });
      });
    }
  }
  
  // Отображение ошибки в форме
  showFormError(form, errorMessage) {
    // Удаляем предыдущее сообщение об ошибке, если оно есть
    const existingError = form.querySelector('.form-error');
    if (existingError) {
      existingError.remove();
    }
    
    // Создаем элемент для отображения ошибки
    const errorElement = document.createElement('div');
    errorElement.className = 'form-error';
    errorElement.textContent = errorMessage;
    
    // Вставляем сообщение об ошибке перед кнопкой отправки
    const submitButton = form.querySelector('.auth-submit');
    form.insertBefore(errorElement, submitButton);
    
    // Анимация встряхивания формы для привлечения внимания
    form.classList.add('shake');
    setTimeout(() => {
      form.classList.remove('shake');
    }, 500);
  }
  
  // Показ уведомления
  showNotification(message, type = 'info') {
    // Удаляем предыдущее уведомление, если оно есть
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
      existingNotification.remove();
    }
    
    // Создаем элемент уведомления
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    // Добавляем иконку в зависимости от типа уведомления
    let icon = '';
    switch (type) {
      case 'success':
        icon = '<i class="fas fa-check-circle"></i>';
        break;
      case 'error':
        icon = '<i class="fas fa-exclamation-circle"></i>';
        break;
      case 'warning':
        icon = '<i class="fas fa-exclamation-triangle"></i>';
        break;
      default:
        icon = '<i class="fas fa-info-circle"></i>';
    }
    
    // Формируем содержимое уведомления
    notification.innerHTML = `
      ${icon}
      <span>${message}</span>
      <button class="notification-close"><i class="fas fa-times"></i></button>
    `;
    
    // Добавляем уведомление на страницу
    document.body.appendChild(notification);
    
    // Добавляем обработчик закрытия уведомления
    const closeButton = notification.querySelector('.notification-close');
    if (closeButton) {
      closeButton.addEventListener('click', () => {
        notification.classList.add('closing');
        setTimeout(() => {
          notification.remove();
        }, 300);
      });
    }
    
    // Автоматическое скрытие уведомления через 5 секунд
    setTimeout(() => {
      if (document.body.contains(notification)) {
        notification.classList.add('closing');
        setTimeout(() => {
          if (document.body.contains(notification)) {
            notification.remove();
          }
        }, 300);
      }
    }, 5000);
  }
  
  // Открытие модального окна
  openModal() {
    if (this.authModal) {
      this.authModal.classList.add('active');
      document.body.classList.add('modal-open');
    }
  }
  
  // Закрытие модального окна
  closeModal() {
    if (this.authModal) {
      this.authModal.classList.remove('active');
      document.body.classList.remove('modal-open');
    }
  }
  
  // Получение текущего пользователя
  getCurrentUser() {
    return this.currentUser;
  }
  
  // Проверка, авторизован ли пользователь
  isUserAuthenticated() {
    return this.isAuthenticated;
  }
  
  // Подписка на изменение состояния аутентификации
  onAuthStateChanged(callback) {
    this.authStateChanged.addEventListener('authStateChanged', (event) => {
      callback(event.detail);
    });
  }
}

// Создаем и экспортируем экземпляр AuthManager
const authManager = new AuthManager();

// Добавляем обработчик маршрутов для страницы входа
document.addEventListener('DOMContentLoaded', () => {
  // Проверяем, если текущий URL содержит /login
  if (window.location.pathname === '/login') {
    // Открываем модальное окно с формой входа
    authManager.openModal();
  }
  
  // Проверяем, если текущий URL содержит /register
  if (window.location.pathname === '/register') {
    // Открываем модальное окно с формой регистрации
    authManager.openModal();
    // Переключаемся на вкладку регистрации
    const registerTab = document.querySelector('.modal-tab[data-tab="register"]');
    if (registerTab) {
      registerTab.click();
    }
  }
});

// Экспортируем authManager для использования в других модулях
window.authManager = authManager; 