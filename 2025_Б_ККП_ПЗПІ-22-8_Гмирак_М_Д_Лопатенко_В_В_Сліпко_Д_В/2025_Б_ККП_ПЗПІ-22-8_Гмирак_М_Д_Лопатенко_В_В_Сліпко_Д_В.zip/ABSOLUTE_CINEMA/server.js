const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const path = require('path');
const http = require('http');
require('dotenv').config();
const { initWebSocket } = require('./server/websocket');

// Инициализация приложения Express
const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 3000;

// Инициализация WebSocket сервера
initWebSocket(server);

// Инициализация Supabase клиента
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

// Создаем клиент Supabase с сервисным ключом для админских операций
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// Настройка CORS для разрешения кросс-доменных запросов
app.use(cors({
  origin: true, // Разрешаем запросы с любого источника (в продакшене стоит ограничить)
  credentials: true, // Разрешаем передачу куки при кросс-доменных запросах
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Парсинг тела запроса и куки
app.use(bodyParser.json());
app.use(cookieParser(process.env.COOKIE_SECRET));

// --- ДОБАВЛЯЮ ПРОМЕЖУТОЧНЫЙ MIDDLEWARE ДЛЯ ПРОПУСКА WEBSOCKET ---
app.use((req, res, next) => {
  if (req.headers.upgrade && req.headers.upgrade.toLowerCase() === 'websocket') {
    return next();
  }
  next();
});

// Применяем middleware аутентификации ко всем запросам
const authMiddleware = async (req, res, next) => {
  const accessToken = req.signedCookies.access_token;
  const refreshToken = req.signedCookies.refresh_token;
  
  if (!accessToken) {
    return next();
  }

  try {
    // Проверка валидности сессии
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error) {
      if (refreshToken) {
        // Попытка обновить токен, если есть refresh_token
        const { data, error: refreshError } = await supabase.auth.refreshSession({
          refresh_token: refreshToken
        });
        
        if (refreshError || !data.session) {
          clearAuthCookies(res);
          return next();
        }
        
        // Обновляем куки с новыми токенами
        setAuthCookies(res, data.session);
        req.user = data.user;
      } else {
        clearAuthCookies(res);
      }
    } else {
      req.user = user;
    }
  } catch (err) {
    console.error('Ошибка аутентификации:', err);
    clearAuthCookies(res);
  }
  
  next();
};

// Функция для установки куки аутентификации
const setAuthCookies = (res, session) => {
  const maxAge = parseInt(process.env.COOKIE_MAX_AGE) || 604800000; // 7 дней по умолчанию
  
  // Установка access_token в куки
  res.cookie('access_token', session.access_token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production', // в продакшене только через HTTPS
    signed: true,
    maxAge: maxAge,
    sameSite: 'lax'
  });
  
  // Установка refresh_token в куки
  if (session.refresh_token) {
    res.cookie('refresh_token', session.refresh_token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      signed: true,
      maxAge: maxAge,
      sameSite: 'lax'
    });
  }
};

// Функция для очистки куки аутентификации
const clearAuthCookies = (res) => {
  res.clearCookie('access_token');
  res.clearCookie('refresh_token');
};

// Применяем middleware аутентификации ко всем запросам
app.use(authMiddleware);

// Middleware для хранения данных сессии
app.use((req, res, next) => {
  // Сохраняем данные пользователя в req.session
  if (req.user) {
    req.session = {
      user: {
        id: req.user.id,
        email: req.user.email
      }
    };
  }
  next();
});

// --- НАЧАЛО БЛОКА API-МАРШРУТОВ ---
// API для проверки состояния авторизации
app.get('/api/auth/status', (req, res) => {
  if (req.user) {
    return res.json({
      authenticated: true,
      user: {
        id: req.user.id,
        email: req.user.email
      }
    });
  } else {
    return res.json({
      authenticated: false
    });
  }
});

// API для получения токена для WebSocket
app.get('/api/auth/token', (req, res) => {
  const accessToken = req.signedCookies.access_token;
  
  if (!accessToken) {
    return res.status(401).json({ error: 'Не авторизован' });
  }
  
  res.json({ token: accessToken });
});

// API для получения данных профиля
app.get('/api/profile', async (req, res) => {
  try {
    // Проверка наличия пользователя
    if (!req.user) {
      console.log('Запрос к /api/profile без авторизации - возвращаю 401');
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }
    
    const userId = req.user.id;
    console.log('Запрос данных профиля для пользователя:', userId);
    
    // Получаем данные профиля из Supabase
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', userId)
      .single();
    
    if (error) {
      console.error('Ошибка при получении профиля из БД:', error);
      
      // Если профиль не существует, создаем его
      if (error.code === 'PGRST116') {
        console.log('Профиль не найден, создаю новый профиль для пользователя:', userId);
        
        // Создаем базовый профиль
        const { data: newProfile, error: createError } = await supabase
          .from('profiles')
          .insert([{ 
            user_id: userId,
            username: req.user.email.split('@')[0], // Базовое имя из email
            created_at: new Date()
          }])
          .select()
          .single();
        
        if (createError) {
          console.error('Ошибка при создании нового профиля:', createError);
          return res.status(500).json({ error: 'Ошибка при создании профиля', details: createError.message });
        }
        
        // Используем новый профиль
        data = newProfile;
      } else {
        return res.status(500).json({ error: 'Ошибка при получении профиля', details: error.message });
      }
    }
    
    // Получаем статистику пользователя
    const [reviews, favorites, comments] = await Promise.all([
      // Количество рецензий
      supabase.from('reviews').select('id', { count: 'exact' }).eq('user_id', userId),
      // Количество избранного
      supabase.from('favorites').select('media_id', { count: 'exact' }).eq('user_id', userId),
      // Количество комментариев
      supabase.from('discussion_comments').select('id', { count: 'exact' }).eq('user_id', userId)
    ]);
    
    // Формируем объект с данными профиля и статистикой
    const profileData = {
      profile: data || null,
      stats: {
        reviews: reviews.count || 0,
        favorites: favorites.count || 0,
        comments: comments.count || 0
      }
    };
    
    console.log('Данные профиля успешно загружены для пользователя:', userId);
    res.json(profileData);
  } catch (error) {
    console.error('Ошибка при получении данных профиля:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// API для обновления профиля
app.put('/api/profile', async (req, res) => {
  try {
    // Проверка наличия пользователя
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }
    
    const userId = req.user.id;
    const { username, bio, social_links } = req.body;
    
    // Проверка уникальности имени пользователя
    if (username) {
      const { data: existingUser, error: checkError } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('username', username)
        .neq('user_id', userId)
        .single();
      
      if (existingUser) {
        return res.status(400).json({ error: 'Это имя пользователя уже занято' });
      }
    }
    
    // Обновляем профиль
    const updateData = {};
    if (username) updateData.username = username;
    if (bio !== undefined) updateData.bio = bio;
    if (social_links) updateData.social_links = social_links;
    
    const { data, error } = await supabase
      .from('profiles')
      .update(updateData)
      .eq('user_id', userId)
      .select()
      .single();
    
    if (error) {
      console.error('Ошибка при обновлении профиля:', error);
      return res.status(500).json({ error: 'Ошибка при обновлении профиля', details: error.message });
    }
    
    console.log('Профиль успешно обновлен для пользователя:', userId);
    res.json({ profile: data });
  } catch (error) {
    console.error('Ошибка при обновлении профиля:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// API для регистрации
app.post('/api/auth/register', async (req, res) => {
  try {
    console.log('Начата попытка регистрации...');
    const { username, email, password } = req.body;
    
    // Валидация входных данных
    if (!username || !email || !password) {
      console.log('Ошибка: не все поля заполнены');
      return res.status(400).json({ error: 'Все поля обязательны для заполнения' });
    }
    
    console.log(`Регистрация пользователя: ${username}, ${email.slice(0, 3)}***@${email.split('@')[1]}`);
    
    // Проверяем, существует ли пользователь с таким username
    try {
      const { data: existingUser, error: usernameError } = await supabase
        .from('profiles')
        .select('username')
        .eq('username', username)
        .single();
      
      if (usernameError && usernameError.code !== 'PGRST116') {
        console.log('Ошибка при проверке существующего username:', usernameError);
        return res.status(500).json({ error: 'Ошибка при проверке имени пользователя', details: usernameError.message });
      }
      
      if (existingUser) {
        console.log('Пользователь с таким именем уже существует');
        return res.status(400).json({ error: 'Пользователь с таким именем уже существует' });
      }
    } catch (checkErr) {
      console.error('Ошибка при проверке существующего пользователя:', checkErr);
      return res.status(500).json({ error: 'Ошибка сервера при проверке существующего пользователя' });
    }
    
    // Регистрация пользователя через Supabase Auth
    let authData, authError;
    try {
      const authResult = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username: username
          }
        }
      });
      
      authData = authResult.data;
      authError = authResult.error;
      
      if (authError) {
        console.log('Ошибка при регистрации в Auth:', authError);
        return res.status(400).json({ error: authError.message });
      }
    } catch (authErr) {
      console.error('Необработанная ошибка при вызове Auth API:', authErr);
      return res.status(500).json({ error: 'Ошибка сервера при обращении к Auth API', details: authErr.message });
    }
    
    // Если успешно зарегистрирован, добавляем запись в таблицу profiles
    if (authData.user) {
      console.log('Пользователь создан в Auth, ID:', authData.user.id);
      
      try {
        const { error: profileError } = await supabase
          .from('profiles')
          .insert([
            { 
              user_id: authData.user.id, 
              username: username,
              created_at: new Date()
            }
          ]);
        
        if (profileError) {
          console.error('Ошибка создания профиля:', profileError);
          
          // Можно добавить удаление пользователя auth, если не удалось создать профиль
          // но для этого нужен админский доступ
          if (supabaseAdmin) {
            try {
              await supabaseAdmin.auth.admin.deleteUser(authData.user.id);
              console.log('Пользователь удален из Auth из-за ошибки создания профиля');
            } catch (deleteErr) {
              console.error('Не удалось удалить пользователя после ошибки:', deleteErr);
            }
          }
          
          return res.status(500).json({ error: 'Ошибка при создании профиля', details: profileError.message });
        }
      } catch (profileErr) {
        console.error('Необработанная ошибка при создании профиля:', profileErr);
        return res.status(500).json({ error: 'Ошибка сервера при создании профиля', details: profileErr.message });
      }
      
      // Устанавливаем куки сессии, если есть
      if (authData.session) {
        console.log('Устанавливаем куки сессии для нового пользователя');
        setAuthCookies(res, authData.session);
      } else {
        console.log('Нет сессии для нового пользователя (возможно, требуется подтверждение email)');
      }
      
      console.log('Регистрация успешно завершена');
      return res.status(201).json({ 
        success: true, 
        message: 'Регистрация успешна',
        user: {
          id: authData.user.id,
          email: authData.user.email
        }
      });
    } else {
      console.log('Нет данных пользователя после регистрации');
      return res.status(400).json({ 
        error: 'Регистрация не завершена, проверьте email для подтверждения' 
      });
    }
  } catch (err) {
    console.error('Необработанная ошибка регистрации:', err);
    return res.status(500).json({ 
      error: 'Ошибка сервера при регистрации', 
      details: err.message
    });
  }
});

// API для авторизации
app.post('/api/auth/login', async (req, res) => {
  try {
    const { emailOrUsername, password, remember } = req.body;
    
    if (!emailOrUsername || !password) {
      return res.status(400).json({ error: 'Необходимо указать email/имя пользователя и пароль' });
    }
    
    let email = emailOrUsername;
    
    // Если пользователь ввел имя пользователя, найти соответствующий email
    if (!emailOrUsername.includes('@')) {
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('username', emailOrUsername)
        .single();
      
      if (profileError || !profileData) {
        return res.status(400).json({ error: 'Пользователь не найден' });
      }
      
      // Получаем email по user_id используя админский доступ
      const { data: userData, error: userError } = await supabaseAdmin.auth.admin.getUserById(
        profileData.user_id
      );
      
      if (userError || !userData) {
        return res.status(400).json({ error: 'Пользователь не найден' });
      }
      
      email = userData.user.email;
    }
    
    // Авторизация через Supabase
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) {
      return res.status(401).json({ error: 'Неверные учетные данные' });
    }
    
    // Установка куки
    setAuthCookies(res, data.session);
    
    return res.json({ 
      success: true, 
      user: {
        id: data.user.id,
        email: data.user.email
      }
    });
  } catch (err) {
    console.error('Ошибка входа:', err);
    return res.status(500).json({ error: 'Ошибка сервера при входе' });
  }
});

// API для выхода
app.post('/api/auth/logout', async (req, res) => {
  try {
    // Выход из Supabase Auth
    const { error } = await supabase.auth.signOut();
    
    if (error) {
      return res.status(500).json({ error: error.message });
    }
    
    // Очистка куки
    clearAuthCookies(res);
    
    return res.json({ success: true });
  } catch (err) {
    console.error('Ошибка выхода:', err);
    return res.status(500).json({ error: 'Ошибка сервера при выходе' });
  }
});

// API для восстановления пароля
app.post('/api/auth/reset-password', async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ error: 'Email обязателен' });
    }
    
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${req.protocol}://${req.get('host')}/reset-password`,
    });
    
    if (error) {
      return res.status(400).json({ error: error.message });
    }
    
    return res.json({ 
      success: true, 
      message: 'Инструкции по сбросу пароля отправлены на указанный email' 
    });
  } catch (err) {
    console.error('Ошибка сброса пароля:', err);
    return res.status(500).json({ error: 'Ошибка сервера при сбросе пароля' });
  }
});

// API для обновления аватара
app.put('/api/profile/avatar', async (req, res) => {
  try {
    // Проверка наличия пользователя
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }
    
    const userId = req.user.id;
    const { avatar_url } = req.body;
    
    if (!avatar_url) {
      return res.status(400).json({ error: 'URL аватара не указан' });
    }
    
    // Обновляем аватар
    const { data, error } = await supabase
      .from('profiles')
      .update({ avatar_url })
      .eq('user_id', userId)
      .select()
      .single();
    
    if (error) {
      console.error('Ошибка при обновлении аватара:', error);
      return res.status(500).json({ error: 'Ошибка при обновлении аватара', details: error.message });
    }
    
    res.json({ profile: data });
  } catch (error) {
    console.error('Ошибка при обновлении аватара:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// API для получения рецензий пользователя
app.get('/api/reviews/user/:userId', async (req, res) => {
  try {
    const userId = req.params.userId;
    // Проверка авторизации - любой авторизованный пользователь может просматривать рецензии любого пользователя
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }
    console.log(`Запрос рецензий пользователя ${userId}`);
    // Получаем рецензии из Supabase
    const { data, error } = await supabase
      .from('reviews')
      .select(`
        id,
        content,
        rating,
        created_at,
        updated_at,
        media_id,
        media:media_id (
          id,
          title,
          poster_url,
          release_date,
          imdb_rating
        )
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) {
      console.error('Ошибка при получении рецензий:', error);
      return res.status(500).json({ error: 'Ошибка при получении рецензий' });
    }
    // Возвращаем список рецензий
    res.json({ reviews: data || [] });
  } catch (error) {
    console.error('Ошибка при получении рецензий пользователя:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// API для получения избранного пользователя
app.get('/api/favorites/user/:userId', async (req, res) => {
  try {
    const userId = req.params.userId;
    
    // Проверка авторизации - пользователь может получать только свое избранное
    // или админ может получать любое избранное
    if (!req.user || (req.user.id !== userId && !req.user.is_admin)) {
      return res.status(403).json({ error: 'Доступ запрещен' });
    }
    
    console.log(`Запрос избранного пользователя ${userId}`);
    
    // Получаем избранное из Supabase
    const { data, error } = await supabase
      .from('favorites')
      .select(`
        favorites_id,
        media_id,
        media:media_id (
          id,
          title,
          poster_url,
          release_date,
          imdb_rating
        )
      `)
      .eq('user_id', userId);
      
    if (error) {
      console.error('Ошибка при получении избранного:', error);
      return res.status(500).json({ error: 'Ошибка при получении избранного' });
    }
    
    // Возвращаем список избранного
    res.json({ favorites: data || [] });
  } catch (error) {
    console.error('Ошибка при получении избранного пользователя:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// API для удаления из избранного
app.delete('/api/favorites/:favoriteId', async (req, res) => {
  try {
    const favoriteId = req.params.favoriteId;
    
    // Проверка авторизации
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }
    
    // Проверяем принадлежность записи пользователю
    const { data: favorite, error: checkError } = await supabase
      .from('favorites')
      .select('user_id')
      .eq('favorites_id', favoriteId)
      .single();
      
    if (checkError) {
      console.error('Ошибка при проверке записи избранного:', checkError);
      return res.status(500).json({ error: 'Ошибка при проверке записи' });
    }
    
    if (!favorite || favorite.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Доступ запрещен' });
    }
    
    // Удаляем запись из избранного
    const { error } = await supabase
      .from('favorites')
      .delete()
      .eq('favorites_id', favoriteId);
      
    if (error) {
      console.error('Ошибка при удалении из избранного:', error);
      return res.status(500).json({ error: 'Ошибка при удалении из избранного' });
    }
    
    // Успешно удалено
    res.json({ success: true });
  } catch (error) {
    console.error('Ошибка при удалении из избранного:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// API для получения истории просмотров пользователя
app.get('/api/history/user/:userId', async (req, res) => {
  try {
    const userId = req.params.userId;
    
    // Проверка авторизации - пользователь может получать только свою историю
    // или админ может получать любую историю
    if (!req.user || (req.user.id !== userId && !req.user.is_admin)) {
      return res.status(403).json({ error: 'Доступ запрещен' });
    }
    
    console.log(`Запрос истории просмотров пользователя ${userId}`);
    
    // Получаем историю просмотров из Supabase
    const { data, error } = await supabase
      .from('viewing_history')
      .select(`
        id,
        viewed_at,
        media_id,
        media:media_id (
          id,
          title,
          poster_url,
          release_date
        )
      `)
      .eq('user_id', userId)
      .order('viewed_at', { ascending: false })
      .limit(100); // Ограничиваем количество записей
      
    if (error) {
      console.error('Ошибка при получении истории просмотров:', error);
      return res.status(500).json({ error: 'Ошибка при получении истории просмотров' });
    }
    
    // Возвращаем историю просмотров
    res.json({ history: data || [] });
  } catch (error) {
    console.error('Ошибка при получении истории просмотров пользователя:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// API для получения новинок
app.get('/api/latest-movies', async (req, res) => {
  try {
    // Получаем последние 10 фильмов из базы данных
    const { data, error } = await supabase
      .from('media')
      .select(`
        id,
        title,
        poster_url,
        release_date,
        type,
        imdb_rating
      `)
      .eq('type', 'movie')
      .order('release_date', { ascending: false })
      .limit(10);

    if (error) {
      console.error('Ошибка при получении новинок:', error);
      console.error('Детали ошибки:', error);
      return res.status(500).json({ error: 'Ошибка при получении новинок' });
    }

    // Возвращаем список новинок
    res.json({ movies: data || [] });
  } catch (error) {
    console.error('Ошибка при получении новинок:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// API для получения популярных фильмов по рейтингу IMDB
app.get('/api/popular-movies', async (req, res) => {
  try {
    // Получаем фильмы с высоким рейтингом IMDB
    const { data, error } = await supabase
      .from('media')
      .select(`
        id,
        title,
        poster_url,
        release_date,
        type,
        imdb_rating,
        description
      `)
      .eq('type', 'movie')
      .not('imdb_rating', 'is', null)
      .order('imdb_rating', { ascending: false })
      .limit(10);

    if (error) {
      console.error('Ошибка при получении популярных фильмов:', error);
      return res.status(500).json({ error: 'Ошибка при получении популярных фильмов' });
    }

    // Для каждого фильма получаем его жанры и среднюю оценку зрителей
    const moviesWithGenresAndRating = await Promise.all(data.map(async (movie) => {
      // Жанры
      let genres = [];
      try {
        const { data: genresData } = await supabase
          .from('media_genres')
          .select('genres:genre_id(name)')
          .eq('media_id', movie.id);
        genres = genresData ? genresData.map(g => g.genres.name) : [];
      } catch {}

      // Средняя оценка зрителей
      let average_rating = null;
      try {
        const { data: reviewsData } = await supabase
          .from('reviews')
          .select('rating')
          .eq('media_id', movie.id);
        if (reviewsData && reviewsData.length > 0) {
          const sum = reviewsData.reduce((acc, r) => acc + (typeof r.rating === 'number' ? r.rating : 0), 0);
          average_rating = Math.round((sum / reviewsData.length) * 10) / 10;
        }
      } catch {}

      return { ...movie, genres: genres.join(', '), average_rating };
    }));

    // Возвращаем список популярных фильмов
    res.json({ movies: moviesWithGenresAndRating || [] });
  } catch (error) {
    console.error('Ошибка при получении популярных фильмов:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// API для получения детальной информации о фильме
app.get('/api/movie/:id', async (req, res) => {
  const movieId = req.params.id;
  const { data, error } = await supabase
    .from('media')
    .select('*')
    .eq('id', movieId)
    .single();
  if (error || !data) {
    return res.status(404).json({ error: 'Фільм не знайдено' });
  }
  res.json(data);
});

// API для получения жанров фильма по его ID
app.get('/api/movie/:id/genres', async (req, res) => {
  const movieId = req.params.id;
  try {
    // Получаем жанры фильма из таблицы media_genres
    const { data, error } = await supabase
      .from('media_genres')
      .select(`
        genres:genre_id(name)
      `)
      .eq('media_id', movieId);
      
    if (error) {
      console.error(`Ошибка при получении жанров для фильма ${movieId}:`, error);
      return res.status(500).json({ error: 'Ошибка при получении жанров фильма' });
    }
    
    // Извлекаем названия жанров из данных
    const genres = data.map(g => g.genres.name);
    
    // Возвращаем массив жанров
    res.json({ genres });
  } catch (error) {
    console.error(`Необработанная ошибка при получении жанров для фильма ${movieId}:`, error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
  }
});

// API для получения актеров фильма по его ID
app.get('/api/movie/:id/cast', async (req, res) => {
  const movieId = req.params.id;
  try {
    const { data, error } = await supabase
      .from('media_people')
      .select(`
        person:person_id(full_name, photo_url),
        character_name
      `)
      .eq('media_id', movieId)
      .eq('role', 'actor');
    if (error) {
      return res.status(500).json({ error: 'Ошибка при получении актеров' });
    }
    const cast = data.map(item => ({
      full_name: item.person.full_name,
      photo_url: item.person.photo_url,
      character_name: item.character_name
    }));
    res.json({ cast });
  } catch (err) {
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// Добавляю endpoint для получения рецензий фильма по его ID
app.get('/api/movie/:id/reviews', async (req, res) => {
  const movieId = req.params.id;
  const userId = req.user?.id;
  try {
    const { data, error } = await supabase
      .from('reviews')
      .select('id, content, rating, created_at, user_id, profiles: user_id (username)')
      .eq('media_id', Number(movieId))
      .order('created_at', { ascending: false });
    if (error) {
      console.error(`Ошибка при получении рецензий для фильма ${movieId}:`, error);
      return res.status(500).json({ error: 'Ошибка при получении рецензий фильма' });
    }
    const reviews = (data || []).map(r => ({
      ...r,
      username: Array.isArray(r.profiles) ? (r.profiles[0]?.username || 'Аноним') : (r.profiles?.username || 'Аноним')
    }));

    // Получаем id всех рецензий
    const reviewIds = reviews.map(r => r.id);
    let likes = [];
    let userLikes = [];
    if (reviewIds.length > 0) {
      // Считаем лайки для каждой рецензии
      const { data: likesData } = await supabase
        .from('review_likes')
        .select('review_id')
        .in('review_id', reviewIds);
      likes = likesData || [];
      // Проверяем лайки текущего пользователя
      if (userId) {
        const { data: userLikesData } = await supabase
          .from('review_likes')
          .select('review_id')
          .eq('user_id', userId)
          .in('review_id', reviewIds);
        userLikes = userLikesData ? userLikesData.map(l => l.review_id) : [];
      }
    }
    // Формируем итоговый массив
    const reviewsWithLikes = reviews.map(r => ({
      ...r,
      likes_count: likes.filter(l => l.review_id === r.id).length,
      is_liked: userLikes.includes(r.id)
    }));

    // Считаем средний рейтинг
    let average_rating = null;
    if (reviews.length > 0) {
      const sum = reviews.reduce((acc, r) => acc + (typeof r.rating === 'number' ? r.rating : 0), 0);
      average_rating = Math.round((sum / reviews.length) * 10) / 10; // округляем до 1 знака
    }

    res.json({ reviews: reviewsWithLikes, average_rating });
  } catch (err) {
    console.error(`Необработанная ошибка при получении рецензий для фильма ${movieId}:`, err);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
  }
});

// API для добавления фильма в избранное
app.post('/api/favorites', async (req, res) => {
  console.log('Получен запрос на добавление в избранное:', req.body);
  try {
    if (!req.user) {
      console.log('Ошибка: пользователь не авторизован');
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }
    const userId = req.user.id;
    console.log('ID пользователя:', userId);
    
    let { movieId } = req.body;
    if (!movieId) {
      console.log('Ошибка: не указан ID фильма');
      return res.status(400).json({ error: 'Не указан ID фильма' });
    }
    
    // Преобразуем movieId в число, если он пришел как строка
    movieId = parseInt(movieId, 10);
    if (isNaN(movieId)) {
      console.log('Ошибка: некорректный ID фильма:', req.body.movieId);
      return res.status(400).json({ error: 'Некорректный ID фильма' });
    }
    
    console.log('ID фильма для добавления в избранное:', movieId);
    
    // Проверяем существование фильма в БД
    const { data: movie, error: movieError } = await supabase
      .from('media')
      .select('id')
      .eq('id', movieId)
      .single();
      
    if (movieError || !movie) {
      console.log('Ошибка: фильм с указанным ID не найден:', movieId);
      return res.status(404).json({ error: 'Фильм с указанным ID не найден' });
    }
    
    // Проверяем, не добавлен ли уже этот фильм в избранное
    const { data: existing, error: checkError } = await supabase
      .from('favorites')
      .select('*')
      .eq('user_id', userId)
      .eq('media_id', movieId)
      .single();
    
    if (checkError && checkError.code !== 'PGRST116') {
      console.error('Ошибка при проверке наличия фильма в избранном:', checkError);
      return res.status(500).json({ error: 'Ошибка при проверке наличия фильма в избранном' });
    }
    
    if (existing) {
      console.log('Фильм уже в избранном');
      return res.status(409).json({ error: 'Фильм уже в избранном' });
    }
    
    // Добавляем в избранное
    console.log('Добавляем фильм в избранное...');
    const { data: newFavorite, error } = await supabase
      .from('favorites')
      .insert([{ user_id: userId, media_id: movieId }])
      .select('favorites_id')
      .single();
    
    if (error) {
      console.error('Ошибка при добавлении в избранное:', error);
      return res.status(500).json({ error: 'Ошибка при добавлении в избранное', details: error.message });
    }
    
    console.log('Фильм успешно добавлен в избранное');
    res.json({ success: true, favorites_id: newFavorite.favorites_id });
  } catch (error) {
    console.error('Необработанная ошибка при добавлении в избранное:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// API для фильмов с высоким рейтингом
app.get('/api/high-rated-movies', async (req, res) => {
  try {
    console.log('Запрос фильмов с высоким рейтингом');
    
    // Получаем фильмы с рейтингом 8 или выше
    const { data, error } = await supabase
      .from('media')
      .select('id, title, poster_url, imdb_rating, description, release_date, type')
      .eq('type', 'movie')
      .order('imdb_rating', { ascending: false })  // Сортировка по убыванию рейтинга
      .limit(20);             // Ограничиваем количество результатов
      
    if (error) {
      console.error('Ошибка при получении фильмов с высоким рейтингом:', error);
      return res.status(500).json({ error: 'Ошибка сервера при получении фильмов' });
    }
    
    console.log(`Получено ${data ? data.length : 0} фильмов из базы данных`);
    
    if (!data || data.length === 0) {
      console.log('Фильмы не найдены в базе данных');
      return res.status(404).json({ error: 'Фильмы не найдены' });
    }
    
    // Отфильтруем, чтобы гарантировать наличие всех необходимых полей
    const validMovies = data.filter(movie => movie.id && movie.title && movie.poster_url);
    
    if (validMovies.length === 0) {
      console.log('Нет фильмов с полными данными');
      return res.status(404).json({ error: 'Нет фильмов с полными данными' });
    }
    
    // Для каждого фильма получаем его жанры
    const moviesWithGenres = await Promise.all(validMovies.map(async (movie) => {
      try {
        const { data: genresData, error: genresError } = await supabase
          .from('media_genres')
          .select(`
            genres:genre_id(name)
          `)
          .eq('media_id', movie.id);

        if (genresError || !genresData) {
          console.error(`Ошибка при получении жанров для фильма ${movie.id}:`, genresError);
          return { ...movie, genres: [] };
        }

        const genres = genresData.map(g => {
          return g.genres && g.genres.name ? g.genres.name : null;
        }).filter(Boolean);
        
        // Проверяем наличие всех необходимых данных и устанавливаем значения по умолчанию при необходимости
        if (!movie.description || movie.description.trim() === '') {
          movie.description = 'Опис відсутній';
        }
        
        if (!movie.imdb_rating) {
          movie.imdb_rating = '?';
        }
        
        return { ...movie, genres };
      } catch (error) {
        console.error(`Ошибка при обработке фильма ${movie.id}:`, error);
        return { ...movie, genres: [] };
      }
    }));
    
    // Перемешиваем фильмы для большей случайности (для блока случайного фильма)
    // Используем алгоритм Fisher-Yates для перемешивания
    for (let i = moviesWithGenres.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [moviesWithGenres[i], moviesWithGenres[j]] = [moviesWithGenres[j], moviesWithGenres[i]];
    }
    
    // Возвращаем список фильмов с жанрами
    res.json({ movies: moviesWithGenres || [] });
  } catch (error) {
    console.error('Необработанная ошибка при получении фильмов с высоким рейтингом:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', message: error.message });
  }
});

// API для случайного фильма
app.get('/api/random-movie', async (req, res) => {
  try {
    console.log('Запрос случайного фильма');
    
    // Запрашиваем все фильмы без ограничения по рейтингу
    const { data, error } = await supabase
      .from('media')
      .select('id, title, poster_url, imdb_rating, description, release_date, type')
      .eq('type', 'movie')
      .limit(100); // Ограничиваем выборку для производительности
      
    if (error) {
      console.error('Ошибка при получении фильмов:', error);
      return res.status(500).json({ error: 'Ошибка сервера при получении случайного фильма' });
    }
    
    console.log(`Получено ${data ? data.length : 0} фильмов из базы данных`);
    
    if (!data || data.length === 0) {
      console.log('Фильмы не найдены в базе данных');
      return res.status(404).json({ error: 'Фильмы не найдены' });
    }
    
    // Отфильтруем, чтобы гарантировать наличие всех необходимых полей
    const validMovies = data.filter(movie => movie.id && movie.title && movie.poster_url);
    
    if (validMovies.length === 0) {
      console.log('Нет фильмов с полными данными');
      return res.status(404).json({ error: 'Нет фильмов с полными данными' });
    }
    
    // Выбираем случайный фильм из массива
    const randomIndex = Math.floor(Math.random() * validMovies.length);
    const randomMovie = validMovies[randomIndex];
    
    console.log('Выбран случайный фильм:', randomMovie.title, 'ID:', randomMovie.id);
    
    // Получаем жанры для случайного фильма
    try {
      const { data: genresData, error: genresError } = await supabase
        .from('media_genres')
        .select(`
          genres:genre_id(name)
        `)
        .eq('media_id', randomMovie.id);
        
      if (!genresError && genresData && genresData.length > 0) {
        console.log(`Получено ${genresData.length} жанров для фильма`);
        const genres = genresData.map(g => g.genres && g.genres.name ? g.genres.name : null).filter(Boolean);
        randomMovie.genres = genres;
      } else {
        console.log('Жанры не найдены, используем значение по умолчанию');
        randomMovie.genres = [];
      }
    } catch (genresErr) {
      console.error('Ошибка при получении жанров для случайного фильма:', genresErr);
      randomMovie.genres = [];
    }
    
    // Проверяем наличие всех необходимых данных и устанавливаем значения по умолчанию при необходимости
    if (!randomMovie.description || randomMovie.description.trim() === '') {
      randomMovie.description = 'Опис відсутній';
    }
    
    if (!randomMovie.imdb_rating) {
      randomMovie.imdb_rating = '?';
    }
    
    // Отладочное сообщение перед отправкой
    console.log('Отправляем случайный фильм в ответе:', JSON.stringify(randomMovie, null, 2));
    
    // Возвращаем случайный фильм
    res.json(randomMovie);
  } catch (error) {
    console.error('Необработанная ошибка при получении случайного фильма:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', message: error.message });
  }
});

// API для работы с чатами
app.get('/api/chats', async (req, res) => {
  try {
    // Проверка авторизации
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }

    const userId = req.user.id;

    // Получаем список чатов пользователя
    const { data: chatsData, error: chatsError } = await supabase
      .from('chats')
      .select(`
        id,
        user1_id,
        user2_id,
        created_at,
        user1:user1_id(user_id, username, avatar_url),
        user2:user2_id(user_id, username, avatar_url)
      `)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .order('created_at', { ascending: false });

    if (chatsError) {
      console.error('Ошибка при получении чатов:', chatsError);
      return res.status(500).json({ error: 'Ошибка при получении чатов', details: chatsError.message });
    }

    // Получаем последние сообщения и количество непрочитанных для каждого чата
    const chatsWithDetails = await Promise.all(chatsData.map(async (chat) => {
      // Получаем последнее сообщение
      const { data: lastMessageData, error: lastMessageError } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('chat_id', chat.id)
        .order('sent_at', { ascending: false })
        .limit(1)
        .single();

      // Получаем количество непрочитанных сообщений
      const { count: unreadCount, error: unreadError } = await supabase
        .from('chat_messages')
        .select('*', { count: 'exact' })
        .eq('chat_id', chat.id)
        .eq('is_read', false)
        .neq('sender_id', userId);

      return {
        ...chat,
        last_message: lastMessageData || null,
        unread_count: unreadCount || 0
      };
    }));

    res.json({ chats: chatsWithDetails });
  } catch (error) {
    console.error('Ошибка при получении чатов:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

app.post('/api/chats', async (req, res) => {
  try {
    console.log('Запрос на создание нового чата');
    
    // Проверка авторизации
    if (!req.user) {
      console.log('Отказ: пользователь не авторизован');
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }

    const userId = req.user.id;
    const { user_id: otherUserId } = req.body;

    console.log(`Создание чата между пользователями ${userId} и ${otherUserId}`);

    if (!otherUserId) {
      console.log('Отказ: не указан ID собеседника');
      return res.status(400).json({ error: 'Необходимо указать ID собеседника' });
    }

    if (userId === otherUserId) {
      console.log('Отказ: попытка создать чат с самим собой');
      return res.status(400).json({ error: 'Нельзя создать чат с самим собой' });
    }

    // Определяем user_min и user_max для уникального ограничения
    const userMin = userId < otherUserId ? userId : otherUserId;
    const userMax = userId < otherUserId ? otherUserId : userId;

    console.log(`Проверка существующего чата между ${userMin} и ${userMax}`);

    // Проверяем, существует ли уже чат между пользователями
    const { data: existingChat, error: existingChatError } = await supabase
      .from('chats')
      .select('id')
      .eq('user_min', userMin)
      .eq('user_max', userMax)
      .single();

    if (existingChatError && existingChatError.code !== 'PGRST116') {
      console.error('Ошибка при проверке существующего чата:', existingChatError);
      return res.status(500).json({ error: 'Ошибка при проверке существующего чата', details: existingChatError.message });
    }

    // Если чат уже существует, возвращаем его
    if (existingChat) {
      console.log(`Чат уже существует, ID: ${existingChat.id}`);
      return res.json({ chat: existingChat });
    }

    console.log('Создание нового чата в базе данных');

    // Создаем новый чат
    const { data: newChat, error: newChatError } = await supabase
      .from('chats')
      .insert([{
        user1_id: userId,
        user2_id: otherUserId,
        user_min: userMin,
        user_max: userMax,
        created_at: new Date()
      }])
      .select()
      .single();

    if (newChatError) {
      console.error('Ошибка при создании чата:', newChatError);
      return res.status(500).json({ error: 'Ошибка при создании чата', details: newChatError.message });
    }

    console.log(`Новый чат успешно создан, ID: ${newChat.id}`);
    res.status(201).json({ chat: newChat });
  } catch (error) {
    console.error('Ошибка при создании чата:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

app.get('/api/chats/:chatId/messages', async (req, res) => {
  try {
    // Проверка авторизации
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }

    const userId = req.user.id;
    const chatId = req.params.chatId;

    // Проверяем, имеет ли пользователь доступ к чату
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .select('*')
      .eq('id', chatId)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .single();

    if (chatError || !chat) {
      return res.status(404).json({ error: 'Чат не найден или доступ запрещен' });
    }

    // Получаем сообщения чата
    const { data: messages, error: messagesError } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('chat_id', chatId)
      .order('sent_at', { ascending: true });

    if (messagesError) {
      console.error('Ошибка при получении сообщений:', messagesError);
      return res.status(500).json({ error: 'Ошибка при получении сообщений', details: messagesError.message });
    }

    res.json({ messages });
  } catch (error) {
    console.error('Ошибка при получении сообщений:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

app.post('/api/chats/:chatId/messages', async (req, res) => {
  try {
    const chatId = req.params.chatId;
    console.log(`Запрос на отправку сообщения в чат ${chatId}`);
    
    // Проверка авторизации
    if (!req.user) {
      console.log('Отказ: пользователь не авторизован');
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }

    const userId = req.user.id;
    const { content } = req.body;

    console.log(`Отправка сообщения от пользователя ${userId} в чат ${chatId}`);
    console.log('Содержание сообщения:', content);

    if (!content || !content.trim()) {
      console.log('Отказ: пустое сообщение');
      return res.status(400).json({ error: 'Сообщение не может быть пустым' });
    }

    console.log(`Проверка доступа пользователя ${userId} к чату ${chatId}`);

    // Проверяем, имеет ли пользователь доступ к чату
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .select('*')
      .eq('id', chatId)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .single();

    if (chatError) {
      console.error(`Ошибка при проверке доступа к чату ${chatId}:`, chatError);
    }

    if (chatError || !chat) {
      console.log(`Отказ: чат ${chatId} не найден или доступ запрещен`);
      return res.status(404).json({ error: 'Чат не найден или доступ запрещен' });
    }

    console.log(`Вставка сообщения в базу данных (chat_id: ${chatId}, sender_id: ${userId})`);

    // Создаем новое сообщение
    const { data: newMessage, error: newMessageError } = await supabase
      .from('chat_messages')
      .insert([
        {
          chat_id: chatId,
          sender_id: userId,
          content,
          is_read: false,
          sent_at: new Date()
        }
      ])
      .select()
      .single();

    if (newMessageError) {
      console.error('Ошибка при отправке сообщения:', newMessageError);
      return res.status(500).json({ error: 'Ошибка при отправке сообщения', details: newMessageError.message });
    }

    console.log(`Сообщение успешно отправлено, ID: ${newMessage.id}`);
    res.status(201).json({ message: newMessage });
  } catch (error) {
    console.error('Ошибка при отправке сообщения:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

app.post('/api/chats/:chatId/read', async (req, res) => {
  try {
    // Проверка авторизации
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }

    const userId = req.user.id;
    const chatId = req.params.chatId;

    // Проверяем, имеет ли пользователь доступ к чату
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .select('*')
      .eq('id', chatId)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .single();

    if (chatError || !chat) {
      return res.status(404).json({ error: 'Чат не найден или доступ запрещен' });
    }

    // Отмечаем сообщения как прочитанные
    const { error: updateError } = await supabase
      .from('chat_messages')
      .update({ is_read: true })
      .eq('chat_id', chatId)
      .neq('sender_id', userId);

    if (updateError) {
      console.error('Ошибка при отметке сообщений как прочитанных:', updateError);
      return res.status(500).json({ error: 'Ошибка при отметке сообщений как прочитанных', details: updateError.message });
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Ошибка при отметке сообщений как прочитанных:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

app.delete('/api/chats/:chatId', async (req, res) => {
  try {
    // Проверка авторизации
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }

    const userId = req.user.id;
    const chatId = req.params.chatId;

    // Проверяем, имеет ли пользователь доступ к чату
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .select('*')
      .eq('id', chatId)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .single();

    if (chatError || !chat) {
      return res.status(404).json({ error: 'Чат не найден или доступ запрещен' });
    }

    // Удаляем сообщения чата
    const { error: messagesDeleteError } = await supabase
      .from('chat_messages')
      .delete()
      .eq('chat_id', chatId);

    if (messagesDeleteError) {
      console.error('Ошибка при удалении сообщений чата:', messagesDeleteError);
      return res.status(500).json({ error: 'Ошибка при удалении сообщений чата', details: messagesDeleteError.message });
    }

    // Удаляем сам чат
    const { error: chatDeleteError } = await supabase
      .from('chats')
      .delete()
      .eq('id', chatId);

    if (chatDeleteError) {
      console.error('Ошибка при удалении чата:', chatDeleteError);
      return res.status(500).json({ error: 'Ошибка при удалении чата', details: chatDeleteError.message });
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Ошибка при удалении чата:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

app.get('/api/users/search', async (req, res) => {
  try {
  // Проверка авторизации
  if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
  }
  
    const query = req.query.query;

    if (!query) {
      return res.status(400).json({ error: 'Необходимо указать поисковый запрос' });
  }

    // Ищем пользователей по имени пользователя
    const { data: users, error } = await supabase
      .from('profiles')
      .select('user_id, username, avatar_url, bio')
      .ilike('username', `%${query}%`)
      .limit(10);

    if (error) {
      console.error('Ошибка при поиске пользователей:', error);
      return res.status(500).json({ error: 'Ошибка при поиске пользователей', details: error.message });
    }

    res.json({ users });
  } catch (error) {
    console.error('Ошибка при поиске пользователей:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

app.get('/api/users/:userId', async (req, res) => {
  try {
    // Проверка авторизации
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }

    const userId = req.params.userId;

    // Получаем профиль пользователя
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (profileError || !profile) {
      console.error('Ошибка при получении профиля пользователя:', profileError);
      return res.status(404).json({ error: 'Профіль не знайдено' });
    }

    // Получаем статистику пользователя
    const [reviews, favorites, comments] = await Promise.all([
      supabase.from('reviews').select('id', { count: 'exact' }).eq('user_id', userId),
      supabase.from('favorites').select('media_id', { count: 'exact' }).eq('user_id', userId),
      supabase.from('discussion_comments').select('id', { count: 'exact' }).eq('user_id', userId)
    ]);

    // Формируем объект с данными профиля и статистикой
    const profileData = {
      profile: profile,
      stats: {
        reviews: reviews.count || 0,
        favorites: favorites.count || 0,
        comments: comments.count || 0
      }
    };

    res.json(profileData);
  } catch (error) {
    console.error('Ошибка при получении профиля пользователя:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// Маршрут для создания новой рецензии
app.post('/api/reviews', async (req, res) => {
    try {
        const { mediaId, content, rating, containsSpoilers } = req.body;
        
        // Проверка авторизации
        if (!req.user) {
            return res.status(401).json({ error: 'Необходима авторизация' });
        }

        const userId = req.user.id;

        const { error } = await supabase
            .from('reviews')
            .insert([
                {
                    user_id: userId,
                    media_id: mediaId,
                    content,
                    rating,
                    contains_spoilers: containsSpoilers,
                    created_at: new Date()
                }
            ]);

        if (error) throw error;

        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка при создании рецензии:', error);
        res.status(500).json({ error: 'Ошибка при создании рецензии' });
    }
});

// Удаление рецензии по id
app.delete('/api/reviews/:id', async (req, res) => {
  try {
    const reviewId = Number(req.params.id);
    // Проверка авторизации
    if (!req.user) {
      return res.status(401).json({ error: 'Необходима авторизация' });
    }
    // Проверяем, что рецензия принадлежит пользователю
    const { data: review, error: reviewError } = await supabase
      .from('reviews')
      .select('user_id')
      .eq('id', reviewId)
      .single();
    if (reviewError || !review) {
      return res.status(404).json({ error: 'Рецензія не знайдена' });
    }
    if (review.user_id !== req.user.id && !req.user.is_admin) {
      return res.status(403).json({ error: 'Видалення заборонено' });
    }
    // Удаляем рецензию
    const { error } = await supabase
      .from('reviews')
      .delete()
      .eq('id', reviewId);
    if (error) {
      return res.status(500).json({ error: 'Помилка при видаленні рецензії' });
    }
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// API для лайков рецензий
app.post('/api/review-likes', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }
    const userId = req.user.id;
    // Поддержка обоих вариантов: reviewId и review_id
    const reviewId = req.body.reviewId || req.body.review_id;
    if (!reviewId) {
      return res.status(400).json({ error: 'Не указан ID рецензии' });
    }

    // Проверяем, не лайкнул ли уже пользователь эту рецензию
    const { data: existing, error: checkError } = await supabase
      .from('review_likes')
      .select('*')
      .eq('user_id', userId)
      .eq('review_id', reviewId)
      .single();

    if (existing) {
      return res.status(409).json({ error: 'Рецензия уже лайкнута' });
    }

    // Добавляем лайк
    const { data, error } = await supabase
      .from('review_likes')
      .insert([{ user_id: userId, review_id: reviewId }])
      .select();

    if (error) {
      return res.status(500).json({ error: 'Ошибка при добавлении лайка', details: error.message });
    }

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

app.delete('/api/review-likes', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Пользователь не авторизован' });
    }
    const userId = req.user.id;
    const reviewId = req.body.reviewId || req.body.review_id;
    if (!reviewId) {
      return res.status(400).json({ error: 'Не указан ID рецензии' });
    }

    const { error } = await supabase
      .from('review_likes')
      .delete()
      .eq('user_id', userId)
      .eq('review_id', reviewId);

    if (error) {
      return res.status(500).json({ error: 'Ошибка при удалении лайка', details: error.message });
    }

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});

// --- КОНЕЦ БЛОКА API-МАРШРУТОВ ---

// --- API превью обсуждений ---
app.get('/api/discussions/preview', async (req, res) => {
  try {
    // Получаем 3 самых новых обсуждения
    const { data: discussions, error: discussionsError } = await supabase
      .from('discussions')
      .select('id, title, creator_id, description, created_at')
      .order('created_at', { ascending: false })
      .limit(3);

    if (discussionsError) {
      return res.status(500).json({ error: 'Ошибка при получении обсуждений', details: discussionsError.message });
    }

    // Для каждого обсуждения получаем автора, количество комментариев и первый комментарий
    const result = await Promise.all(discussions.map(async (discussion) => {
      // Получаем автора
      const { data: author } = await supabase
        .from('profiles')
        .select('username, avatar_url')
        .eq('user_id', discussion.creator_id)
        .single();

      // Получаем количество комментариев
      const { count: commentsCount } = await supabase
        .from('discussion_comments')
        .select('id', { count: 'exact' })
        .eq('discussion_id', discussion.id);

      // Получаем первый комментарий (по дате)
      const { data: firstComment } = await supabase
        .from('discussion_comments')
        .select('content, user_id')
        .eq('discussion_id', discussion.id)
        .order('created_at', { ascending: true })
        .limit(1)
        .single();

      let commentData = null;
      if (firstComment) {
        // Получаем имя автора комментария
        const { data: commentAuthor } = await supabase
          .from('profiles')
          .select('username')
          .eq('user_id', firstComment.user_id)
          .single();
        commentData = {
          username: commentAuthor ? commentAuthor.username : 'Анонім',
          content: firstComment.content
        };
      }

      return {
        id: discussion.id,
        title: discussion.title,
        author: {
          username: author ? author.username : 'Анонім',
          avatar_url: author && author.avatar_url ? author.avatar_url : 'https://randomuser.me/api/portraits/men/1.jpg'
        },
        description: discussion.description || '',
        comments_count: commentsCount || 0,
        first_comment: commentData
      };
    }));

    res.json({ discussions: result });
  } catch (error) {
    res.status(500).json({ error: 'Внутренняя ошибка сервера', details: error.message });
  }
});
// ... существующий код ...

// --- API: получить все обсуждения для discussions.html ---
app.get('/api/discussions/all', async (req, res) => {
  try {
    // Получаем все обсуждения
    const { data: discussions, error: discussionsError } = await supabase
      .from('discussions')
      .select('id, title, description, creator_id, created_at')
      .order('created_at', { ascending: false });

    if (discussionsError) {
      return res.status(500).json({ error: 'Ошибка при получении обсуждений', details: discussionsError.message });
    }

    // Получаем авторов и количество комментариев для каждого обсуждения
    const result = await Promise.all(discussions.map(async (discussion) => {
      // Автор
      const { data: author } = await supabase
        .from('profiles')
        .select('user_id, username, avatar_url')
        .eq('user_id', discussion.creator_id)
        .single();
      // Количество комментариев
      const { count: comments_count } = await supabase
        .from('discussion_comments')
        .select('id', { count: 'exact', head: true })
        .eq('discussion_id', discussion.id);
      return {
        ...discussion,
        author: author || { username: 'Невідомий', avatar_url: '/img/avatar-default.png' },
        comments_count: comments_count || 0
      };
    }));
    res.json({ discussions: result });
  } catch (e) {
    res.status(500).json({ error: 'Ошибка сервера', details: e.message });
  }
});
// ... существующий код ...

// Статические файлы (после API-маршрутов)
app.use(express.static(path.join(__dirname)));

// Маршрут для страницы профиля (после API и статики)
app.get('/profile', (req, res) => {
  console.log('Запрос к маршруту /profile');
    if (!req.user) {
    console.log('Попытка доступа к странице профиля неавторизованным пользователем - перенаправление на /login');
      return res.redirect('/login');
  }
  console.log('Отправка HTML страницы профиля для пользователя:', req.user.id);
      const profilePath = path.resolve(__dirname, 'profile.html');
  console.log('Путь к файлу профиля:', profilePath);
  res.sendFile(profilePath);
});

// Маршрут для страницы детального просмотра фильма (после API и статики)
app.get('/movie/:id', (req, res) => {
  res.sendFile(path.join(__dirname, 'movie.html'));
});

// Маршрут для страницы чатов (после API и статики)
app.get('/chats', (req, res) => {
  console.log('Обработка запроса к /chats');
  if (!req.user) {
    console.log('Пользователь не авторизован, перенаправление на /login');
    return res.redirect('/login');
  }
  const chatsPath = path.resolve(__dirname, 'chats.html');
  console.log('Отправка chats.html:', chatsPath);
  return res.sendFile(chatsPath);
});

// Маршрут для всех остальных запросов - отдаем index.html (в самом конце)
app.get(/^\/(?!api).*/, (req, res, next) => {
  if (req.path.startsWith('/ws/chat')) {
    return next();
  }
  console.log('Запрос к URL (catch-all):', req.path, '- отправляем index.html');
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Проверка структуры БД при запуске сервера
async function checkDatabaseStructure() {
  try {
    console.log('Проверка структуры базы данных...');
    
    // Проверяем существование таблицы chat_messages
    const { count, error: countError } = await supabase
      .from('chat_messages')
      .select('*', { count: 'exact', head: true });
    
    if (countError) {
      console.error('Ошибка при проверке таблицы chat_messages:', countError);
      
      if (countError.code === '42P01') { // Код ошибки "отношение не существует"
        console.log('Таблица chat_messages не существует, создаём её...');
        
        // Создаем таблицу chat_messages
        const createTableQuery = `
          CREATE TABLE IF NOT EXISTS chat_messages (
            id SERIAL PRIMARY KEY,
            chat_id INTEGER REFERENCES chats(id) ON DELETE CASCADE,
            sender_id UUID REFERENCES profiles(user_id) ON DELETE CASCADE,
            content TEXT NOT NULL,
            is_read BOOLEAN DEFAULT FALSE,
            sent_at TIMESTAMPTZ DEFAULT NOW()
          );
        `;
        
        const { error: createError } = await supabase.rpc('execute_sql', { sql: createTableQuery });
        
        if (createError) {
          console.error('Ошибка при создании таблицы chat_messages:', createError);
        } else {
          console.log('Таблица chat_messages успешно создана');
        }
      }
    } else {
      console.log('Таблица chat_messages существует');
    }
    
    // Добавляем колонку favorites_id в таблицу favorites, если она отсутствует
    const addIdColumnQuery = `
        DO $$ 
        BEGIN 
            IF NOT EXISTS (
                SELECT 1 
                FROM information_schema.columns 
                WHERE table_name = 'favorites' 
                AND column_name = 'favorites_id'
            ) THEN
                ALTER TABLE favorites ADD COLUMN favorites_id SERIAL PRIMARY KEY;
            END IF;
        END $$;
    `;

    await supabase.rpc('execute_sql', { sql: addIdColumnQuery });
    console.log('Проверка колонки favorites_id в таблице favorites выполнена');
    
  } catch (error) {
    console.error('Ошибка при проверке структуры БД:', error);
  }
}

// Запуск сервера
server.listen(PORT, async () => {
  console.log(`Сервер запущен на порту ${PORT}`);
  
  // Проверяем структуру БД при запуске
  await checkDatabaseStructure();
});

app.get('/api/discussions/:id/comments', async (req, res) => {
  try {
    const discussionId = req.params.id;
    const { data: comments, error } = await supabase
    .from('discussion_comments')
    .select('id, user_id, content, created_at, parent_id')
    .eq('discussion_id', discussionId)
    .order('created_at', { ascending: true });

    if (error) {
      return res.status(500).json({ error: 'Ошибка при получении комментариев', details: error.message });
    }

    // Получаем авторов комментариев
    const userIds = [...new Set(comments.map(c => c.user_id))];
    let usersMap = {};
    if (userIds.length > 0) {
      const { data: users } = await supabase
        .from('profiles')
        .select('user_id, username, avatar_url')
        .in('user_id', userIds);
      (users || []).forEach(u => { usersMap[u.user_id] = u; });
    }

    const result = comments.map(c => ({
      ...c,
      author: usersMap[c.user_id] ? {
        username: usersMap[c.user_id].username,
        avatar_url: usersMap[c.user_id].avatar_url
      } : { username: 'Невідомий', avatar_url: '/img/avatar-default.png' }
    }));

    res.json({ comments: result });
  } catch (e) {
    res.status(500).json({ error: 'Ошибка сервера', details: e.message });
  }
});

app.post('/api/discussions', async (req, res) => {
  try {
    // Проверка авторизации
    const user = req.user;
    if (!user) return res.status(401).json({ error: 'Не авторизован' });

    const { title, description } = req.body;
    if (!title || !description) return res.status(400).json({ error: 'Заполните все поля' });

    const { data, error } = await supabase
      .from('discussions')
      .insert([{ title, description, creator_id: user.id }])
      .single();

    if (error) return res.status(500).json({ error: 'Ошибка при создании обсуждения', details: error.message });

    res.json({ discussion: data });
  } catch (e) {
    res.status(500).json({ error: 'Ошибка сервера', details: e.message });
  }
});

app.post('/api/discussions/:id/comments', async (req, res) => {
  try {
    // Проверка авторизации
    const user = req.user;
    if (!user) return res.status(401).json({ error: 'Не авторизован' });

    const discussionId = req.params.id;
    const { content, parent_id } = req.body;
    if (!content || !discussionId) return res.status(400).json({ error: 'Введіть текст коментаря' });

    const insertObj = { discussion_id: discussionId, user_id: user.id, content };
    if (parent_id !== undefined && parent_id !== null && parent_id !== '') insertObj.parent_id = parent_id;

    const { data, error } = await supabase
      .from('discussion_comments')
      .insert([insertObj])
      .single();

    if (error) return res.status(500).json({ error: 'Помилка при додаванні коментаря', details: error.message });

    res.json({ comment: data });
  } catch (e) {
    res.status(500).json({ error: 'Помилка сервера', details: e.message });
  }
});

// Удаление комментария обсуждения
app.delete('/api/discussions/:discussionId/comments/:commentId', async (req, res) => {
  try {
      const { discussionId, commentId } = req.params;
      // Проверка авторизации
      const user = req.user;
      if (!user) return res.status(401).json({ error: 'Не авторизован' });
        // Получаем комментарий
        const { data: comment, error: getErr } = await supabase
            .from('discussion_comments')
            .select('id, user_id')
            .eq('id', commentId)
            .eq('discussion_id', discussionId)
            .single();
        if (getErr || !comment) {
            return res.status(404).json({ error: 'Коментар не знайдено' });
        }
        if (comment.user_id !== user.id && comment.user_id !== user.user_id) {
            return res.status(403).json({ error: 'Ви не можете видалити цей коментар' });
        }
        // Удаляем комментарий
        const { error: delErr } = await supabase
            .from('discussion_comments')
            .delete()
            .eq('id', commentId)
            .eq('discussion_id', discussionId);
        if (delErr) {
            return res.status(500).json({ error: 'Помилка при видаленні коментаря', details: delErr.message });
        }
        return res.json({ success: true });
    } catch (e) {
        return res.status(500).json({ error: 'Внутрішня помилка сервера', details: e.message });
    }
});

// Удаление обсуждения
app.delete('/api/discussions/:discussionId', async (req, res) => {
    try {
        const { discussionId } = req.params;
        // Проверка авторизации
        const { user } = await authCheck(req, res);
        if (!user) return; // authCheck сам отправит 401
        // Получаем обсуждение
        const { data: discussion, error: getErr } = await supabase
            .from('discussions')
            .select('id, user_id')
            .eq('id', discussionId)
            .single();
        if (getErr || !discussion) {
            return res.status(404).json({ error: 'Обговорення не знайдено' });
        }
        if (discussion.user_id !== user.id && discussion.user_id !== user.user_id) {
            return res.status(403).json({ error: 'Ви не автор цього обговорення' });
        }
        // Удаляем все комментарии к обсуждению
        await supabase
            .from('discussion_comments')
            .delete()
            .eq('discussion_id', discussionId);
        // Удаляем само обсуждение
        const { error: delErr } = await supabase
            .from('discussions')
            .delete()
            .eq('id', discussionId);
        if (delErr) {
            return res.status(500).json({ error: 'Помилка при видаленні обговорення' });
        }
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: 'Помилка сервера' });
    }
});

// API для поиска фильмов
app.get('/api/search', async (req, res) => {
  try {
    const query = req.query.query;
    if (!query) {
      return res.json({ movies: [] });
    }

    // Получаем фильмы из базы данных
    const { data, error } = await supabase
      .from('media')
      .select(`
        id,
        title,
        poster_url,
        release_date,
        type,
        imdb_rating,
        description
      `)
      .eq('type', 'movie')
      .ilike('title', `%${query}%`)
      .limit(5);

    if (error) {
      console.error('Ошибка при поиске фильмов:', error);
      return res.status(500).json({ error: 'Ошибка при поиске фильмов' });
    }

    // Для каждого фильма получаем его жанры
    const moviesWithGenres = await Promise.all(data.map(async (movie) => {
      try {
        const { data: genresData } = await supabase
          .from('media_genres')
          .select(`
            genres:genre_id(name)
          `)
          .eq('media_id', movie.id);

        const genres = genresData ? genresData.map(g => g.genres.name) : [];
        return { ...movie, genres };
      } catch (error) {
        console.error(`Ошибка при получении жанров для фильма ${movie.id}:`, error);
        return { ...movie, genres: [] };
      }
    }));

    res.json({ movies: moviesWithGenres });
  } catch (error) {
    console.error('Ошибка при поиске фильмов:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
  }
});

