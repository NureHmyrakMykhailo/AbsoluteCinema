// test-db.js
require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

// Создаем клиента Supabase с использованием переменных окружения
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

// Попробуем создать клиента с сервисным ключом, если он есть
const supabaseAdmin = process.env.SUPABASE_SERVICE_KEY 
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY)
  : null;

// Функция для проверки подключения
async function testConnection() {
  console.log('Проверка подключения к Supabase...');
  console.log('SUPABASE_URL:', process.env.SUPABASE_URL);
  console.log('SUPABASE_ANON_KEY:', process.env.SUPABASE_ANON_KEY ? 'Ключ задан' : 'Ключ не задан');
  console.log('SUPABASE_SERVICE_KEY:', process.env.SUPABASE_SERVICE_KEY ? 'Ключ задан' : 'Ключ не задан');
  
  try {
    // Проверка подключения с публичным ключом
    console.log('\n1. Проверка доступа с публичным ключом:');
    const { data: profilesData, error: profilesError } = await supabase
      .from('profiles')
      .select('*')
      .limit(1);
    
    if (profilesError) {
      console.error('  ❌ Ошибка доступа к таблице profiles:', profilesError.message);
    } else {
      console.log('  ✅ Успешный доступ к таблице profiles');
      console.log('  📊 Данные:', JSON.stringify(profilesData, null, 2));
    }
    
    // Проверка Auth API
    console.log('\n2. Проверка Auth API:');
    const { data: authData, error: authError } = await supabase.auth.getSession();
    
    if (authError) {
      console.error('  ❌ Ошибка Auth API:', authError.message);
    } else {
      console.log('  ✅ Auth API работает корректно');
      console.log('  🔑 Текущая сессия:', authData.session ? 'Активна' : 'Отсутствует');
    }
    
    // Проверка с сервисным ключом, если он задан
    if (supabaseAdmin) {
      console.log('\n3. Проверка доступа с сервисным ключом:');
      try {
        const { data: adminData, error: adminError } = await supabaseAdmin
          .from('profiles')
          .select('*')
          .limit(1);
        
        if (adminError) {
          console.error('  ❌ Ошибка доступа с сервисным ключом:', adminError.message);
        } else {
          console.log('  ✅ Успешный доступ с сервисным ключом');
          console.log('  📊 Данные:', JSON.stringify(adminData, null, 2));
        }
        
        // Попробуем воспользоваться админским API
        const { data: userList, error: userListError } = await supabaseAdmin.auth.admin.listUsers();
        
        if (userListError) {
          console.error('  ❌ Ошибка доступа к админскому API:', userListError.message);
        } else {
          console.log('  ✅ Админский API работает корректно');
          console.log(`  👥 Количество пользователей: ${userList.users ? userList.users.length : 'Н/Д'}`);
        }
      } catch (adminErr) {
        console.error('  ❌ Ошибка при использовании сервисного ключа:', adminErr);
      }
    } else {
      console.log('\n3. Проверка с сервисным ключом: ❌ Ключ не задан');
    }
    
    // Проверка наличия необходимых таблиц
    console.log('\n4. Проверка структуры БД:');
    const client = supabaseAdmin || supabase;
    
    // Получаем список таблиц
    try {
      const { data: tablesData, error: tablesError } = await client.rpc('get_tables');
      
      if (tablesError) {
        console.error('  ❌ Ошибка получения списка таблиц:', tablesError.message);
      } else {
        const tables = tablesData || [];
        const requiredTables = ['profiles'];
        
        console.log('  📋 Найденные таблицы:', tables.join(', '));
        
        for (const table of requiredTables) {
          if (tables.includes(table)) {
            console.log(`  ✅ Таблица '${table}' существует`);
          } else {
            console.log(`  ❌ Таблица '${table}' не найдена`);
          }
        }
      }
    } catch (rpcErr) {
      console.log('  ℹ️ Не удалось получить список таблиц через RPC, пробуем альтернативный метод');
      
      // Альтернативный способ проверки таблицы profiles
      const { error: profilesCheckError } = await client
        .from('profiles')
        .select('count')
        .limit(1);
      
      if (profilesCheckError) {
        console.log('  ❌ Таблица profiles недоступна:', profilesCheckError.message);
      } else {
        console.log('  ✅ Таблица profiles существует и доступна');
      }
    }
    
    console.log('\n5. Итоговый результат:');
    if (profilesError && authError) {
      console.log('  ❌ КРИТИЧЕСКАЯ ОШИБКА: Не удалось подключиться к Supabase');
      return false;
    } else if (profilesError) {
      console.log('  ⚠️ ЧАСТИЧНО РАБОТАЕТ: Auth API работает, но есть проблемы с доступом к данным');
      return true;
    } else {
      console.log('  ✅ УСПЕШНО: Подключение к Supabase работает корректно');
      return true;
    }
  } catch (err) {
    console.error('\n❌ КРИТИЧЕСКАЯ ОШИБКА:', err);
    return false;
  }
}

// Запускаем проверку
testConnection().then(success => {
  console.log('\nПроверка завершена', success ? 'успешно! 🎉' : 'с ошибками ❌');
  process.exit(success ? 0 : 1);
}); 