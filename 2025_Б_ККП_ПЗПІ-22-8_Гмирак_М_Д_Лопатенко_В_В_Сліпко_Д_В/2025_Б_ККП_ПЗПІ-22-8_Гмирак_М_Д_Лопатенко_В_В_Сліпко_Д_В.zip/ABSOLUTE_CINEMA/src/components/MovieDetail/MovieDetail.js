import React, { useState } from 'react';

const MovieDetail = ({ movie }) => {
    const [showReviewForm, setShowReviewForm] = useState(false);
    const [showRatingForm, setShowRatingForm] = useState(false);
    const [showWatchlistForm, setShowWatchlistForm] = useState(false);
    const [reviewTitle, setReviewTitle] = useState('');
    const [reviewContent, setReviewContent] = useState('');
    const [rating, setRating] = useState('');
    const [watchlistName, setWatchlistName] = useState('');
    const [reviews, setReviews] = useState([]);

    const handleReviewSubmit = (e) => {
        e.preventDefault();
        // Handle review submission
    };

    const handleRatingSubmit = (e) => {
        e.preventDefault();
        // Handle rating submission
    };

    const handleWatchlistSubmit = (e) => {
        e.preventDefault();
        // Handle watchlist submission
    };

    return (
        <div className="movie-detail-card">
            <div className="movie-detail-header">
                <h1>{movie.title}</h1>
                <div className="movie-detail-actions">
                    <button 
                        className="action-button"
                        onClick={() => setShowReviewForm(!showReviewForm)}
                    >
                        {showReviewForm ? 'Отмена' : 'Написать рецензию'}
                    </button>
                    <button 
                        className="action-button"
                        onClick={() => setShowRatingForm(!showRatingForm)}
                    >
                        {showRatingForm ? 'Отмена' : 'Оценить фильм'}
                    </button>
                    <button 
                        className="action-button"
                        onClick={() => setShowWatchlistForm(!showWatchlistForm)}
                    >
                        {showWatchlistForm ? 'Отмена' : 'Добавить в список'}
                    </button>
                </div>
            </div>

            <div className="movie-detail-content">
                <div className="movie-detail-poster">
                    <img 
                        src={movie.poster_path ? `https://image.tmdb.org/t/p/w500${movie.poster_path}` : '/placeholder.jpg'} 
                        alt={movie.title} 
                    />
                </div>
                
                <div className="movie-detail-info">
                    <div className="movie-detail-overview">
                        <h2>Описание</h2>
                        <p>{movie.overview}</p>
                    </div>
                    
                    <div className="movie-detail-meta">
                        <div className="meta-item">
                            <span className="meta-label">Рейтинг:</span>
                            <span className="meta-value">{movie.vote_average?.toFixed(1)}/10</span>
                        </div>
                        <div className="meta-item">
                            <span className="meta-label">Дата выхода:</span>
                            <span className="meta-value">{movie.release_date}</span>
                        </div>
                        <div className="meta-item">
                            <span className="meta-label">Жанры:</span>
                            <span className="meta-value">{movie.genres?.map(genre => genre.name).join(', ')}</span>
                        </div>
                    </div>
                </div>
            </div>

            {showReviewForm && (
                <div className="review-form">
                    <h3>Написать рецензию</h3>
                    <form onSubmit={handleReviewSubmit}>
                        <div className="form-group">
                            <label htmlFor="reviewTitle">Заголовок</label>
                            <input
                                type="text"
                                id="reviewTitle"
                                value={reviewTitle}
                                onChange={(e) => setReviewTitle(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="reviewContent">Текст рецензии</label>
                            <textarea
                                id="reviewContent"
                                value={reviewContent}
                                onChange={(e) => setReviewContent(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit" className="submit-button">Опубликовать</button>
                    </form>
                </div>
            )}

            {showRatingForm && (
                <div className="rating-form">
                    <h3>Оценить фильм</h3>
                    <form onSubmit={handleRatingSubmit}>
                        <div className="form-group">
                            <label htmlFor="rating">Ваша оценка</label>
                            <input
                                type="number"
                                id="rating"
                                min="1"
                                max="10"
                                value={rating}
                                onChange={(e) => setRating(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit" className="submit-button">Оценить</button>
                    </form>
                </div>
            )}

            {showWatchlistForm && (
                <div className="watchlist-form">
                    <h3>Добавить в список</h3>
                    <form onSubmit={handleWatchlistSubmit}>
                        <div className="form-group">
                            <label htmlFor="watchlistName">Название списка</label>
                            <input
                                type="text"
                                id="watchlistName"
                                value={watchlistName}
                                onChange={(e) => setWatchlistName(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit" className="submit-button">Добавить</button>
                    </form>
                </div>
            )}

            <div className="movie-reviews">
                <h2>Рецензии</h2>
                {reviews.length > 0 ? (
                    <div className="reviews-list">
                        {reviews.map(review => (
                            <div key={review.id} className="review-item">
                                <h3>{review.title}</h3>
                                <p>{review.content}</p>
                                <div className="review-meta">
                                    <span>Автор: {review.author}</span>
                                    <span>Дата: {new Date(review.created_at).toLocaleDateString()}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p>Пока нет рецензий</p>
                )}
            </div>
        </div>
    );
};

export default MovieDetail; 